import datetime
import gzip
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

p = Path(__file__).resolve().parent
c = p/'checkout'
label = sys.argv[1]
ident = {'057':'INFRA-057', '058':'INFRA-058', '051':'INFRA-051', '041':'FE-041'}[label]
e = c/'docs/dev-cycle/evidence'/ident
e.mkdir(parents=True, exist_ok=True)
for name in ['backend.log', 'next.log', 'browser-commands.jsonl', 'requests.jsonl']:
    (e/(name+'.gz')).write_bytes(gzip.compress((p/name).read_bytes()))
for f in p.glob(label+'-*'):
    if f.suffix in {'.png', '.gz'} or f.name.endswith(('summary.json', 'adversarial.json', 'normal-values.json', 'ready.json', 'deletion.json', 'save-results.json')):
        shutil.copy2(f, e/f.name)
for name in ['qa_fixture.py','ui_driver.py','browser_cli.py','cleanup_round.py']:
    (e/(name+'.gz')).write_bytes(gzip.compress((p/name).read_bytes()))
shutil.copy2(p/'proxy-cleanup.json',e/'proxy-cleanup.json')
ready = json.loads((p/(label+'-ready.json')).read_text())
ports = [ready['backend']['port'], ready['next']['port'], json.loads((p/'proxy-ready.json').read_text())['port']]
for port in ports:
    assert subprocess.run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'],capture_output=True).returncode == 1
ns = Path.home()/'.agent-browser/namespaces/devcycle-notification-4s28gwie'
assert not list(ns.rglob('*.pid'))
if ns.exists():
    shutil.rmtree(ns)
for name in ['.env','.env.lock']:
    f=c/name
    if f.exists():
        assert f.is_file() and not f.is_symlink()
        f.unlink()
for name in ['fake.env','fixture-secrets.json','admin-nextauth-cookie.json','viewer-nextauth-cookie.json','legacy-link-created.json','fixture-control.json','proxy-ready.json','stop']:
    f=p/name
    if f.exists():
        f.unlink()
for name in ['browser-admin-055','browser-viewer-055','browser-admin-batch','browser-viewer-batch']:
    f=p/name
    if f.exists():
        shutil.rmtree(f)
owned=json.loads((p/'ownership.json').read_text())
unchanged=hashlib.sha256((Path(owned['root'])/'package.json').read_bytes()).hexdigest()==owned['user_package_sha256']
assert unchanged
result={'at':datetime.datetime.now().astimezone().isoformat(),'ports_stopped':ports,'browser_namespace_removed':not ns.exists(),'fixture_env_removed':not(c/'.env').exists(),'original_user_package_unchanged':unchanged,'workspace_retained':'approved remaining rounds; runtime/credentials/profile removed'}
(e/'cleanup.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
