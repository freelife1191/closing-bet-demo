"""실제 agent-browser UI 조작과 요청 관측을 함께 기록한다."""
import json
import re
import subprocess
import sys
from pathlib import Path

p = Path(__file__).resolve().parent
name, title, want_env, want_requests, want_status, want_transport = sys.argv[1:]
assert re.fullmatch(r'041-[a-z-]+', name)
def ab(*args, script=None):
    r = subprocess.run([sys.executable, str(p/'browser_cli.py'), 'admin', *args], input=script,
                       capture_output=True, text=True, timeout=75)
    if r.returncode:
        print(r.stdout + r.stderr)
        raise SystemExit(r.returncode)
    return r.stdout

def requests():
    return [json.loads(line) for line in (p/'requests.jsonl').read_text().splitlines()]

script = "performance.getEntriesByType('resource').filter(e => new URL(e.name).pathname === '/api/system/env').map(e => ({status: e.responseStatus, url: e.name}))"
before_resources = json.loads(ab('eval', '--stdin', script=script))
before = requests()
transport = before[-1]['transport_count'] if before else 0
ui = subprocess.run([sys.executable, str(p/'ui_driver.py'), 'admin', 'click', '테스트 발송', '1'],
                    capture_output=True, text=True, timeout=90)
if ui.returncode:
    print(ui.stdout + ui.stderr)
    raise SystemExit(ui.returncode)
ab('wait', '--text', title)
ab('snapshot', '-i')
ab('screenshot', str(p/(name+'.png')))
resources = json.loads(ab('eval', '--stdin', script=script))[len(before_resources):]
after = requests()[len(before):]
notifications = [r for r in after if r['method'] == 'POST' and r['path'] == '/api/notification/send']
env_records = [r for r in after if r['method'] == 'POST' and r['path'] == '/api/system/env']
new_transport = after[-1]['transport_count'] if after else transport
observed = {'case': name, 'title': title, 'env_resource_status': resources,
            'server_env_requests': len(env_records), 'notification_requests': len(notifications),
            'notification_status': notifications[-1]['status'] if notifications else None,
            'transport_delta': new_transport - transport, 'screenshot': name+'.png'}
with (p/'041-cases.jsonl').open('a') as out:
    out.write(json.dumps(observed, ensure_ascii=False)+'\n')
print(json.dumps(observed, ensure_ascii=False))
assert len(notifications) == int(want_requests)
assert observed['notification_status'] == (int(want_status) if want_status != 'none' else None)
assert observed['transport_delta'] == int(want_transport)
if want_env == 'abort':
    assert not env_records and all(r.get('status', 0) == 0 for r in resources)
else:
    assert resources and resources[-1]['status'] == int(want_env)
