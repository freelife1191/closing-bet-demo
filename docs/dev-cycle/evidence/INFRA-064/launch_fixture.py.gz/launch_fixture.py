from pathlib import Path
import os,socket,json,sys
P=Path(__file__).resolve().parent
ports=[]
while len(ports)<2:
 with socket.socket() as s:
  s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
 if port not in ports+[3500,5501]: ports.append(port)
policy='(version 1)(allow default)(deny network-outbound)'+''.join('(allow network-outbound (remote ip "localhost:%d"))'%port for port in ports)
(P/'fixture.sb').write_text(policy+'\n')
(P/'fixture-input.json').write_text(json.dumps({'flask':ports[0],'next':ports[1],'policy':policy},indent=2)+'\n')
env={k:os.environ[k] for k in ('PATH','HOME','USER','LOGNAME','LANG','LC_ALL','SHELL','TMPDIR') if k in os.environ}
env.update(SCHEDULER_ENABLED='false',PYTHONDONTWRITEBYTECODE='1',NEXT_TELEMETRY_DISABLED='1',NEXT_TRACE_UPLOAD_DISABLED='1')
args=['/usr/bin/sandbox-exec','-f',str(P/'fixture.sb'),str(P/'checkout/venv/bin/python'),'-B',str(P/'gate_web_fixture.py'),'--flask-port',str(ports[0]),'--next-port',str(ports[1])]
os.chdir(P/'checkout')
log=os.open(P/'backend.log',os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
os.dup2(log,1);os.dup2(log,2);os.close(log)
os.execve(args[0],args,env)
