# INFRA-064 격리 브라우저 실측 하네스

`gate_web_fixture.py`는 임시 clone의 실제 Next 대시보드와 실제 Flask
`_register_market_gate_routes`를 연결한다. 실제 `kr_market._trigger_market_gate_background_refresh`의
파일 잠금·쿨다운·스레드 상태 전이는 그대로 실행하고, worker 안에서 동적으로 import하는
`engine.market_gate.MarketGate`만 임시 구현으로 바꾼다. 결과 파일은 이 하네스의
`gate-data/market_gate.json`에만 저장된다.

실행은 리더가 담당한다. 브라우저 시작 전 한 번만 다음을 실행한다.

```sh
cd /private/var/folders/99/kpfx0mdj3fvbczqpbncjl0bm0000gn/T/closing-bet-infra064-9f4s45_s
/Users/freelife/vibe/lecture/hodu/closing-bet-demo/venv/bin/python -B gate_web_fixture.py
```

외부 차단 sandbox가 정확한 loopback 포트를 미리 허용해야 하면 리더가 소유한 빈 포트를
확정해 `--flask-port <port> --next-port <port>`를 붙인다. 인자를 생략하면 두 포트는
동적으로 배정되며, 어느 경우에도 3500·5501은 거부한다.

`ready.json`에는 동적으로 할당된 loopback Next/Flask 포트, `/dashboard/kr`,
`/dashboard/kr/vcp`, `cookie_file`(admin 기본값), `cookie_files.admin`·`cookie_files.viewer`,
그리고 fixture control URL이 들어 있다. 시작 시 현재 날짜의 fresh score 72와
`1999-01-01`의 historical score 31을 각각 임시 JSON에 둔다.
원본 3500/5501, 실제 `.env`·`data/`, 외부 주소는 사용하지 않는다. 15분 이내에 `stop` 파일을
만들면 runner가 Next 프로세스 그룹을 SIGKILL-first로 종료하고 Flask도 내린다.

`POST <control_url>`의 JSON control은 fixture 전용이다.

| body | 용도 |
| --- | --- |
| `{"event":"mode","mode":"success"}` | 다음 실제 자동 분석을 성공시킨다. |
| `{"event":"mode","mode":"fail"}` | 다음 실제 자동 분석을 예외로 끝낸다. |
| `{"event":"hold"}` / `{"event":"release"}` | 실제 in-flight 상태를 고정·해제한다. |
| `{"event":"advance","seconds":300}` | 제품의 300초 쿨다운 로직을 바꾸지 않고 fake clock만 전진한다. |
| `{"event":"reset"}` | 분석이 idle일 때 fixture lock·gate JSON·측정 수를 초기화한다. |
| `{"event":"snapshot"}` | `metrics.json`과 같은 요약을 반환한다. |

권장 시나리오는 다음과 같다.

1. admin 쿠키로 `/dashboard/kr`를 열고 `hold` 후 최초 GET이 `initializing`인지 확인한다.
2. `release` 후 성공 snapshot이 표시되는지, 이어진 GET이 분석을 중복 실행하지 않는지
   `metrics.json`의 `analysis_count`, `save_count`, `api_requests`로 확인한다.
3. `reset` 및 `mode=fail` 후 페이지를 다시 열어 한 번만 분석하고, 쿨다운 중에는
   `initializing` 대신 빈/기존 snapshot 상태가 보이는지 확인한다. `advance 300` 뒤 재시도한다.
4. 날짜 입력을 과거로 바꿔 `/api/kr/market-gate?...&date=...` 요청이 실제 분석 수를 늘리지
   않는지 확인한다.
5. `/dashboard/kr/vcp`도 열어 같은 Market Gate caller가 실제 경로를 통과하는지 확인한다.

이 하네스는 UI가 조회하는 보조 GET에 빈 형식의 fixture payload를 돌려준다. VCP 시그널,
시장 데이터 수집, LLM, 알림, 관리자 갱신 POST와 실제 분석 결과의 품질은 검증 범위가 아니다.
