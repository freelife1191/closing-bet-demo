import os,sys,subprocess,time,json
from pathlib import Path
P=Path(__file__).resolve().parent
C=P/'checkout'
name=sys.argv[1]; cwd=C/('frontend' if name.startswith(('vitest','typecheck','lint')) else '')
commands={'pytest':[str(C/'venv/bin/python'),'-B','-m','pytest','-q'], 'vitest':['./node_modules/.bin/vitest','run'], 'typecheck':['npm','run','type-check'],'lint':['npm','run','lint']}
cmd=commands.get(name.split('-')[0],sys.argv[2:])
if name.split('-')[0] in commands: cmd=cmd+sys.argv[2:]
env={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL','USER') if k in os.environ}
env.update(SCHEDULER_ENABLED='false',PYTHONDONTWRITEBYTECODE='1',NEXT_TELEMETRY_DISABLED='1',NEXT_TRACE_UPLOAD_DISABLED='1',CI='1')
policy='local-network.sb' if name.startswith(('vitest','typecheck','lint')) else 'no-network.sb'
start=time.time()
with (P/(name+'.log')).open('w') as log:
 result=subprocess.run(['/usr/bin/sandbox-exec','-f',str(P/policy),*cmd],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=480)
meta={'name':name,'command':cmd,'cwd':str(cwd),'exit':result.returncode,'seconds':round(time.time()-start,2),'policy':policy}
(P/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta));print('\n'.join((P/(name+'.log')).read_text().splitlines()[-12:]));sys.exit(result.returncode)
