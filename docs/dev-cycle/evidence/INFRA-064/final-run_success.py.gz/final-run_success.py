import json,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent

def ab(*args):
 r=subprocess.run([sys.executable,'-B',str(P/'browser_cli.py'),'viewer',*args],capture_output=True,text=True,timeout=70)
 assert r.returncode==0,(args,r.stdout,r.stderr)
 return r.stdout

def control(data):
 r=subprocess.run([sys.executable,'-B',str(P/'control.py'),json.dumps(data)],capture_output=True,text=True,timeout=15)
 assert r.returncode==0,r.stderr

def metrics(name):
 data=json.loads((P/'metrics.json').read_text());(P/name).write_text(json.dumps(data,ensure_ascii=False,indent=2));return data

control({'event':'reset'});control({'event':'mode','mode':'success'});control({'event':'hold'})
ab('reload');ab('wait','1000')
text=ab('get','text','body');assert '\n50\nSCORE\nNeutral\n' in text,text
ab('snapshot','-i');ab('screenshot',str(P/'running.png'))
ab('wait','5500')
m=metrics('metrics-running-short.json');g=[r for r in m['api_requests'] if r['path']=='/api/kr/market-gate']
assert m['analysis_count']==1 and m['save_count']==0 and len(g)>=2,g
assert all(r['response']['status']=='initializing' for r in g),g
control({'event':'release'});ab('wait','5500')
text=ab('get','text','body');assert '\n72\nSCORE\nBullish\n' in text,text
ab('snapshot','-i');ab('screenshot',str(P/'success.png'))
m=metrics('metrics-success.json');assert m['analysis_count']==1 and m['save_count']==1,m
(P/'success-result.json').write_text(json.dumps({'status':'passed','analysis':1,'save':1,'initial_poll_requests':len(g),'body_score':72},indent=2))
print('success UI passed: inflight poll >=2, analysis1, save1, visible72')
