import json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent

def ab(*args):
 r=subprocess.run([sys.executable,'-B',str(P/'browser_cli.py'),'viewer',*args],capture_output=True,text=True,timeout=70)
 assert r.returncode==0,(args,r.stdout,r.stderr)
 return r.stdout

def control(data):
 r=subprocess.run([sys.executable,'-B',str(P/'control.py'),json.dumps(data)],capture_output=True,text=True,timeout=15)
 assert r.returncode==0,r.stderr

def metrics(name):
 data=json.loads((P/'metrics.json').read_text());(P/name).write_text(json.dumps(data,ensure_ascii=False,indent=2));return data

def gates(m):return [r for r in m['api_requests'] if r['path']=='/api/kr/market-gate']
control({'event':'reset'});control({'event':'mode','mode':'fail'})
ab('reload');ab('wait','6000')
text=ab('get','text','body');assert '\n50\nSCORE\nNeutral\n' in text,text
ab('snapshot','-i');ab('screenshot',str(P/'failure.png'))
m=metrics('metrics-failure.json');assert m['analysis_count']==1 and m['save_count']==0,m
assert gates(m)[-1]['response']['message']=='데이터 없음',gates(m)
before=len(gates(m));ab('wait','6500');m=metrics('metrics-no-repoll.json');assert len(gates(m))==before,gates(m)
control({'event':'advance','seconds':299});ab('reload');ab('wait','800')
m=metrics('metrics-299.json');assert m['analysis_count']==1 and gates(m)[-1]['response']['status']!='initializing',m
ab('snapshot','-i');ab('screenshot',str(P/'cooldown-299.png'))
control({'event':'advance','seconds':1});ab('reload');ab('wait','6000')
m=metrics('metrics-300.json');assert m['analysis_count']==2 and m['save_count']==0,m
control({'event':'mode','mode':'success'});control({'event':'advance','seconds':300});ab('reload');ab('wait','6000')
text=ab('get','text','body');assert '\n72\nSCORE\nBullish\n' in text,text
m=metrics('metrics-recovery.json');assert m['analysis_count']==3 and m['save_count']==1,m
ab('screenshot',str(P/'recovery.png'))
errors=ab('errors');assert not errors.strip(),errors
console=ab('console');assert '[error]' not in console,console
(P/'failure-result.json').write_text(json.dumps({'status':'passed','failure_analysis':1,'repoll_after_empty':0,'at299_analysis':1,'at300_analysis':2,'recovery_analysis':3,'recovery_save':1},indent=2))
print('failure UI passed: one failure, no repoll, 299 blocked, 300 allowed, success recovery72')
