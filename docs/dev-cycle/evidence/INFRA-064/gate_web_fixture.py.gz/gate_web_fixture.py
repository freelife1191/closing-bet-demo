#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""INFRA-064 browser fixture: real Next UI + real Market Gate GET route.

This runner only serves an isolated checkout on dynamically assigned loopback
ports.  It does not use ``create_app()``, a dotenv file, a production port, or
the real MarketGate implementation.  The route registration, validity
helpers, refresh lock/cooldown function and Next rewrite/proxy are real.
"""

from __future__ import annotations

import argparse
import json
import os
import secrets
import signal
import socket
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from types import ModuleType
from typing import Any

from flask import Blueprint, Flask, Response, jsonify, request
from werkzeug.serving import BaseWSGIServer, make_server


ROOT = Path(__file__).resolve().parent
CLONE = ROOT / "checkout"
FRONTEND = CLONE / "frontend"
DATA_DIR = ROOT / "gate-data"
READY = ROOT / "ready.json"
STOP = ROOT / "stop"
CONTROL = ROOT / "control.json"
METRICS = ROOT / "metrics.json"
NEXT_LOG = ROOT / "next.log"
LIFETIME_SECONDS = 15 * 60
START_TIMEOUT_SECONDS = 90
CHILD_ENV_ALLOWLIST = (
    "PATH", "HOME", "USER", "LOGNAME", "SHELL", "TMPDIR", "TMP", "TEMP",
    "LANG", "LC_ALL", "XDG_CACHE_HOME",
)
ADMIN_EMAIL = "infra064-admin@example.test"
VIEWER_EMAIL = "infra064-viewer@example.test"


class FixtureFailure(RuntimeError):
    """A safe fixture setup failure."""


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise FixtureFailure(message)


def _safe_child_environment() -> dict[str, str]:
    return {key: os.environ[key] for key in CHILD_ENV_ALLOWLIST if key in os.environ}


def _assert_no_runtime_secrets() -> None:
    dotenv_paths = (
        CLONE / ".env", CLONE / ".env.production", CLONE / ".env.vertex",
        FRONTEND / ".env", FRONTEND / ".env.local", FRONTEND / ".env.development",
        FRONTEND / ".env.production",
    )
    _assert(not any(path.exists() for path in dotenv_paths), "dotenv file exists in isolated clone")


def _free_loopback_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as candidate:
        candidate.bind(("127.0.0.1", 0))
        port = int(candidate.getsockname()[1])
    _assert(port not in {3500, 5501}, "standard service port selected")
    return port


def _write_json_atomic(path: Path, payload: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def _listener_pids(port: int) -> list[int]:
    listing = subprocess.run(
        ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-Fp"],
        check=False,
        capture_output=True,
        text=True,
    )
    _assert(listing.returncode in (0, 1), "lsof listener query failed")
    return [int(line[1:]) for line in listing.stdout.splitlines() if line.startswith("p")]


def _process_group_members(pgid: int) -> list[int]:
    listing = subprocess.run(["/usr/bin/pgrep", "-g", str(pgid)], capture_output=True, text=True)
    _assert(listing.returncode in (0, 1), "pgrep group query failed")
    return [int(value) for value in listing.stdout.split()]


def _terminate_next(process: subprocess.Popen[bytes], pgid: int, port: int) -> None:
    _assert(process.pid == pgid, "refusing to terminate non-owned Next process group")
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired as error:
        raise FixtureFailure("owned Next process did not stop") from error
    _assert(not _process_group_members(pgid), "owned Next process group still has members")
    _assert(not _listener_pids(port), "owned Next port still listening")


def _start_next(port: int, flask_port: int, identity_secret: str, jwt_secret: str) -> tuple[subprocess.Popen[bytes], int]:
    environment = _safe_child_environment()
    environment.update({
        "API_URL": f"http://127.0.0.1:{flask_port}",
        "INTERNAL_IDENTITY_SECRET": identity_secret,
        "NEXTAUTH_SECRET": jwt_secret,
        "AUTH_SECRET": jwt_secret,
        "NEXTAUTH_URL": f"http://127.0.0.1:{port}",
        "ADMIN_EMAILS": ADMIN_EMAIL,
        "SCHEDULER_ENABLED": "false",
        "NODE_ENV": "development",
        "NEXT_TELEMETRY_DISABLED": "1",
        "NEXT_TRACE_UPLOAD_DISABLED": "1",
    })
    with NEXT_LOG.open("wb") as log_handle:
        process = subprocess.Popen(
            ["node", "node_modules/next/dist/bin/next", "dev", "--hostname", "127.0.0.1", "--port", str(port)],
            cwd=FRONTEND,
            env=environment,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    pgid = os.getpgid(process.pid)
    _assert(pgid == process.pid, "Next process group is not owned by fixture")
    return process, pgid


def _wait_for_next(port: int, process: subprocess.Popen[bytes], pgid: int) -> None:
    deadline = time.monotonic() + START_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        _assert(process.poll() is None, "Next exited before readiness")
        listeners = _listener_pids(port)
        if listeners:
            try:
                owned = all(os.getpgid(pid) == pgid for pid in listeners)
            except ProcessLookupError:
                owned = False
            if owned:
                try:
                    with socket.create_connection(("127.0.0.1", port), timeout=3):
                        return
                except OSError:
                    pass
        time.sleep(0.25)
    raise FixtureFailure("Next readiness timeout")


def _write_session_cookie(label: str, email: str, name: str, jwt_secret: str) -> None:
    output = ROOT / f"{label}.cookies.json"
    script = (
        "const fs=require('fs');const {encode}=require('next-auth/jwt');"
        "encode({token:{email:process.env.QA_EMAIL,name:process.env.QA_NAME,sub:'infra064'},"
        "secret:process.env.QA_SECRET,maxAge:1800}).then(value=>fs.writeFileSync(process.env.QA_OUTPUT,"
        "JSON.stringify([{name:'next-auth.session-token',value,domain:'localhost',path:'/',httpOnly:true,"
        "secure:false,sameSite:'Lax'}]),{mode:0o600})).catch(()=>process.exit(1));"
    )
    environment = _safe_child_environment()
    environment.update(QA_EMAIL=email, QA_NAME=name, QA_SECRET=jwt_secret, QA_OUTPUT=str(output))
    completed = subprocess.run(
        ["node", "-e", script], cwd=FRONTEND, env=environment,
        capture_output=True, text=True, timeout=15,
    )
    _assert(completed.returncode == 0 and output.is_file(), "synthetic NextAuth JWT creation failed")
    _assert(not completed.stdout, "JWT creator unexpectedly wrote stdout")


def _fixture_gate_payload() -> dict[str, Any]:
    now = datetime.now()
    return {
        "total_score": 72,
        "status": "GREEN",
        "dataset_date": now.strftime("%Y-%m-%d"),
        "timestamp": now.isoformat(),
        "sectors": [{"name": "격리 QA", "change_pct": 1.2, "signal": "bullish"}],
        "indices": {"kospi": {"value": 2700, "change_pct": 0.1}, "kosdaq": {"value": 850, "change_pct": 0.2}},
    }


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the isolated INFRA-064 browser fixture")
    parser.add_argument("--flask-port", type=int, help="owned Flask loopback port")
    parser.add_argument("--next-port", type=int, help="owned Next loopback port")
    return parser.parse_args(argv)


def _requested_port(value: int | None, name: str) -> int:
    if value is None:
        return _free_loopback_port()
    _assert(1 < value < 65536 and value not in {3500, 5501}, f"invalid {name} port")
    _assert(not _listener_pids(value), f"requested {name} port is already listening")
    return value


def main(argv: list[str] | None = None) -> int:
    arguments = _parse_args(argv)
    _assert(CLONE.is_dir() and FRONTEND.is_dir(), "isolated checkout is missing")
    _assert_no_runtime_secrets()
    # app.__init__ calls load_dotenv().  Start it with only inert process
    # basics, then inject the fixture identities used by both Next and Flask.
    safe_environment = _safe_child_environment()
    os.environ.clear()
    os.environ.update(safe_environment)
    DATA_DIR.mkdir(exist_ok=True)
    # A normal current snapshot lets both actual UI callers render before a
    # missing-current scenario is deliberately armed through fixture reset.
    # The dated record proves a historical GET remains a read-only lookup.
    _write_json_atomic(DATA_DIR / "market_gate.json", _fixture_gate_payload())
    historical_gate = _fixture_gate_payload()
    historical_gate.update(total_score=31, status="RED", dataset_date="1999-01-01", timestamp="1999-01-01T15:40:00")
    _write_json_atomic(DATA_DIR / "market_gate_19990101.json", historical_gate)
    identity_secret = secrets.token_urlsafe(32)
    jwt_secret = secrets.token_urlsafe(32)
    # Flask verifies the header itself and admin_helpers reads this process's
    # environment.  Both values are synthetic and exist only in this runner.
    os.environ["INTERNAL_IDENTITY_SECRET"] = identity_secret
    os.environ["ADMIN_EMAILS"] = ADMIN_EMAIL
    os.environ["SCHEDULER_ENABLED"] = "false"
    base_clock = time.time()
    state: dict[str, Any] = {
        "mode": "success", "hold": False, "clock_offset_seconds": 0.0,
        "analysis_count": 0, "save_count": 0, "api_requests": [], "control_events": [],
    }
    hold_started = threading.Event()
    release_hold = threading.Event()
    metrics_lock = threading.RLock()

    def _snapshot_unlocked() -> dict[str, Any]:
        return {
            "mode": state["mode"], "hold": state["hold"],
            "clock_offset_seconds": state["clock_offset_seconds"],
            "analysis_count": state["analysis_count"], "save_count": state["save_count"],
            "api_requests": list(state["api_requests"]),
            "control_events": list(state["control_events"]),
            "hold_started": hold_started.is_set(), "release_hold": release_hold.is_set(),
        }

    def snapshot() -> dict[str, Any]:
        with metrics_lock:
            return _snapshot_unlocked()

    def save_metrics() -> None:
        # Flask request and daemon analysis threads both write this evidence.
        # One lock covers the shared state and the fixed .tmp replacement path.
        with metrics_lock:
            _write_json_atomic(METRICS, _snapshot_unlocked())

    # App imports must happen only after the isolated clone's dotenv policy is checked.
    sys.path.insert(0, str(CLONE))
    from app import _register_request_context
    from app.routes import kr_market
    from app.routes.kr_market_system_http_routes import _register_market_gate_routes
    from services import kr_market_market_gate_validity as validity

    class SyntheticMarketGate:
        def analyze(self) -> dict[str, Any]:
            with metrics_lock:
                state["analysis_count"] += 1
            save_metrics()
            with metrics_lock:
                hold = bool(state["hold"])
            if hold:
                hold_started.set()
                save_metrics()
                if not release_hold.wait(timeout=120):
                    raise RuntimeError("fixture hold timed out")
            with metrics_lock:
                mode = str(state["mode"])
            if mode == "fail":
                raise RuntimeError("synthetic MarketGate failure")
            return _fixture_gate_payload()

        def save_analysis(self, result: dict[str, Any]) -> None:
            with metrics_lock:
                state["save_count"] += 1
            _write_json_atomic(DATA_DIR / "market_gate.json", result)
            save_metrics()

    # The production trigger imports engine.market_gate inside its worker.  Only
    # that import is replaced; the actual lock/cooldown/threading code remains.
    synthetic_module = ModuleType("engine.market_gate")
    synthetic_module.MarketGate = SyntheticMarketGate
    sys.modules["engine.market_gate"] = synthetic_module
    kr_market.DATA_DIR = str(DATA_DIR)
    kr_market.is_market_gate_updating = False
    kr_market._market_gate_process_lock_handle = None
    # INFRA-064 injects this clock seam; retaining the real 300-second duration.
    kr_market._market_gate_now = lambda: base_clock + float(state["clock_offset_seconds"])

    app = Flask("infra064_browser_fixture")
    _register_request_context(app)

    @app.after_request
    def record_response(response: Response) -> Response:
        if request.path.startswith("/api/"):
            payload = response.get_json(silent=True)
            summary = {
                key: payload[key]
                for key in ("status", "score", "message")
                if isinstance(payload, dict) and key in payload
            }
            with metrics_lock:
                state["api_requests"].append({
                    "method": request.method, "path": request.path,
                    "query": request.query_string.decode("ascii", "replace"),
                    "response_status": response.status_code,
                    "response": summary,
                })
            save_metrics()
        return response

    @app.get("/api/admin/check")
    def admin_check() -> Response:
        from flask import g
        from services.admin_helpers import is_admin_email

        return jsonify(isAdmin=is_admin_email(g.get("user_email")))

    @app.get("/api/kr/signals")
    def signals() -> Response:
        return jsonify(signals=[], total_scanned=0, generated_at=datetime.now().isoformat())

    @app.get("/api/kr/status")
    def status() -> Response:
        return jsonify(status="success", data={"last_update": None, "collected_stocks": 0, "signals_count": 0, "market_status": "fixture", "files": {}})

    @app.get("/api/kr/backtest-summary")
    def backtest_summary() -> Response:
        return jsonify({})

    @app.get("/api/kr/config/interval")
    def interval() -> Response:
        return jsonify(interval=30)

    @app.get("/api/kr/signals/status")
    def vcp_status() -> Response:
        return jsonify(running=False, status="idle", message="", progress=0)

    @app.get("/api/kr/signals/dates")
    def signal_dates() -> Response:
        return jsonify([])

    @app.get("/api/kr/ai-analysis")
    def ai_analysis() -> Response:
        return jsonify(signals=[], analyses={})

    @app.get("/api/system/data-status")
    @app.get("/api/system/update-status")
    def system_status() -> Response:
        return jsonify(files=[], update_status={"isRunning": False}, isRunning=False)

    @app.post("/fixture/control")
    def fixture_control() -> Response:
        payload = request.get_json(silent=True) or {}
        event = str(payload.get("event", "snapshot"))
        if event == "mode":
            mode = str(payload.get("mode", ""))
            if mode not in {"success", "fail"}:
                return jsonify(error="mode must be success or fail"), 400
            with metrics_lock:
                state["mode"] = mode
        elif event == "hold":
            with metrics_lock:
                state["hold"] = True
            release_hold.clear()
            hold_started.clear()
        elif event == "release":
            with metrics_lock:
                state["hold"] = False
            release_hold.set()
        elif event == "advance":
            with metrics_lock:
                state["clock_offset_seconds"] += float(payload.get("seconds", 0))
        elif event == "reset":
            if kr_market.is_market_gate_updating:
                return jsonify(error="cannot reset an active fixture analysis"), 409
            lock_path = DATA_DIR / ".market_gate_refresh.lock"
            if lock_path.exists():
                lock_path.unlink()
            (DATA_DIR / "market_gate.json").unlink(missing_ok=True)
            with metrics_lock:
                state["clock_offset_seconds"] = 0.0
                state["analysis_count"] = 0
                state["save_count"] = 0
                state["api_requests"] = []
        elif event != "snapshot":
            return jsonify(error="unsupported fixture event"), 400
        with metrics_lock:
            state["control_events"].append({"event": event, "at": datetime.now().isoformat()})
        save_metrics()
        return jsonify(snapshot())

    # Registration includes the production POST route because its registrar owns
    # both endpoints.  Its injected executor is inert 405; no update, LLM,
    # data collection or real write route is reachable in this fixture.
    gate_bp = Blueprint("infra064_market_gate", __name__)
    _register_market_gate_routes(
        gate_bp,
        logger=app.logger,
        deps={
            "resolve_market_gate_filename": validity.resolve_market_gate_filename,
            "load_json_file": lambda filename, **_kwargs: json.loads((DATA_DIR / filename).read_text(encoding="utf-8")) if (DATA_DIR / filename).is_file() else {},
            "evaluate_market_gate_validity": validity.evaluate_market_gate_validity,
            "apply_market_gate_snapshot_fallback": validity.apply_market_gate_snapshot_fallback,
            "trigger_market_gate_background_refresh": kr_market._trigger_market_gate_background_refresh,
            "build_market_gate_initializing_payload": validity.build_market_gate_initializing_payload,
            "build_market_gate_empty_payload": validity.build_market_gate_empty_payload,
            "normalize_market_gate_payload": validity.normalize_market_gate_payload,
            "execute_market_gate_update": lambda **_kwargs: (405, {"error": "fixture excludes update route"}),
        },
    )
    app.register_blueprint(gate_bp, url_prefix="/api/kr")

    flask_port = _requested_port(arguments.flask_port, "Flask")
    next_port = _requested_port(arguments.next_port, "Next")
    _assert(flask_port != next_port, "Flask and Next ports must differ")
    server: BaseWSGIServer | None = None
    thread: threading.Thread | None = None
    next_process: subprocess.Popen[bytes] | None = None
    next_pgid: int | None = None
    cleanup_errors: list[Exception] = []
    try:
        server = make_server("127.0.0.1", flask_port, app)
        thread = threading.Thread(target=server.serve_forever, name="infra064-flask-fixture", daemon=True)
        thread.start()
        next_process, next_pgid = _start_next(next_port, flask_port, identity_secret, jwt_secret)
        _wait_for_next(next_port, next_process, next_pgid)
        _write_session_cookie("admin", ADMIN_EMAIL, "INFRA-064 Admin", jwt_secret)
        _write_session_cookie("viewer", VIEWER_EMAIL, "INFRA-064 Viewer", jwt_secret)
        save_metrics()
        _write_json_atomic(READY, {
            "url": f"http://localhost:{next_port}/dashboard/kr",
            "vcp_url": f"http://localhost:{next_port}/dashboard/kr/vcp",
            "flask_port": flask_port, "next_port": next_port,
            "next_pid": next_process.pid, "next_pgid": next_pgid,
            "cookie_file": str(ROOT / "admin.cookies.json"),
            "admin_cookie": str(ROOT / "admin.cookies.json"),
            "viewer_cookie": str(ROOT / "viewer.cookies.json"),
            "cookie_files": {
                "admin": str(ROOT / "admin.cookies.json"),
                "viewer": str(ROOT / "viewer.cookies.json"),
            },
            "control_url": f"http://127.0.0.1:{flask_port}/fixture/control",
            "metrics": str(METRICS),
        })
        print("INFRA-064 fixture ready", flush=True)
        deadline = time.monotonic() + LIFETIME_SECONDS
        while not STOP.exists():
            if time.monotonic() >= deadline:
                raise TimeoutError("fixture lifetime expired")
            time.sleep(0.2)
        return 0
    finally:
        release_hold.set()
        analysis_deadline = time.monotonic() + 10
        while kr_market.is_market_gate_updating and time.monotonic() < analysis_deadline:
            time.sleep(0.05)
        if kr_market.is_market_gate_updating:
            cleanup_errors.append(FixtureFailure("owned analysis thread did not finish"))
        try:
            if next_process is not None and next_pgid is not None:
                _terminate_next(next_process, next_pgid, next_port)
        except Exception as error:
            cleanup_errors.append(error)
        try:
            if server is not None:
                server.shutdown()
                if thread is not None:
                    thread.join(timeout=10)
                server.server_close()
        except Exception as error:
            cleanup_errors.append(error)
        cleanup = {
            "next_stopped": not _listener_pids(next_port),
            "flask_stopped": not _listener_pids(flask_port),
            "flask_thread_stopped": thread is None or not thread.is_alive(),
            "analysis_stopped": not kr_market.is_market_gate_updating,
            "errors": [type(error).__name__ for error in cleanup_errors],
        }
        _write_json_atomic(ROOT / "cleanup.json", cleanup)
        if cleanup_errors or not all((cleanup["next_stopped"], cleanup["flask_stopped"], cleanup["flask_thread_stopped"], cleanup["analysis_stopped"])):
            raise FixtureFailure("fixture cleanup did not reach terminal state")


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"INFRA-064 fixture failed: {type(error).__name__}", file=sys.stderr)
        raise
