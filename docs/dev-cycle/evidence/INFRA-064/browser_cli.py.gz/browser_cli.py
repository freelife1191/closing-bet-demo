from pathlib import Path
import json, os, subprocess, sys, time
root=Path(__file__).resolve().parent
session=sys.argv[1]
assert session in {"admin","viewer"}
args=sys.argv[2:]
env={k:os.environ[k] for k in ["PATH","HOME","USER","LOGNAME","LANG","LC_ALL","SHELL","TMPDIR"] if k in os.environ}
base=["/opt/homebrew/bin/gtimeout","-k","5s","60s","agent-browser","--namespace","devcycle-infra064-9f4s45","--session",session,"--config",str(root/"browser-config.json")]
port=json.loads((root/"proxy-ready.json").read_text())["port"]
base += ["--profile",str(root/("browser-"+session+"-064")),"--allowed-domains","localhost,127.0.0.1","--proxy",f"http://127.0.0.1:{port}","--proxy-bypass","localhost;127.0.0.1","--args","--disable-background-networking,--disable-component-update,--disable-default-apps,--disable-sync,--no-first-run,--disable-quic,--dns-prefetch-disable,--force-webrtc-ip-handling-policy=disable_non_proxied_udp"]
if args==["launch"]:
    args=["open",json.loads((root/"ready.json").read_text())["url"]]
start=time.monotonic()
r=subprocess.run(base+args,env=env,capture_output=True,text=True)
with (root/"browser-commands.jsonl").open("a") as f:
    f.write(json.dumps({"at":time.time(),"session":session,"args":args,"exit":r.returncode,"seconds":round(time.monotonic()-start,2),"stdout":r.stdout,"stderr":r.stderr},ensure_ascii=False)+"\n")
print(r.stdout,end="");print(r.stderr,end="",file=sys.stderr)
raise SystemExit(r.returncode)

