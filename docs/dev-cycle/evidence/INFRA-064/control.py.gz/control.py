from pathlib import Path
import sys,json,http.client
P=Path(__file__).resolve().parent
ready=json.loads((P/'ready.json').read_text());port=ready['flask_port']
assert port not in [3500,5501]
payload=json.loads(sys.argv[1]);c=http.client.HTTPConnection('127.0.0.1',port,timeout=10)
c.request('POST','/fixture/control',body=json.dumps(payload),headers={'Content-Type':'application/json'})
r=c.getresponse();d=json.loads(r.read());c.close()
with (P/'control-log.jsonl').open('a') as f:f.write(json.dumps({'input':payload,'status':r.status,'output':d},ensure_ascii=False)+'\n')
assert r.status==200,r.status
print(json.dumps({k:d[k] for k in ['mode','hold','analysis_count','save_count','clock_offset_seconds']}))
