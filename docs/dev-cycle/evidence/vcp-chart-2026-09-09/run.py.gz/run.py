import subprocess,sys,time,json,pathlib,os
p=pathlib.Path(__file__).parent; c=p/'checkout'; label=sys.argv[1]; cwd=c/('frontend' if sys.argv[2]=='front' else '.'); args=sys.argv[3:]; start=time.time(); env=os.environ.copy()
for key in list(env):
 if key.startswith(('OMX_','OMC_')): env.pop(key)
log=c/'docs/dev-cycle/evidence/vcp-chart-2026-09-09'/f'{label}.log'
with log.open('w') as f:
 try: code=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240).returncode
 except subprocess.TimeoutExpired: code=124
meta={'command':args,'cwd':str(cwd),'exit':code,'seconds':round(time.time()-start,2),'timeout':240}
log.with_suffix('.json').write_text(json.dumps(meta,indent=2)); print(json.dumps(meta)); print(''.join(log.read_text().splitlines(True)[-12:])); sys.exit(code)
