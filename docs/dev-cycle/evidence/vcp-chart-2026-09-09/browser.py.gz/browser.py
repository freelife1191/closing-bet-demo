import subprocess,sys,pathlib,json,time,os
p=pathlib.Path(__file__).parent; q=p/'qa'; e=p/'checkout/docs/dev-cycle/evidence/vcp-chart-2026-09-09'; proxy=json.loads((q/'proxy-ready.json').read_text()); env=os.environ.copy()
for key in list(env):
 if key.startswith(('OMX_','OMC_')): env.pop(key)
args=['agent-browser','--namespace','devcycle-vcp-z89pj2p2','--session','viewer','--profile',str(q/'browser-profile'),'--proxy',f"http://127.0.0.1:{proxy['port']}",'--proxy-bypass','127.0.0.1,localhost','--allowed-domains','127.0.0.1,localhost']+sys.argv[1:]
stdin=sys.stdin.read() if '--stdin' in args else None
try: r=subprocess.run(args,input=stdin,text=True,capture_output=True,env=env,timeout=40); code=r.returncode; output=r.stdout+r.stderr
except subprocess.TimeoutExpired: code=124; output='browser command timeout'
with (e/'browser-commands.jsonl').open('a') as f: f.write(json.dumps({'at':time.time(),'args':sys.argv[1:],'stdin':stdin,'exit':code,'output':output},ensure_ascii=False)+'\n')
print(output);sys.exit(code)
