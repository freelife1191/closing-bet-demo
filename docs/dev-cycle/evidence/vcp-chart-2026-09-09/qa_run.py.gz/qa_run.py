import pathlib,subprocess,json,sys,time
p=pathlib.Path(__file__).resolve().parent;e=p/'checkout/docs/dev-cycle/evidence/vcp-chart-2026-09-09';name=sys.argv[1];start=time.time()
r=subprocess.run([sys.executable,str(p/'qa_cases.py'),name],capture_output=True,text=True,timeout=120)
(e/f'case-{name}.log').write_text(r.stdout+r.stderr);meta={'scenario':name,'exit':r.returncode,'seconds':time.time()-start,'timeout':120,'source':'qa_cases.py via agent-browser','cycle':2};(e/f'case-{name}.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta));print((r.stdout+r.stderr)[-2000:]);sys.exit(r.returncode)
