import pathlib,subprocess,sys,json,re,time
P=pathlib.Path(__file__).resolve().parent; Q=P/'qa'; E=P/'checkout/docs/dev-cycle/evidence/vcp-chart-2026-09-09'
def ab(*args,stdin=None):
 r=subprocess.run([sys.executable,str(P/'browser.py'),*map(str,args)],input=stdin,capture_output=True,text=True,timeout=45)
 if r.returncode: raise RuntimeError(r.stdout+r.stderr)

 if args[:2]==('set','viewport'): time.sleep(.5)
 return r.stdout.strip()
def js(code): return json.loads(ab('eval','--stdin',stdin=code))
def snap(): return ab('snapshot','-i')
def click(pattern):
 tree=snap(); lines=[l for l in tree.splitlines() if re.search(pattern,l)]
 assert len(lines)==1,(pattern,lines)
 ref=re.search(r'\[ref=(e\d+)\]',lines[0]); assert ref,lines
 result=ab('click','@'+ref[1])
 if '차트 닫기' in pattern:
  ab('wait','--fn',"!document.querySelector('button[aria-label=\"차트 닫기\"]')")
  time.sleep(.15)
 return result
def mode(name):
 r=subprocess.run([sys.executable,str(Q/'qa_fixture.py'),'set-mode',name],capture_output=True,text=True,timeout=5); assert r.returncode==0,r.stderr

def release(): (Q/'release-chart').write_text('release\n')
def wait_chart(): ab('wait','--fn',"!document.body.innerText.includes('Loading chart data...') && [...document.querySelectorAll('h3')].some(e=>e.innerText.includes('(267260)')||e.innerText.includes('(012450)'))")
def measure():
 return js('''(()=>{const title=[...document.querySelectorAll('h3')].find(e=>/\\((267260|012450)\\)/.test(e.textContent));if(!title)return {open:false};const modal=title.parentElement.parentElement.parentElement,left=modal.children[0],right=modal.children[1];const rect=e=>{if(!e)return null;const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right}};const label=[...left.querySelectorAll('span')].find(e=>e.textContent==='전반부:'); const sma=[...left.querySelectorAll('span')].find(e=>e.textContent==='이동평균선 토글 ' || e.textContent.trim()==='이동평균선 토글'); const canvas=left.querySelector('.tv-lightweight-charts');return {open:true,title:title.textContent,modal:rect(modal),horizontalOverflow:modal.scrollWidth-modal.clientWidth,chart:rect(canvas),sma:rect(sma?.parentElement?.parentElement?.parentElement),info:rect(label?.parentElement?.parentElement),ai:rect(right),high:label?.nextElementSibling?.textContent,low:[...left.querySelectorAll('span')].find(e=>e.textContent==='후반부:')?.nextElementSibling?.textContent,loading:modal.innerText.includes('Loading chart data...'),empty:modal.innerText.includes('No chart data available.'),error:!!modal.querySelector('[role=alert]'),period:[...left.querySelectorAll('button[aria-pressed=true]')].map(e=>e.textContent),gaps:left.querySelector('details')?.textContent,canvases:left.querySelectorAll('canvas').length};})()''')
def capture(name):
 wait_chart(); js('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(true))))'); ab('wait',150); m=measure(); (E/f'{name}.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));(E/f'{name}.snapshot.txt').write_text(snap());ab('screenshot',str(E/f'{name}.png'));(E/f'{name}.errors.txt').write_text(ab('errors'));(E/f'{name}.console.txt').write_text(ab('console'));print(name,json.dumps(m,ensure_ascii=False));return m

def begin():
 ab('console','--clear');ab('errors','--clear')

def main(case):
 begin()
 if case=='normal':
  click(r'  - cell "HD현대');m=capture(case);assert m['high']=='₩430,200',m
 elif case=='mobile':
  ab('set','viewport','375','812');m=capture(case);assert m['horizontalOverflow']<=1,m
  assert m['chart']['bottom']<=m['sma']['y']+1 and m['sma']['bottom']<=m['info']['y']+1 and m['info']['bottom']<=m['ai']['y']+1,m
  click(r'button "120일선"');m=capture('mobile-sma'); assert m['canvases']>0
 elif case=='history':
  
  if measure().get('open'): click(r'button "차트 닫기"')
  ab('set','viewport','1280','900');ab('wait',300);click(r'button "과거"');click(r'button "2026-05-05"');click(r'  - cell "HD현대')
  results=[]
  for label,high in [('1개월','₩410,400'),('3개월','₩430,200'),('6개월','₩459,900'),('1년','₩513,900')]:
   click(r'button "'+label+'"'); wait_chart();m=measure();assert m['high']==high and m['period']==[label],m;results.append(m)
  (E/'period-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));capture('history-year')
 elif case=='gap':
  mode('gap');click(r'button "3개월"');wait_chart();tree=snap();(E/'gap-before.snapshot.txt').write_text(tree);print(tree)
 elif case=='gap-open':
  assert js("document.querySelectorAll('summary').length")==1;ab('click','summary');m=capture('gap-desktop');assert '2026-03-06 → 2026-04-30: 55일' in m['gaps'],m
  ab('set','viewport','375','812');m=capture('gap-mobile'); assert m['info']['bottom']<=m['ai']['y']+1,m
 elif case=='multiple-gaps':
  mode('gap');click(r'button "1년"');wait_chart();ab('click','summary');m=capture('multiple-gaps');assert '2026-01-14 → 2026-01-29: 15일' in m['gaps'] and '2026-03-06 → 2026-04-30: 55일' in m['gaps'],m
 elif case=='empty-single-fail':
  results=[]
  for mode_name in ['empty','single','fail','normal']:
   mode(mode_name);click(r'button "다시 시도"' if mode_name=='normal' else r'button "1개월"');wait_chart(); m=measure();results.append({'mode':mode_name,**m});assert m['empty']==(mode_name=='empty') and m['error']==(mode_name=='fail'),m
   if mode_name in ['empty','single','fail']: capture(mode_name)
  (E/'empty-single-fail.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));capture('recovered')
 elif case=='race':
  
  if measure().get('open'): click(r'button "차트 닫기"')
  ab('set','viewport','1280','900');mode('delayed');(Q/'release-chart').unlink(missing_ok=True)
  click(r'  - cell "HD현대');assert measure()['loading'];click(r'button "차트 닫기"');mode('normal');click(r'  - cell "한화');wait_chart();before=measure(); release()
  ab('wait','--fn',"!document.body.innerText.includes('Loading chart data...')")
  deadline=time.time()+3
  while time.time()<deadline:
   records=[json.loads(l) for l in (Q/'requests.jsonl').read_text().splitlines()]
   if any(r.get('chart_delay_released') for r in records):break
   time.sleep(.1)
  ab('wait',250);after=capture('race');assert before['high']==after['high'] and '012450' in after['title'],(before,after)
  (E/'race-results.json').write_text(json.dumps({'before':before,'after':after,'records':records[-10:]},ensure_ascii=False,indent=2))
 elif case=='race-failure':
  click(r'button "차트 닫기"');mode('delayed')
  for file in Q.glob('release-chart*'): file.unlink()
  control=json.loads((Q/'control.json').read_text());control['delay_result']='fail';(Q/'control.json').write_text(json.dumps(control))
  click(r'  - cell "HD현대');click(r'button "차트 닫기"')
  control['delay_result']='success';(Q/'control.json').write_text(json.dumps(control))
  click(r'  - cell "한화');(Q/'release-chart-267260').write_text('release')
  ab('wait',300);pending=measure();assert pending['loading'] and not pending['error'],pending
  (Q/'release-chart-012450').write_text('release');wait_chart();m=capture('race-failure');assert not m['error'] and '012450' in m['title'],m
  (E/'race-failure-results.json').write_text(json.dumps({'pending':pending,'complete':m},ensure_ascii=False,indent=2))
 elif case=='race-period':
  click(r'button "차트 닫기"');mode('normal');click(r'  - cell "HD현대');wait_chart();mode('delayed')
  for file in Q.glob('release-chart*'): file.unlink()
  click(r'button "1개월"');mode('normal');click(r'button "1년"');wait_chart();before=measure();release();ab('wait',300);after=capture('race-period');assert after['high']=='₩513,900' and after['period']==['1년'] and before['high']==after['high'],after
 elif case=='long':
  
  if measure().get('open'): click(r'button "차트 닫기"')
  mode('long');ab('reload');ab('wait','--text','HD현대');ab('set','viewport','375','812');click(r'  - cell "HD현대');m=capture('long-mobile');assert m['horizontalOverflow']<=1 and m['info']['bottom']<=m['ai']['y']+1,m
 elif case=='resize':
  ab('set','viewport','1280','900');m=capture('resized');assert m['horizontalOverflow']<=1 and m['chart']['height']>100,m
 else: raise ValueError(case)
if __name__=='__main__': main(sys.argv[1])
