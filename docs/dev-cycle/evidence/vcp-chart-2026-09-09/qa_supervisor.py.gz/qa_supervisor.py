#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VCP QA의 소유 프로세스만 시작·종료하는 supervisor. 기본 동작은 실행하지 않는다."""

from __future__ import annotations

import argparse
import json
import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
CHECKOUT = ROOT.parent / "checkout"
FRONTEND = CHECKOUT / "frontend"
FIXTURE = ROOT / "qa_fixture.py"
FAKE_ENV = ROOT / "fake.env"
RUNTIME = ROOT / "runtime.json"
BACKEND_LOG = ROOT / "backend.log"
NEXT_LOG = ROOT / "next.log"
LOCAL_ONLY = ROOT / "local-only.sb"
BACKEND_PORT = 57261
NEXT_PORT = 57262


class SupervisorError(RuntimeError):
    """소유 증명 없는 프로세스 조작을 막는다."""


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise SupervisorError(message)


def _safe_env() -> dict[str, str]:
    allowed = ("PATH", "HOME", "USER", "LOGNAME", "SHELL", "TMPDIR", "TMP", "TEMP", "LANG", "LC_ALL", "TZ")
    return {key: os.environ[key] for key in allowed if key in os.environ}


def _fixture_env() -> dict[str, str]:
    _assert(FAKE_ENV.is_file() and not FAKE_ENV.is_symlink(), "먼저 qa_fixture.py prepare를 실행하세요")
    values: dict[str, str] = {}
    for line in FAKE_ENV.read_text(encoding="utf-8").splitlines():
        if line and "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    required = {"NEXTAUTH_SECRET", "NEXTAUTH_URL", "API_URL", "INTERNAL_IDENTITY_SECRET"}
    _assert(required <= values.keys(), "fake.env가 불완전합니다")
    return values


def _listeners(port: int) -> list[int]:
    result = subprocess.run(["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-Fp"], capture_output=True, text=True, check=False)
    _assert(result.returncode in {0, 1}, "lsof 실행에 실패했습니다")
    return [int(line[1:]) for line in result.stdout.splitlines() if line.startswith("p")]


def _wait(port: int, process: subprocess.Popen[bytes], label: str) -> None:
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise SupervisorError(f"{label}이 readiness 전에 종료했습니다")
        if _listeners(port):
            with socket.socket() as probe:
                probe.settimeout(1)
                if probe.connect_ex(("127.0.0.1", port)) == 0:
                    return
        time.sleep(0.2)
    raise SupervisorError(f"{label} readiness가 120초를 넘었습니다")


def _spawn(command: list[str], cwd: Path, log: Path, env: dict[str, str]) -> subprocess.Popen[bytes]:
    output = log.open("ab")
    return subprocess.Popen(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)


def _group_members(pgid: int) -> list[int]:
    result = subprocess.run(["ps", "-axo", "pid=,pgid="], capture_output=True, text=True, check=False)
    return [int(line.split()[0]) for line in result.stdout.splitlines() if len(line.split()) == 2 and int(line.split()[1]) == pgid]


def _cwd(pid: int) -> str | None:
    result = subprocess.run(["lsof", "-a", "-p", str(pid), "-d", "cwd", "-Fn"], capture_output=True, text=True, check=False)
    return next((line[1:] for line in result.stdout.splitlines() if line.startswith("n")), None)


def _command(pid: int) -> str | None:
    result = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True, check=False)
    command = result.stdout.strip()
    return command or None


def _owned(record: dict[str, Any]) -> bool:
    try:
        pid, pgid, port = int(record["pid"]), int(record["pgid"]), int(record["port"])
        listeners = _listeners(port)
        command = _command(pid)
        return (
            os.getpgid(pid) == pgid
            and _cwd(pid) == record["cwd"]
            and command is not None and str(record["command_token"]) in command
            and bool(listeners) and all(os.getpgid(listener) == pgid for listener in listeners)
        )
    except ProcessLookupError:
        return False


def start() -> int:
    _assert(not RUNTIME.exists(), "runtime.json이 남아 있습니다. 먼저 stop을 실행하세요")
    _assert(not _listeners(BACKEND_PORT) and not _listeners(NEXT_PORT), "57261/57262 중 하나가 이미 사용 중입니다")
    _assert(Path("/usr/bin/sandbox-exec").is_file() and LOCAL_ONLY.is_file(), "sandbox-exec 정책이 없습니다")
    prepare = subprocess.run([sys.executable, str(FIXTURE), "prepare"], cwd=ROOT, env=_safe_env(), capture_output=True, text=True, check=False)
    _assert(prepare.returncode == 0, "fixture prepare에 실패했습니다")
    env = {**_safe_env(), **_fixture_env()}
    backend = _spawn(["/usr/bin/sandbox-exec", "-f", str(LOCAL_ONLY), sys.executable, str(FIXTURE), "serve", "--port", str(BACKEND_PORT)], CHECKOUT, BACKEND_LOG, env)
    try:
        _wait(BACKEND_PORT, backend, "synthetic HTTP")
        next_process = _spawn(["/usr/bin/sandbox-exec", "-f", str(LOCAL_ONLY), "npm", "run", "dev", "--", "--port", str(NEXT_PORT), "--hostname", "127.0.0.1"], FRONTEND, NEXT_LOG, env)
        _wait(NEXT_PORT, next_process, "Next VCP")
    except Exception:
        for process in (backend, locals().get("next_process")):
            if process is not None and process.poll() is None:
                os.killpg(os.getpgid(process.pid), signal.SIGTERM)
        raise
    _private = {
        "backend": {"pid": backend.pid, "pgid": os.getpgid(backend.pid), "port": BACKEND_PORT, "cwd": str(CHECKOUT), "command_token": "qa_fixture.py"},
        "next": {"pid": next_process.pid, "pgid": os.getpgid(next_process.pid), "port": NEXT_PORT, "cwd": str(FRONTEND), "command_token": "npm"},
        "url": f"http://127.0.0.1:{NEXT_PORT}/dashboard/kr/vcp",
    }
    temporary = RUNTIME.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(_private, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    os.replace(temporary, RUNTIME)
    print(json.dumps({"started": True, "backend_port": BACKEND_PORT, "next_port": NEXT_PORT, "synthetic_api": True}))
    return 0


def stop() -> int:
    _assert(RUNTIME.is_file() and not RUNTIME.is_symlink(), "runtime.json이 없습니다")
    runtime = json.loads(RUNTIME.read_text(encoding="utf-8"))
    records = [runtime["backend"], runtime["next"]]
    for record in records:
        _assert(_owned(record), "fixture 소유 프로세스 증명이 실패했습니다")
    for record in records:
        os.killpg(int(record["pgid"]), signal.SIGTERM)
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline and any(_group_members(int(record["pgid"])) for record in records):
        time.sleep(0.2)
    _assert(
        not any(_listeners(int(record["port"])) for record in records)
        and not any(_group_members(int(record["pgid"])) for record in records),
        "fixture process group 또는 listener가 남아 있습니다",
    )
    RUNTIME.unlink()
    print(json.dumps({"stopped": True}))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="VCP QA supervisor")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("start")
    commands.add_parser("stop")
    args = parser.parse_args()
    try:
        return start() if args.command == "start" else stop()
    except (SupervisorError, OSError, json.JSONDecodeError) as error:
        print(f"supervisor error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
