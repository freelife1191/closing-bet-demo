import json, os
from pathlib import Path
import pytest

@pytest.fixture(autouse=True)
def startup_probe(monkeypatch, tmp_path, request):
    if request.node.name != "test_gated_route_list_matches_reality":
        yield
        return
    import app as factory
    monkeypatch.chdir(tmp_path)
    data = tmp_path / "data"
    data.mkdir()
    names = ["update_status.json", "v2_screener_status.json", "scheduler_runtime_status.json"]
    for name in names:
        (data / name).write_text('{"isRunning":true,"items":["sentinel"]}')
    def snapshot():
        return {f.name: {"text":f.read_text(), "mtime_ns":f.stat().st_mtime_ns}
                for f in (data / name for name in names)}
    before = snapshot()
    scheduler_calls = []
    monkeypatch.setattr(factory, "_start_scheduler", lambda: scheduler_calls.append("called"))
    mutation = os.getenv("QA_MUTATION", "")
    if mutation:
        register = factory._register_blueprints
        def mutated_register(app):
            register(app)
            if mutation == "missing":
                rule = next(r for r in app.url_map.iter_rules() if str(r) == "/api/kr/refresh" and "POST" in r.methods)
                app.view_functions[rule.endpoint] = lambda: {"unguarded": True}
            elif mutation == "extra":
                from app.routes.route_guards import require_admin
                app.add_url_rule("/api/qa-only-extra", view_func=require_admin(lambda: {}), methods=["POST"])
        monkeypatch.setattr(factory, "_register_blueprints", mutated_register)
    yield
    after = snapshot()
    result = {"before":before,"after":after,"unchanged":before==after,
              "scheduler_calls":len(scheduler_calls),"mutation":mutation}
    Path(os.environ["QA_OBSERVATION"]).write_text(json.dumps(result, indent=2)+"\n")
    if os.getenv("QA_EXPECT_SAFE") == "1":
        assert before == after, "startup status files changed"
        assert not scheduler_calls, "scheduler entry reached"
