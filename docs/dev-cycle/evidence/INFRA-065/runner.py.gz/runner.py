import os,sys,json,time,subprocess,gzip
from pathlib import Path
P=Path(__file__).resolve().parent; C=P/'checkout'
name=sys.argv[1]; extra=sys.argv[2:]
env={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL','USER') if k in os.environ}
env.update(SCHEDULER_ENABLED='false', PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(P)+os.pathsep+str(C), QA_OBSERVATION=str(P/(name+'-observation.json')))
if name != 'baseline': env['QA_EXPECT_SAFE']='1'
if name in ('missing','extra'): env['QA_MUTATION']=name
args=extra or ['tests/app/test_admin_gated_routes.py::test_gated_route_list_matches_reality']
cmd=[str(C/'venv/bin/python'),'-B','-m','pytest','-p','probe_plugin','-q','-rs','--basetemp',str(P/('pytest-'+name)),*args]
start=time.time()
res=subprocess.run(['/usr/bin/sandbox-exec','-f',str(P/'no-network.sb'),*cmd],cwd=C,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
meta={'command':cmd,'exit':res.returncode,'seconds':round(time.time()-start,2),'timeout':120,'network':'deny all'}
(P/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
with gzip.open(P/(name+'.log.gz'),'wb') as f: f.write(res.stdout)
print(json.dumps(meta));print(res.stdout.decode(errors='replace')[-7000:]);sys.exit(res.returncode)
