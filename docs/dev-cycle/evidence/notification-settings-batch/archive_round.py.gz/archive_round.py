"""리더가 검증한 승인 라운드의 기록/통합만 수행하는 임시 도구."""
import datetime
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

p = Path(__file__).resolve().parent
c = p / 'checkout'
ident, base, implementation, qa_commit, title = sys.argv[1:]
assert ident in {'INFRA-057', 'INFRA-058', 'INFRA-051', 'FE-041'}
report = (c / f'docs/dev-cycle/qa/{ident}.md').read_text()
assert 'ULTRAQA COMPLETE: Goal met' in report and '- cleanup: complete' in report
assert '- phase: complete' in report
stats = {'code_add': 0, 'code_del': 0, 'doc_add': 0, 'doc_del': 0}
output = subprocess.check_output(['git', 'diff', '--numstat', base, qa_commit], cwd=c, text=True)
for line in output.splitlines():
    added, removed, path = line.split('\t', 2)
    if added == '-':
        continue
    kind = 'doc' if path.startswith('docs/') or path.endswith('.md') else 'code'
    stats[kind+'_add'] += int(added)
    stats[kind+'_del'] += int(removed)
todo = c / 'docs/dev-cycle/TODO.md'
text = todo.read_text()
start = text.index(f'### [{ident}]')
priority = re.findall(r'^## (P[012])', text[:start], re.M)[-1]
end = text.find('\n### [', start + 1)
if end < 0:
    end = len(text)
# 우선순위 제목이 다음 항목 전에 있으면 보존한다.
section = text[start:end]
heading = re.search(r'^## P[012]', section, re.M)
if heading:
    end = start + heading.start()
todo.write_text(text[:start] + text[end:].lstrip('\n'))
month = c / 'docs/dev-cycle/archive/2026-09.md'
text = month.read_text()
category = '프론트엔드' if ident.startswith('FE') else '인프라'
text = text.replace('## 통계', f'| 09-09 | {ident} | {title} | {category} | T3 | {implementation}, {qa_commit} |\n\n## 통계', 1)
def totals(match):
    values = [int(x) for x in match.groups()]
    values[0] += 1
    values[int(priority[1]) + 1] += 1
    return f'완료 {values[0]}건 (P0 {values[1]} · P1 {values[2]} · P2 {values[3]})'
text = re.sub(r'완료 (\d+)건 \(P0 (\d+) · P1 (\d+) · P2 (\d+)\)', totals, text, count=1)
def lines(match):
    code, added, removed = (int(x) for x in match.groups())
    return f"순 코드 증감 +{code+stats['code_add']-stats['code_del']}줄 (문서 +{added+stats['doc_add']} -{removed+stats['doc_del']})"
text = re.sub(r'순 코드 증감 \+(\d+)줄 \(문서 \+(\d+) -(\d+)\)', lines, text, count=1)
month.write_text(text)
daily = c / 'docs/dev-cycle/archive/daily/2026-09-09.md'
detail = (p / f'{ident}-archive-body.txt').read_text().rstrip()
daily.write_text(daily.read_text() + f"\n## [{ident}] {title}\n- 완료 {datetime.datetime.now():%Y-%m-%d %H:%M} | 티어 T3 | 커밋 {implementation}, {qa_commit}\n- 변경: 코드/회귀 +{stats['code_add']} -{stats['code_del']}, 문서/증거텍스트 +{stats['doc_add']} -{stats['doc_del']}. 구현/QA커밋 기준, 아카이브 자신과 binary 제외.\n" + detail + '\n')
subprocess.run(['git', 'add', '--', str(todo), str(month), str(daily)], cwd=c, check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=c, check=True)
subprocess.run(['git', 'commit', '-m', f'docs(dev-cycle): [{ident}] 실측 검증과 정리를 완료한다'], cwd=c, check=True)
owned = json.loads((p/'ownership.json').read_text())
root = Path(owned['root'])
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == owned['base']
assert subprocess.check_output(['git', 'status', '--short'], cwd=root, text=True).strip() == '?? package.json'
assert hashlib.sha256((root/'package.json').read_bytes()).hexdigest() == owned['user_package_sha256']
subprocess.run(['git', 'fetch', '--quiet', str(c), 'develop'], cwd=root, check=True)
subprocess.run(['git', 'merge', '--ff-only', 'FETCH_HEAD'], cwd=root, check=True, stdout=subprocess.DEVNULL)
owned['base'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
(p/'ownership.json').write_text(json.dumps(owned, indent=2))
print(json.dumps({'integrated': owned['base'], 'stats': stats}))
