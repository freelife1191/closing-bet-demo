#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""INFRA-063 Next proxy → bare Flask message JSON-boundary QA harness.

This runner is inert until an owner supplies the exact implementation commit.
It uses only temporary loopback servers, a temporary fixture/guard directory,
and fake NextAuth/identity secrets.  It never creates the application factory
or reads a dotenv/data file from the clone or source checkout.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import http.client
import json
import logging
import os
import secrets
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from flask import Flask
    from werkzeug.serving import BaseWSGIServer

import infra062_transport_support as support


ROOT = Path(__file__).resolve().parent / "checkout"
FRONTEND = ROOT / "frontend"
EVIDENCE_DIR = ROOT / "docs" / "dev-cycle" / "evidence" / "INFRA-063" / "transport"
PATH = "/api/kr/jongga-v2/message"
ADMIN = "infra063-admin@example.test"
USER = "infra063-user@example.test"
REQUEST_TIMEOUT_SECONDS = 10
HARNESS_TIMEOUT_SECONDS = 600
MAX_BODY_BYTES = 64 * 1024
UNSET = object()


class HarnessFailure(RuntimeError):
    """A non-secret assertion suitable for the preserved result JSON."""


@dataclass(frozen=True)
class HttpResult:
    status: int
    headers: dict[str, str]
    body: bytes


@dataclass
class RouteState:
    arrivals: int = 0
    load: int = 0
    construct: int = 0
    send: int = 0
    identities: list[str] = field(default_factory=list)
    resolved_targets: list[str | None] = field(default_factory=list)
    loaded_filenames: list[str] = field(default_factory=list)


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise HarnessFailure(message)


def _run_git(*args: str) -> str:
    return support._run_git(*args)


def _require_exact_commit(commit: str) -> None:
    _assert(_run_git("rev-parse", "--show-toplevel") == str(ROOT), "clone root mismatch")
    actual = _run_git("rev-parse", "HEAD")
    expected = _run_git("rev-parse", "--verify", f"{commit}^{{commit}}")
    _assert(actual == expected, "HEAD is not the requested implementation commit")
    paths = (
        "app/routes/kr_market_jongga_execution_routes.py",
        "tests/app/test_jongga_message_request_boundary.py",
    )
    tracked = support.subprocess.run(
        ["git", "ls-files", "--error-unmatch", *paths], cwd=ROOT, capture_output=True, text=True
    )
    _assert(tracked.returncode == 0, "message source/test is not tracked at requested commit")
    dirty = support.subprocess.run(
        ["git", "diff", "--quiet", "HEAD", "--", *paths], cwd=ROOT, capture_output=True
    )
    _assert(dirty.returncode == 0, "message source/test has uncommitted changes")


def _assert_no_runtime_secrets() -> None:
    support._assert_no_runtime_secrets()
    _assert(ROOT.resolve() == support.ROOT.resolve(), "support module clone root mismatch")
    forbidden_source = Path("/Users/freelife/vibe/lecture/hodu/closing-bet-demo").resolve()
    _assert(ROOT.resolve() != forbidden_source, "runner refuses the source checkout")


def _request(
    port: int,
    method: str,
    *,
    body: bytes | None = None,
    content_type: str | None = None,
    cookie: str | None = None,
    identity: str | None = None,
    sec_fetch_site: str | None = None,
) -> HttpResult:
    """Raw HTTP preserves absent MIME and does not follow redirects."""
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=REQUEST_TIMEOUT_SECONDS)
    try:
        connection.putrequest(method, PATH, skip_host=True, skip_accept_encoding=True)
        connection.putheader("Host", f"127.0.0.1:{port}")
        if cookie:
            connection.putheader("Cookie", f"next-auth.session-token={cookie}")
        if identity:
            connection.putheader("X-Auth-Identity", identity)
        if sec_fetch_site:
            connection.putheader("Sec-Fetch-Site", sec_fetch_site)
        if content_type is not None:
            connection.putheader("Content-Type", content_type)
        if body is not None:
            connection.putheader("Content-Length", str(len(body)))
        connection.endheaders(body)
        response = connection.getresponse()
        return HttpResult(
            status=response.status,
            headers={name.lower(): value for name, value in response.getheaders()},
            body=response.read(),
        )
    finally:
        connection.close()


def _make_jwt_cookie(email: str, secret: str, temporary: Path) -> str:
    token_file = temporary / f"{email.split('@', 1)[0]}.jwt"
    script = (
        "const fs=require('fs');const {encode}=require('next-auth/jwt');"
        "encode({token:{email:process.env.INFRA063_EMAIL,sub:'infra063-user'},"
        "secret:process.env.NEXTAUTH_SECRET,maxAge:600})"
        ".then(t=>fs.writeFileSync(process.env.INFRA063_TOKEN_FILE,t,{mode:0o600}))"
        ".catch(e=>{console.error(e.name);process.exit(1)});"
    )
    environment = support._safe_child_environment()
    environment.update(
        {
            "NEXTAUTH_SECRET": secret,
            "AUTH_SECRET": secret,
            "INFRA063_EMAIL": email,
            "INFRA063_TOKEN_FILE": str(token_file),
        }
    )
    completed = support.subprocess.run(
        ["node", "-e", script],
        cwd=FRONTEND,
        env=environment,
        capture_output=True,
        text=True,
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    _assert(completed.returncode == 0 and token_file.is_file(), "synthetic NextAuth JWT generation failed")
    _assert(not completed.stdout, "JWT generator unexpectedly wrote stdout")
    return token_file.read_text(encoding="utf-8").strip()


def _tree_digest(directory: Path) -> str:
    entries: list[str] = []
    if directory.exists():
        for item in sorted(directory.rglob("*")):
            if item.is_file():
                entries.append(f"{item.relative_to(directory)}:{hashlib.sha256(item.read_bytes()).hexdigest()}")
    return hashlib.sha256("\n".join(entries).encode("utf-8")).hexdigest()


def _create_bare_message_app(
    state: RouteState,
    fixture: Path,
    guard_dir: Path,
) -> tuple[Flask, Any]:
    """Register only real context/admin/message code against a temporary fixture."""
    from flask import Blueprint, Flask, request
    from app import _register_request_context
    from app.routes.kr_market_jongga_execution_routes import _register_jongga_message_route
    import engine.messenger as messenger_module

    app = Flask("infra063_message_transport")
    app.testing = True
    _register_request_context(app)

    @app.before_request
    def observe_flask_arrival() -> None:
        state.arrivals += 1
        identity = request.headers.get("X-Auth-Identity")
        if identity:
            state.identities.append(identity)

    class DummyMessenger:
        def __init__(self) -> None:
            state.construct += 1

        def send_screener_result(self, _result: Any) -> None:
            state.send += 1

    original_messenger = messenger_module.Messenger
    messenger_module.Messenger = DummyMessenger

    def load_fixture(filename: str, **_kwargs: Any) -> dict[str, Any]:
        state.load += 1
        state.loaded_filenames.append(filename)
        _assert(filename in {"jongga_v2_latest.json", "jongga_v2_2026-09-08.json"}, "unexpected fixture name")
        _assert(fixture.resolve().parent == fixture.parent.resolve(), "fixture parent changed")
        return json.loads(fixture.read_text(encoding="utf-8"))

    def build_result(payload: dict[str, Any]) -> tuple[dict[str, Any], int, str]:
        return {"fixture": True}, len(payload["signals"]), "2026-09-08"

    def resolve_filename(target_date: str | None) -> str:
        state.resolved_targets.append(target_date)
        return "jongga_v2_2026-09-08.json" if target_date else "jongga_v2_latest.json"

    bp = Blueprint("infra063_message", __name__)
    _register_jongga_message_route(
        bp,
        data_dir=str(guard_dir),
        logger=app.logger,
        load_json_file=load_fixture,
        resolve_jongga_message_filename=resolve_filename,
        build_screener_result_for_message=build_result,
    )
    app.register_blueprint(bp, url_prefix="/api/kr")
    return app, original_messenger


def _snapshot(state: RouteState, guard_dir: Path) -> dict[str, int | str]:
    return {
        "arrivals": state.arrivals,
        "load": state.load,
        "construct": state.construct,
        "send": state.send,
        "guard": _tree_digest(guard_dir),
        "resolve": len(state.resolved_targets),
    }


def _expect(
    records: list[dict[str, Any]],
    scenario: str,
    result: HttpResult,
    state: RouteState,
    guard_dir: Path,
    before: dict[str, int | str],
    *,
    status: int,
    arrival_delta: int,
    load_delta: int,
    construct_delta: int,
    send_delta: int,
    guard_changed: bool,
    marker: bytes | None = None,
    payload_status: str | None = None,
    duplicate: bool | None = None,
    target_date: str | None = None,
    resolved_target: object = UNSET,
) -> None:
    after = _snapshot(state, guard_dir)
    try:
        payload = json.loads(result.body.decode("utf-8")) if result.body else {}
    except (UnicodeDecodeError, json.JSONDecodeError):
        payload = {}
    record = {
        "id": scenario,
        "http_status": result.status,
        "response_status": payload.get("status"),
        "duplicate": payload.get("duplicate"),
        "target_date": payload.get("target_date"),
        "resolved_target": state.resolved_targets[-1] if len(state.resolved_targets) > int(before["resolve"]) else None,
        "loaded_filename": state.loaded_filenames[-1] if int(after["load"]) > int(before["load"]) else None,
        "arrivals": after["arrivals"],
        "load": after["load"],
        "construct": after["construct"],
        "send": after["send"],
        "guard_changed": after["guard"] != before["guard"],
    }
    records.append(record)
    _assert(result.status == status, f"{scenario}: expected HTTP {status}, got {result.status}")
    _assert(int(after["arrivals"]) - int(before["arrivals"]) == arrival_delta, f"{scenario}: Flask arrival mismatch")
    _assert(int(after["load"]) - int(before["load"]) == load_delta, f"{scenario}: load mismatch")
    _assert(int(after["construct"]) - int(before["construct"]) == construct_delta, f"{scenario}: construct mismatch")
    _assert(int(after["send"]) - int(before["send"]) == send_delta, f"{scenario}: send mismatch")
    _assert((after["guard"] != before["guard"]) is guard_changed, f"{scenario}: guard mutation mismatch")
    if marker is not None:
        _assert(marker not in result.body and marker not in json.dumps(payload, ensure_ascii=False).encode("utf-8"), f"{scenario}: input marker reflected in response")
    if payload_status is not None:
        _assert(payload.get("status") == payload_status, f"{scenario}: response status mismatch")
    if duplicate is not None:
        _assert(payload.get("duplicate") is duplicate, f"{scenario}: duplicate flag mismatch")
    if target_date is not None:
        _assert(payload.get("target_date") == target_date, f"{scenario}: target date mismatch")
    if resolved_target is not UNSET:
        _assert(record["resolved_target"] == resolved_target, f"{scenario}: resolver target mismatch")


def _assert_no_leak(result: HttpResult, secrets_to_hide: list[str], identities: list[str]) -> None:
    exposed = result.body + b"\n" + b"\n".join(f"{key}: {value}".encode() for key, value in result.headers.items())
    _assert("x-auth-identity" not in result.headers, "identity leaked in client response")
    _assert(not any(key.startswith("x-middleware-request-") for key in result.headers), "middleware request header leaked")
    for value in [*secrets_to_hide, *identities, *(item.rsplit(".", 1)[-1] for item in identities)]:
        _assert(value.encode() not in exposed, "fake identity material leaked in client response")


def _preserve_safe_log(name: str, contents: bytes) -> None:
    """Write only logs that have already passed every secret/input scan."""
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    with gzip.open(EVIDENCE_DIR / f"{name}.log.gz", "wb") as destination:
        destination.write(contents)


def _telemetry_snapshot() -> dict[str, Any]:
    """Record only matching detached-flush PIDs and event filenames."""
    event_root = FRONTEND / ".next"
    event_files = [str(path.relative_to(FRONTEND)) for path in sorted(event_root.rglob("_events*.json"))] if event_root.exists() else []
    listing = support.subprocess.run(
        ["ps", "-axo", "pid=,command="], check=True, capture_output=True, text=True
    )
    frontend_path = str(FRONTEND.resolve())
    detached_pids: list[int] = []
    for line in listing.stdout.splitlines():
        columns = line.strip().split(maxsplit=1)
        if len(columns) == 2 and "/telemetry/detached-flush" in columns[1] and frontend_path in columns[1]:
            detached_pids.append(int(columns[0]))
    return {
        "NEXT_TELEMETRY_DISABLED": "1",
        "NEXT_TRACE_UPLOAD_DISABLED": "1",
        "detached_flush_pids": detached_pids,
        "event_files": event_files,
    }


def _assert_telemetry_clean() -> dict[str, Any]:
    snapshot = _telemetry_snapshot()
    _assert(not snapshot["detached_flush_pids"], "detached Next telemetry process remained")
    _assert(not snapshot["event_files"], "Next telemetry event file remained")
    return snapshot


def _validate_port(port: int, label: str) -> int:
    _assert(1024 <= port <= 65_535, f"{label} port is outside the unprivileged range")
    _assert(port not in {3500, 5501}, f"{label} port is a prohibited standard service port")
    return port


def _run_transport(commit: str, flask_port: int, next_port: int) -> dict[str, Any]:
    started = time.monotonic()
    evidence: dict[str, Any] = {"status": "failed", "requested_commit": commit, "scenarios": [], "cleanup": {"next_process_group": "not-started", "flask_thread": "not-started", "temporary_fixture": "not-started"}}
    next_process = None
    next_pgid = None
    server: BaseWSGIServer | None = None
    server_thread = None
    original_messenger = None
    backend_capture = None
    next_log = None
    temporary_root: Path | None = None
    state = RouteState()
    results: list[HttpResult] = []
    saved_identity_secret = os.environ.get("INTERNAL_IDENTITY_SECRET")
    saved_admin_emails = os.environ.get("ADMIN_EMAILS")
    failure: Exception | None = None
    deadline = started + HARNESS_TIMEOUT_SECONDS
    try:
        _require_exact_commit(commit)
        _assert_no_runtime_secrets()
        flask_port = _validate_port(flask_port, "Flask")
        next_port = _validate_port(next_port, "Next")
        _assert(flask_port != next_port, "harness ports must be distinct")
        _assert(not support._listener_pids(flask_port), "selected Flask port already has a listener")
        _assert(not support._listener_pids(next_port), "selected Next port already has a listener")
        identity_secret = f"INFRA063_IDENTITY_{secrets.token_urlsafe(24)}"
        jwt_secret = f"INFRA063_JWT_{secrets.token_urlsafe(24)}"
        evidence["ports"] = {"flask": flask_port, "next": next_port}
        telemetry_before = _telemetry_snapshot()
        evidence["telemetry"] = {
            "before": telemetry_before,
            "next_child_env_allowlist": list(support.CHILD_ENV_ALLOWLIST),
        }
        _assert(not telemetry_before["detached_flush_pids"], "detached Next telemetry process existed before start")
        _assert(not telemetry_before["event_files"], "Next telemetry event file existed before start")
        with tempfile.TemporaryDirectory(prefix="infra063-message-") as temporary_name:
            temporary = Path(temporary_name)
            temporary_root = temporary
            fixture, guard_dir = temporary / "jongga_v2_latest.json", temporary / "guard"
            fixture.write_text(json.dumps({"signals": [{"ticker": "005930", "stock_name": "fixture"}]}, ensure_ascii=False), encoding="utf-8")
            evidence["cleanup"]["temporary_fixture"] = "created"
            os.environ["INTERNAL_IDENTITY_SECRET"] = identity_secret
            os.environ["ADMIN_EMAILS"] = ADMIN
            app, original_messenger = _create_bare_message_app(state, fixture, guard_dir)
            backend_capture = support.BackendLogCapture()
            backend_capture.start(app)
            server, server_thread = support._start_flask(app, flask_port)
            evidence["cleanup"]["flask_thread"] = "running"
            admin_cookie = _make_jwt_cookie(ADMIN, jwt_secret, temporary)
            user_cookie = _make_jwt_cookie(USER, jwt_secret, temporary)
            next_log = temporary / "next.log"
            next_process, next_pgid = support._start_next(
                next_port, flask_port, identity_secret, jwt_secret, next_log, admin_emails=ADMIN
            )
            evidence["cleanup"]["next_process_group"] = "running"
            support._wait_for_next(next_port, next_process, next_pgid, started + 90)

            def run_case(name: str, **kwargs: Any) -> tuple[HttpResult, dict[str, int | str]]:
                _assert(time.monotonic() < deadline, "harness timeout exceeded")
                before = _snapshot(state, guard_dir)
                result = _request(next_port, "POST", **kwargs)
                results.append(result)
                return result, before

            # Valid paths, including the exact duplicate guard behavior.
            result, before = run_case("Q1-admin-latest", body=b"{}", content_type="application/json", cookie=admin_cookie, sec_fetch_site="same-origin")
            _expect(evidence["scenarios"], "Q1-admin-latest", result, state, guard_dir, before, status=200, arrival_delta=1, load_delta=1, construct_delta=1, send_delta=1, guard_changed=True, payload_status="success", target_date="2026-09-08", resolved_target=None)
            result, before = run_case("Q1-duplicate", body=b"{}", content_type="application/json", cookie=admin_cookie, sec_fetch_site="same-origin")
            _expect(evidence["scenarios"], "Q1-duplicate", result, state, guard_dir, before, status=200, arrival_delta=1, load_delta=1, construct_delta=0, send_delta=0, guard_changed=False, payload_status="skipped", duplicate=True, target_date="2026-09-08", resolved_target=None)
            result, before = run_case("Q1-force", body=b'{"force":true}', content_type="application/json", cookie=admin_cookie, sec_fetch_site="same-origin")
            _expect(evidence["scenarios"], "Q1-force", result, state, guard_dir, before, status=200, arrival_delta=1, load_delta=1, construct_delta=1, send_delta=1, guard_changed=False, payload_status="success", target_date="2026-09-08", resolved_target=None)
            for name, body, mime, requested_date in (("Q1-date", b'{"target_date":"2026-09-08","force":true}', "application/json; charset=utf-8", "2026-09-08"), ("Q1-null-date", b'{"target_date":null,"force":true}', "application/vnd.infra063+json", None)):
                result, before = run_case(name, body=body, content_type=mime, cookie=admin_cookie, sec_fetch_site="same-origin")
                _expect(evidence["scenarios"], name, result, state, guard_dir, before, status=200, arrival_delta=1, load_delta=1, construct_delta=1, send_delta=1, guard_changed=False, payload_status="success", target_date="2026-09-08", resolved_target=requested_date)

            # Authentication and Next proxy CSRF checks occur before parse/load/send.
            for name, cookie, body, mime in (("Q4-anon-form", None, b"force=true", "application/x-www-form-urlencoded"), ("Q4-anon-malformed", None, b"{", "application/json"), ("Q4-user-form", user_cookie, b"force=true", "application/x-www-form-urlencoded"), ("Q4-user-malformed", user_cookie, b"{", "application/json")):
                result, before = run_case(name, body=body, content_type=mime, cookie=cookie, sec_fetch_site="same-origin")
                _expect(evidence["scenarios"], name, result, state, guard_dir, before, status=403, arrival_delta=1, load_delta=0, construct_delta=0, send_delta=0, guard_changed=False)
            for name, body, mime, site in (("Q4-csrf-cross-json", b"{}", "application/json", "cross-site"), ("Q4-csrf-cross-form", b"force=true", "application/x-www-form-urlencoded", "cross-site"), ("Q4-csrf-cross-plain", b"{}", "text/plain", "cross-site"), ("Q4-csrf-same-site", b"{}", "application/json", "same-site"), ("Q4-csrf-missing", b"{}", "application/json", None)):
                result, before = run_case(name, body=body, content_type=mime, cookie=admin_cookie, sec_fetch_site=site)
                _expect(evidence["scenarios"], name, result, state, guard_dir, before, status=403, arrival_delta=0, load_delta=0, construct_delta=0, send_delta=0, guard_changed=False)
            copied = state.identities[0]
            result, before = run_case("Q4-proxy-strips-copied-identity", body=b"{}", content_type="application/json", identity=copied, sec_fetch_site="same-origin")
            _expect(evidence["scenarios"], "Q4-proxy-strips-copied-identity", result, state, guard_dir, before, status=403, arrival_delta=1, load_delta=0, construct_delta=0, send_delta=0, guard_changed=False)

            # Parser rejection: every case reaches Flask only after authorization.
            invalid_mime = (("urlencoded", b"force=true", "application/x-www-form-urlencoded"), ("multipart", b"--x\r\n", "multipart/form-data; boundary=x"), ("plain", b"{}", "text/plain"), ("no-mime", b"{}", None), ("no-mime-empty", None, None))
            for label, body, mime in invalid_mime:
                result, before = run_case(f"Q2-{label}", body=body, content_type=mime, cookie=admin_cookie, sec_fetch_site="same-origin")
                _expect(evidence["scenarios"], f"Q2-{label}", result, state, guard_dir, before, status=415, arrival_delta=1, load_delta=0, construct_delta=0, send_delta=0, guard_changed=False, payload_status="error")
            marker = "INFRA063_입력_비반사".encode()
            invalid_json = (("malformed", b"{"), ("empty", b""), ("null", b"null"), ("array", b"[]"), ("scalar", b"true"), ("unicode", marker), ("large", marker + b"x" * (MAX_BODY_BYTES - len(marker))))
            for label, body in invalid_json:
                result, before = run_case(f"Q3-{label}", body=body, content_type="application/json", cookie=admin_cookie, sec_fetch_site="same-origin")
                _expect(evidence["scenarios"], f"Q3-{label}", result, state, guard_dir, before, status=400, arrival_delta=1, load_delta=0, construct_delta=0, send_delta=0, guard_changed=False, marker=marker, payload_status="error")

            before = _snapshot(state, guard_dir)
            options = _request(next_port, "OPTIONS")
            results.append(options)
            _expect(evidence["scenarios"], "Q5-options", options, state, guard_dir, before, status=200, arrival_delta=1, load_delta=0, construct_delta=0, send_delta=0, guard_changed=False)

            identities = list(state.identities)
            for result in results:
                _assert_no_leak(result, [identity_secret, jwt_secret], identities)
            support._terminate_process_group(next_process, next_pgid, next_port, force_kill_first=True)
            next_process = None
            evidence["cleanup"]["next_process_group"] = "terminated"
            evidence["telemetry"]["after_next_cleanup"] = _assert_telemetry_clean()
            server.shutdown(); server_thread.join(timeout=10); _assert(not server_thread.is_alive(), "bare Flask thread did not stop"); server.server_close()
            _assert(not support._listener_pids(flask_port), "selected Flask port still has a listener after cleanup")
            server = None; server_thread = None
            evidence["cleanup"]["flask_thread"] = "joined"
            flask_log = backend_capture.stop(); backend_capture = None
            next_log_contents = next_log.read_bytes()
            for secret, label in ((identity_secret, "identity"), (jwt_secret, "jwt")):
                support._assert_execution_log_clean(next_log_contents, f"Next-{label}", secret, identities, [item.rsplit(".", 1)[-1] for item in identities])
                support._assert_execution_log_clean(flask_log, f"Flask-{label}", secret, identities, [item.rsplit(".", 1)[-1] for item in identities])
            _assert(marker not in next_log_contents, "invalid input marker appeared in Next execution log")
            _assert(marker not in flask_log, "invalid input marker appeared in Flask execution log")
            support._assert_client_bundle_clean(identity_secret, identities, [item.rsplit(".", 1)[-1] for item in identities])
            support._assert_client_bundle_clean(jwt_secret, identities, [item.rsplit(".", 1)[-1] for item in identities])
            _preserve_safe_log("next", next_log_contents)
            _preserve_safe_log("flask", flask_log)
            _assert(time.monotonic() <= deadline, "harness timeout exceeded")
            evidence["commit"] = _run_git("rev-parse", "HEAD")
            evidence["security"] = "responses, logs, and client bundle contain no fake secret, identity, or MAC"
        _assert(temporary_root is not None and not temporary_root.exists(), "temporary fixture remained after cleanup")
        evidence["cleanup"]["temporary_fixture"] = "removed"
    except KeyboardInterrupt as error:
        failure = error
        evidence["failure"] = {"type": "KeyboardInterrupt", "message": "KeyboardInterrupt"}
    except Exception as error:
        failure = error
        evidence["failure"] = {"type": type(error).__name__, "message": str(error) if isinstance(error, HarnessFailure) else type(error).__name__}
    finally:
        if next_process is not None and next_pgid is not None:
            try:
                support._terminate_process_group(
                    next_process,
                    next_pgid,
                    evidence.get("ports", {}).get("next"),
                    force_kill_first=True,
                )
                evidence["cleanup"]["next_process_group"] = "terminated"
            except Exception as error:
                failure = error; evidence["cleanup"]["next_process_group"] = "failed"
        if server is not None:
            try:
                server.shutdown()
                if server_thread is not None:
                    server_thread.join(timeout=10); _assert(not server_thread.is_alive(), "bare Flask thread did not stop")
                server.server_close(); evidence["cleanup"]["flask_thread"] = "joined"
            except Exception as error:
                failure = error; evidence["cleanup"]["flask_thread"] = "failed"
        flask_port = evidence.get("ports", {}).get("flask")
        if isinstance(flask_port, int):
            try:
                _assert(not support._listener_pids(flask_port), "selected Flask port still has a listener after cleanup")
            except Exception as error:
                failure = error; evidence["cleanup"]["flask_thread"] = "failed"
        if backend_capture is not None:
            backend_capture.stop()
        if original_messenger is not None:
            import engine.messenger as messenger_module
            messenger_module.Messenger = original_messenger
        if saved_identity_secret is None: os.environ.pop("INTERNAL_IDENTITY_SECRET", None)
        else: os.environ["INTERNAL_IDENTITY_SECRET"] = saved_identity_secret
        if saved_admin_emails is None: os.environ.pop("ADMIN_EMAILS", None)
        else: os.environ["ADMIN_EMAILS"] = saved_admin_emails
        if temporary_root is not None:
            if temporary_root.exists():
                failure = HarnessFailure("temporary fixture remained after cleanup")
                evidence["cleanup"]["temporary_fixture"] = "failed"
            else:
                evidence["cleanup"]["temporary_fixture"] = "removed"
        if "telemetry" in evidence:
            try:
                evidence["telemetry"]["after_finally"] = _assert_telemetry_clean()
            except Exception as error:
                failure = error
                evidence["telemetry"]["after_finally"] = {"failed": type(error).__name__}
    evidence["status"] = "passed" if failure is None else "failed"
    return evidence


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the INFRA-063 message transport QA harness")
    parser.add_argument("--commit", help="exact first implementation commit SHA")
    parser.add_argument("--flask-port", type=int, help="Seatbelt-authorized temporary bare Flask loopback port")
    parser.add_argument("--next-port", type=int, help="Seatbelt-authorized temporary Next loopback port")
    parser.add_argument("--self-test-cleanup", action="store_true", help="network-free owned process-group cleanup test")
    args = parser.parse_args()
    if args.self_test_cleanup:
        _assert(args.commit is None, "cleanup self-test does not accept a commit")
        _assert(args.flask_port is None and args.next_port is None, "cleanup self-test does not accept ports")
        support._self_test_process_group_cleanup()
        print("INFRA-063 owned process-group cleanup self-tests passed")
        return 0
    _assert(args.commit is not None, "--commit is required for transport QA")
    _assert(args.flask_port is not None and args.next_port is not None, "--flask-port and --next-port are required for transport QA")
    evidence = _run_transport(args.commit, args.flask_port, args.next_port)
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    output = EVIDENCE_DIR / "transport.json"
    output.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if evidence["status"] != "passed":
        print(f"INFRA-063 transport QA failed: {output.relative_to(ROOT)}", file=sys.stderr)
        return 1
    print(f"INFRA-063 transport QA passed: {output.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
