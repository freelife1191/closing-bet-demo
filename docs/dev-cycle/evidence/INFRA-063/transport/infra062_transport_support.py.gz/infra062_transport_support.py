#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""INFRA-062 Next proxy → bare Flask identity transport harness.

This file is deliberately inert unless the owner supplies the exact first
implementation commit with ``--commit``.  It never starts the application
factory, reads an ``.env`` value, talks to the standard ports, or calls an
endpoint other than the disposable identity probe.
"""

from __future__ import annotations

import argparse
import base64
import gzip
import hashlib
import hmac
import http.client
import io
import json
import logging
import os
import secrets
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from flask import Flask
    from werkzeug.serving import BaseWSGIServer


ROOT = Path(__file__).resolve().parent / "checkout"
FRONTEND = ROOT / "frontend"
EVIDENCE_DIR = ROOT / "docs" / "dev-cycle" / "evidence" / "INFRA-062" / "transport"
PROBE_PREFIX = "/api/__identity_probe"
EMAIL = "transport-owner@example.test"
START_TIMEOUT_SECONDS = 90
REQUEST_TIMEOUT_SECONDS = 10
HARNESS_TIMEOUT_SECONDS = 15 * 60
CHILD_ENV_ALLOWLIST = (
    "PATH",
    "HOME",
    "USER",
    "LOGNAME",
    "SHELL",
    "TMPDIR",
    "TMP",
    "TEMP",
    "LANG",
    "LC_ALL",
    "XDG_CACHE_HOME",
)

# The runner is stored beside the disposable clone.  Put the clone before any
# caller's paths before importing app._register_request_context at runtime.
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


class HarnessFailure(RuntimeError):
    """An assertion failure that is safe to preserve in the QA evidence."""


def _safe_child_environment() -> dict[str, str]:
    """Pass only runtime basics; callers add fake harness values explicitly."""
    return {name: os.environ[name] for name in CHILD_ENV_ALLOWLIST if name in os.environ}


@dataclass(frozen=True)
class HttpResult:
    status: int
    headers: dict[str, str]
    body: bytes


class ProbeState:
    """Only in-process state; no header is returned through the HTTP API."""

    def __init__(self) -> None:
        self.arrivals = 0
        self.hits = 0
        self.headers: list[str] = []
        self.observed: list[tuple[str, str]] = []


class BackendLogCapture:
    """Capture bare Flask/Werkzeug stderr and logger records in this process."""

    def __init__(self) -> None:
        self.stderr = io.StringIO()
        self.logger_stream = io.StringIO()
        self.handler = logging.StreamHandler(self.logger_stream)
        self.saved_loggers: list[tuple[logging.Logger, list[logging.Handler], bool]] = []
        self.saved_stderr: Any | None = None

    def start(self, app: Flask) -> None:
        self.saved_stderr = sys.stderr
        sys.stderr = self.stderr
        for logger in (logging.getLogger("werkzeug"), app.logger):
            self.saved_loggers.append((logger, list(logger.handlers), logger.propagate))
            logger.handlers = [self.handler]
            logger.propagate = False

    def stop(self) -> bytes:
        self.handler.flush()
        for logger, handlers, propagate in self.saved_loggers:
            logger.handlers = handlers
            logger.propagate = propagate
        self.saved_loggers.clear()
        if self.saved_stderr is not None:
            sys.stderr = self.saved_stderr
            self.saved_stderr = None
        return (self.stderr.getvalue() + self.logger_stream.getvalue()).encode("utf-8")


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise HarnessFailure(message)


def _run_git(*args: str) -> str:
    completed = subprocess.run(
        ["git", *args],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def _require_exact_commit(commit: str) -> None:
    _assert(_run_git("rev-parse", "--show-toplevel") == str(ROOT), "clone root mismatch")
    actual = _run_git("rev-parse", "HEAD")
    expected = _run_git("rev-parse", "--verify", f"{commit}^{{commit}}")
    _assert(actual == expected, "HEAD is not the requested implementation commit")


def _assert_no_runtime_secrets() -> None:
    """Stat only: values of untracked/real dotenv files are never opened."""
    prohibited = [
        ROOT / ".env",
        ROOT / ".env.production",
        ROOT / ".env.vertex",
        FRONTEND / ".env",
        FRONTEND / ".env.local",
        FRONTEND / ".env.development",
        FRONTEND / ".env.production",
    ]
    present = [str(path.relative_to(ROOT)) for path in prohibited if path.exists()]
    _assert(not present, "dotenv file exists in the QA clone")

    tracked = [line for line in _run_git("ls-files").splitlines() if Path(line).name.startswith(".env")]
    _assert(tracked == [".env.example"], "tracked dotenv policy changed")


def _free_loopback_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as candidate:
        candidate.bind(("127.0.0.1", 0))
        port = int(candidate.getsockname()[1])
    _assert(port not in {3500, 5501}, "standard service port selected")
    return port


def _sign_identity(secret: str, method: str, path: str, expiry: int) -> str:
    encoded_email = base64.urlsafe_b64encode(EMAIL.encode("utf-8")).decode("ascii").rstrip("=")
    encoded_path = base64.urlsafe_b64encode(path.encode("utf-8")).decode("ascii").rstrip("=")
    payload = f"v2.{encoded_email}.{expiry}.{method.upper()}.{encoded_path}"
    mac = hmac.new(secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"v2.{encoded_email}.{expiry}.{mac}"


def _legacy_identity(secret: str, expiry: int) -> str:
    encoded_email = base64.urlsafe_b64encode(EMAIL.encode("utf-8")).decode("ascii").rstrip("=")
    payload = f"{encoded_email}.{expiry}"
    mac = hmac.new(secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{payload}.{mac}"


def _create_probe(state: ProbeState) -> Flask:
    from flask import Flask, Response, g, jsonify, request

    # Import only after dotenv absence is checked.  Importing app itself calls
    # load_dotenv(), while create_app would touch the real app startup paths.
    from app import _register_request_context

    app = Flask("infra062_identity_transport_probe")
    _register_request_context(app)

    @app.before_request
    def count_probe_arrival() -> None:
        # This is deliberately independent from a successful identity or probe
        # handler.  It proves a Next-side 400/308/403 never reached Flask.
        state.arrivals += 1

    @app.route(
        f"{PROBE_PREFIX}/<path:probe_path>",
        methods=["GET", "POST", "HEAD", "OPTIONS"],
        provide_automatic_options=False,
    )
    def identity_probe(probe_path: str) -> Response:
        del probe_path
        if request.method == "OPTIONS":
            return Response(status=204)
        if not g.get("user_email"):
            return jsonify(error="Unauthorized"), 401
        state.hits += 1
        identity = request.headers.get("X-Auth-Identity")
        if identity:
            # This is the only retained copy and stays in this Python process.
            state.headers.append(identity)
        state.observed.append((request.method, request.path))
        return jsonify(
            email=g.user_email,
            method=request.method,
            path=request.path,
            hit_count=state.hits,
        )

    return app


def _start_flask(app: Flask, port: int) -> tuple[BaseWSGIServer, threading.Thread]:
    from werkzeug.serving import make_server

    server = make_server("127.0.0.1", port, app)
    thread = threading.Thread(target=server.serve_forever, name="infra062-flask-probe", daemon=True)
    thread.start()
    return server, thread


def _make_jwt_cookie(secret: str, temporary: Path) -> str:
    token_file = temporary / "session-token"
    script = (
        "const fs=require('fs');"
        "const {encode}=require('next-auth/jwt');"
        "encode({token:{email:process.env.INFRA062_EMAIL,sub:'transport-user'},"
        "secret:process.env.NEXTAUTH_SECRET,maxAge:600})"
        ".then(token=>fs.writeFileSync(process.env.INFRA062_TOKEN_FILE,token,{mode:0o600}))"
        ".catch(error=>{console.error(error.name);process.exit(1)});"
    )
    environment = _safe_child_environment()
    environment.update(
        {
            "NEXTAUTH_SECRET": secret,
            "AUTH_SECRET": secret,
            "INFRA062_EMAIL": EMAIL,
            "INFRA062_TOKEN_FILE": str(token_file),
        }
    )
    completed = subprocess.run(
        ["node", "-e", script],
        cwd=FRONTEND,
        env=environment,
        capture_output=True,
        text=True,
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    _assert(completed.returncode == 0 and token_file.is_file(), "synthetic NextAuth JWT generation failed")
    # The child has no permitted stdout.  Its stderr is only retained on failure
    # as a generic failure name, never its output or generated token.
    _assert(not completed.stdout, "JWT generator unexpectedly wrote stdout")
    return token_file.read_text(encoding="utf-8").strip()


def _start_next(
    port: int,
    flask_port: int,
    identity_secret: str,
    jwt_secret: str,
    log_path: Path,
    admin_emails: str | None = None,
) -> tuple[subprocess.Popen[bytes], int]:
    environment = _safe_child_environment()
    environment.update(
        {
            "API_URL": f"http://127.0.0.1:{flask_port}",
            "INTERNAL_IDENTITY_SECRET": identity_secret,
            "NEXTAUTH_SECRET": jwt_secret,
            "AUTH_SECRET": jwt_secret,
            "NEXTAUTH_URL": f"http://127.0.0.1:{port}",
            "SCHEDULER_ENABLED": "false",
            "NODE_ENV": "development",
            "NEXT_TELEMETRY_DISABLED": "1",
            "NEXT_TRACE_UPLOAD_DISABLED": "1",
        }
    )
    if admin_emails is not None:
        environment["ADMIN_EMAILS"] = admin_emails
    log_handle = log_path.open("wb")
    try:
        process = subprocess.Popen(
            ["node", "node_modules/next/dist/bin/next", "dev", "--hostname", "127.0.0.1", "--port", str(port)],
            cwd=FRONTEND,
            env=environment,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    finally:
        log_handle.close()
    _assert(process.pid != os.getpid(), "invalid Next process owner")
    owned_pgid = os.getpgid(process.pid)
    _assert(owned_pgid == process.pid, "Next process group is not owned by this harness")
    return process, owned_pgid


def _request(
    port: int,
    method: str,
    raw_target: str,
    *,
    cookie: str | None = None,
    identity: str | None = None,
    sec_fetch_site: str | None = None,
    body: bytes | None = None,
) -> HttpResult:
    """Send raw target bytes without URL quoting or automatic redirects."""
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=REQUEST_TIMEOUT_SECONDS)
    try:
        connection.putrequest(method, raw_target, skip_host=True, skip_accept_encoding=True)
        connection.putheader("Host", f"127.0.0.1:{port}")
        if cookie:
            connection.putheader("Cookie", f"next-auth.session-token={cookie}")
        if identity:
            connection.putheader("X-Auth-Identity", identity)
        if sec_fetch_site:
            connection.putheader("Sec-Fetch-Site", sec_fetch_site)
        if body is not None:
            connection.putheader("Content-Type", "application/json")
            connection.putheader("Content-Length", str(len(body)))
        connection.endheaders(body)
        response = connection.getresponse()
        headers = {name.lower(): value for name, value in response.getheaders()}
        return HttpResult(response.status, headers, response.read())
    finally:
        connection.close()


def _listener_pids(port: int) -> list[int]:
    listeners = subprocess.run(
        ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-Fp"],
        check=False,
        capture_output=True,
        text=True,
    )
    return [int(line[1:]) for line in listeners.stdout.splitlines() if line.startswith("p")]


def _owned_listener(process: subprocess.Popen[bytes], owned_pgid: int, port: int) -> bool:
    """Accept only the harness process group as the selected port listener."""
    pids = _listener_pids(port)
    if not pids or process.poll() is not None:
        return False
    try:
        return all(os.getpgid(pid) == owned_pgid for pid in pids)
    except ProcessLookupError:
        return False


def _wait_for_next(port: int, process: subprocess.Popen[bytes], owned_pgid: int, deadline: float) -> None:
    while time.monotonic() < deadline:
        _assert(process.poll() is None, "Next exited before becoming ready")
        if not _owned_listener(process, owned_pgid, port):
            time.sleep(0.25)
            continue
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=REQUEST_TIMEOUT_SECONDS):
                return
        except OSError:
            time.sleep(0.25)
            continue
    raise HarnessFailure("Next readiness timeout")


def _assert_no_response_leak(
    result: HttpResult,
    secret: str,
    identities: list[str],
    macs: list[str],
) -> None:
    header_names = set(result.headers)
    _assert("x-auth-identity" not in header_names, "identity leaked in client response")
    _assert(not any(name.startswith("x-middleware-request-") for name in header_names), "middleware request header leaked")
    exposed = result.body + b"\n" + b"\n".join(
        f"{name}: {value}".encode("utf-8") for name, value in result.headers.items()
    )
    _assert(secret.encode("utf-8") not in exposed, "secret leaked in client response")
    _assert(all(identity.encode("utf-8") not in exposed for identity in identities), "identity header leaked in client response")
    _assert(all(mac.encode("ascii") not in exposed for mac in macs), "identity MAC leaked in client response")


def _json_path(result: HttpResult) -> str:
    payload = json.loads(result.body.decode("utf-8"))
    return str(payload["path"])


def _expect(
    evidence: list[dict[str, Any]],
    scenario: str,
    result: HttpResult,
    state: ProbeState,
    expected_status: int,
    expected_hits: int,
    expected_arrivals: int,
    *,
    path: str | None = None,
    location: str | None = None,
) -> None:
    evidence.append(
        {
            "id": scenario,
            "expected_status": expected_status,
            "status": result.status,
            "expected_hit_count": expected_hits,
            "hit_count": state.hits,
            "expected_arrival_count": expected_arrivals,
            "arrival_count": state.arrivals,
            "path": path,
            "location": location,
        }
    )
    _assert(result.status == expected_status, f"{scenario}: expected HTTP {expected_status}, got {result.status}")
    _assert(state.hits == expected_hits, f"{scenario}: expected {expected_hits} probe hits, got {state.hits}")
    _assert(state.arrivals == expected_arrivals, f"{scenario}: unexpected Flask arrival count")
    if path is not None and result.body:
        _assert(_json_path(result) == path, f"{scenario}: unexpected Flask request.path")
    if location is not None:
        _assert(result.headers.get("location") == location, f"{scenario}: unexpected redirect Location")


def _process_group_members(owned_pgid: int) -> list[int]:
    """Read the exact PGID membership; this never signals another process."""
    listing = subprocess.run(
        ["ps", "-axo", "pid=,pgid="],
        check=True,
        capture_output=True,
        text=True,
    )
    members: list[int] = []
    for line in listing.stdout.splitlines():
        columns = line.split()
        if len(columns) == 2 and columns[1] == str(owned_pgid):
            members.append(int(columns[0]))
    return members


def _process_group_exists(owned_pgid: int) -> bool:
    try:
        os.killpg(owned_pgid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # Some hosts report EPERM for an already reaped empty PGID.  Treat it
        # as gone only when ps independently confirms there is no member.
        return bool(_process_group_members(owned_pgid))
    return True


def _terminate_process_group(
    process: subprocess.Popen[bytes],
    owned_pgid: int,
    port: int | None = None,
    *,
    force_kill_first: bool = False,
) -> None:
    """Stop the exact start_new_session group, even if its leader already died."""
    _assert(owned_pgid == process.pid, "refusing to terminate a non-owned process group")
    # poll() reaps a dead direct child but does not decide whether the process
    # group is clean: descendants can remain in the preserved PGID.
    process.poll()
    _assert(
        _process_group_exists(owned_pgid) == bool(_process_group_members(owned_pgid)),
        "owned process group presence disagrees with its member list",
    )
    if force_kill_first and _process_group_exists(owned_pgid):
        os.killpg(owned_pgid, signal.SIGKILL)
        deadline = time.monotonic() + 10
        while _process_group_exists(owned_pgid) and time.monotonic() < deadline:
            process.poll()
            time.sleep(0.1)
    elif _process_group_exists(owned_pgid):
        os.killpg(owned_pgid, signal.SIGTERM)
        deadline = time.monotonic() + 10
        while _process_group_exists(owned_pgid) and time.monotonic() < deadline:
            process.poll()
            time.sleep(0.1)
    if _process_group_exists(owned_pgid):
        os.killpg(owned_pgid, signal.SIGKILL)
        deadline = time.monotonic() + 10
        while _process_group_exists(owned_pgid) and time.monotonic() < deadline:
            process.poll()
            time.sleep(0.1)
    process.poll()
    _assert(not _process_group_exists(owned_pgid), "owned process group remained after cleanup")
    _assert(not _process_group_members(owned_pgid), "owned process group members remained after cleanup")
    if port is not None:
        _assert(not _listener_pids(port), "selected Next port still has a listener after cleanup")


def _self_test_process_group_cleanup() -> None:
    """Network-free proof for both dead- and live-leader child groups."""
    child_script = "import time; time.sleep(60)"
    for label, leader_state in (("dead-leader-child", "exit"), ("live-leader-child", "stay")):
        leader = subprocess.Popen(
            [sys.executable, "-c", "import time; time.sleep(60)"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            preexec_fn=os.setpgrp,
        )
        owned_pgid = os.getpgid(leader.pid)
        _assert(owned_pgid == leader.pid, f"{label}: self-test did not create an owned process group")
        child = subprocess.Popen(
            [sys.executable, "-c", child_script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            preexec_fn=lambda: os.setpgid(0, owned_pgid),
        )
        _assert(os.getpgid(child.pid) == owned_pgid, f"{label}: child did not join the owned process group")
        if leader_state == "exit":
            leader.terminate()
            leader.wait(timeout=REQUEST_TIMEOUT_SECONDS)
            _assert(_process_group_exists(owned_pgid), f"{label}: child did not remain after leader exit")
        else:
            _assert(leader.poll() is None, f"{label}: leader exited before cleanup")
            _assert(_process_group_exists(owned_pgid), f"{label}: process group did not start")
        reaper = threading.Thread(target=child.wait, name=f"infra062-{label}-reaper", daemon=True)
        reaper.start()
        _terminate_process_group(leader, owned_pgid)
        reaper.join(timeout=REQUEST_TIMEOUT_SECONDS)
        _assert(not reaper.is_alive(), f"{label}: direct child was not reaped")
        _assert(not _process_group_exists(owned_pgid), f"{label}: group remained after cleanup")


def _assert_execution_log_clean(
    contents: bytes,
    name: str,
    secret: str,
    identities: list[str],
    macs: list[str],
) -> None:
    _assert(secret.encode("utf-8") not in contents, f"identity secret appeared in {name} execution log")
    _assert(all(identity.encode("utf-8") not in contents for identity in identities), f"identity header appeared in {name} execution log")
    _assert(all(mac.encode("ascii") not in contents for mac in macs), f"identity MAC appeared in {name} execution log")


def _preserve_safe_log(name: str, contents: bytes) -> None:
    """Persist raw bytes only after all secret/header/MAC scans have passed."""
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    with gzip.open(EVIDENCE_DIR / f"{name}.log.gz", "wb") as destination:
        destination.write(contents)


def _assert_client_bundle_clean(secret: str, identities: list[str], macs: list[str]) -> None:
    static_root = FRONTEND / ".next" / "static"
    _assert(static_root.is_dir(), "Next static output was not created")
    for artifact in static_root.rglob("*"):
        if not artifact.is_file():
            continue
        contents = artifact.read_bytes()
        _assert(secret.encode("utf-8") not in contents, "identity secret appeared in client bundle")
        _assert(all(identity.encode("utf-8") not in contents for identity in identities), "identity header appeared in client bundle")
        _assert(all(mac.encode("ascii") not in contents for mac in macs), "identity MAC appeared in client bundle")


def _run_transport(commit: str) -> dict[str, Any]:
    started_at = time.monotonic()
    state = ProbeState()
    server: BaseWSGIServer | None = None
    server_thread: threading.Thread | None = None
    next_process: subprocess.Popen[bytes] | None = None
    next_pgid: int | None = None
    backend_capture: BackendLogCapture | None = None
    scenarios: list[dict[str, Any]] = []
    responses: list[HttpResult] = []
    evidence: dict[str, Any] = {
        "status": "failed",
        "requested_commit": commit,
        "scenarios": scenarios,
        "security": "not-run",
        "cleanup": {"next_process_group": "not-started", "flask_thread": "not-started"},
    }
    failure: Exception | None = None

    try:
        _require_exact_commit(commit)
        _assert_no_runtime_secrets()
        identity_secret = f"INFRA062_SENTINEL_{secrets.token_urlsafe(24)}"
        jwt_secret = f"INFRA062_JWT_{secrets.token_urlsafe(24)}"
        flask_port = _free_loopback_port()
        next_port = _free_loopback_port()
        _assert(flask_port != next_port, "duplicate harness port")
        evidence["ports"] = {"next": next_port, "flask": flask_port}

        with tempfile.TemporaryDirectory(prefix="infra062-transport-") as temporary_name:
            temporary = Path(temporary_name)
            next_log = temporary / "next.log"
            os.environ["INTERNAL_IDENTITY_SECRET"] = identity_secret
            app = _create_probe(state)
            backend_capture = BackendLogCapture()
            backend_capture.start(app)
            server, server_thread = _start_flask(app, flask_port)
            evidence["cleanup"]["flask_thread"] = "running"
            cookie = _make_jwt_cookie(jwt_secret, temporary)
            next_process, next_pgid = _start_next(next_port, flask_port, identity_secret, jwt_secret, next_log)
            evidence["cleanup"]["next_process_group"] = "running"
            _wait_for_next(next_port, next_process, next_pgid, started_at + START_TIMEOUT_SECONDS)

            # Q1: each method is independently signed by the actual Next proxy.
            a = f"{PROBE_PREFIX}/a"
            normal_get = _request(next_port, "GET", a, cookie=cookie)
            responses.append(normal_get)
            _expect(scenarios, "Q1-GET", normal_get, state, 200, 1, 1, path=a)
            normal_post = _request(next_port, "POST", a, cookie=cookie, sec_fetch_site="same-origin", body=b"{}")
            responses.append(normal_post)
            _expect(scenarios, "Q1-POST", normal_post, state, 200, 2, 2, path=a)
            normal_head = _request(next_port, "HEAD", a, cookie=cookie)
            responses.append(normal_head)
            _expect(scenarios, "Q1-HEAD", normal_head, state, 200, 3, 3)
            _assert(len(state.headers) == 3, "expected one retained identity for each successful request")

            # Capture only in Python memory, then validate Flask's actual request binding directly.
            get_header = state.headers[0]
            direct_before = state.hits
            cross_path = _request(flask_port, "GET", f"{PROBE_PREFIX}/b", identity=get_header)
            responses.append(cross_path)
            _expect(scenarios, "Q2-cross-path", cross_path, state, 401, direct_before, 4)
            cross_method = _request(flask_port, "POST", a, identity=get_header, body=b"{}")
            responses.append(cross_method)
            _expect(scenarios, "Q2-cross-method", cross_method, state, 401, direct_before, 5)
            same_path_query = _request(flask_port, "GET", f"{a}?scope=still-path-only", identity=get_header)
            responses.append(same_path_query)
            _expect(scenarios, "Q6-same-path-query", same_path_query, state, 200, direct_before + 1, 6, path=a)

            # Client-supplied replay cannot cross the proxy either: it is stripped before rewrite.
            proxy_replay = _request(next_port, "GET", f"{PROBE_PREFIX}/b", identity=get_header)
            responses.append(proxy_replay)
            _expect(scenarios, "Q2-proxy-strips-replay", proxy_replay, state, 401, direct_before + 1, 7)

            # Q3: old, malformed and expired values never authorize the bare probe.
            expiry = int(time.time()) + 120
            invalid_headers = {
                "legacy": _legacy_identity(identity_secret, expiry),
                "unknown": f"v9.{get_header.split('.', 1)[1]}",
                "expired": _sign_identity(identity_secret, "GET", a, int(time.time()) - 1),
                "forged": f"{get_header.rsplit('.', 1)[0]}.{'0' * 64}",
            }
            for offset, (label, header) in enumerate(invalid_headers.items(), start=8):
                result = _request(flask_port, "GET", a, identity=header)
                responses.append(result)
                _expect(scenarios, f"Q3-{label}", result, state, 401, direct_before + 1, offset)

            # Q4 exact raw target table.  http.client receives these strings unchanged.
            cases = [
                ("Q4-a-percent-2f", f"{PROBE_PREFIX}/a%2Fb", f"{PROBE_PREFIX}/a/b"),
                ("Q4-double-encoding", f"{PROBE_PREFIX}/%252F", f"{PROBE_PREFIX}/%2F"),
                ("Q4-unicode", f"{PROBE_PREFIX}/%ED%95%9C%EA%B8%80", f"{PROBE_PREFIX}/한글"),
            ]
            expected_hits = direct_before + 1
            expected_arrivals = 11
            for scenario, raw_target, observed_path in cases:
                result = _request(next_port, "GET", raw_target, cookie=cookie)
                responses.append(result)
                expected_hits += 1
                expected_arrivals += 1
                _expect(scenarios, scenario, result, state, 200, expected_hits, expected_arrivals, path=observed_path)

            tail_with_slash = _request(next_port, "GET", f"{PROBE_PREFIX}/tail/", cookie=cookie)
            responses.append(tail_with_slash)
            _expect(
                scenarios,
                "Q4-tail-redirect",
                tail_with_slash,
                state,
                308,
                expected_hits,
                expected_arrivals,
                location=f"{PROBE_PREFIX}/tail",
            )
            tail = _request(next_port, "GET", f"{PROBE_PREFIX}/tail", cookie=cookie)
            responses.append(tail)
            expected_hits += 1
            expected_arrivals += 1
            _expect(scenarios, "Q4-tail-resigned", tail, state, 200, expected_hits, expected_arrivals, path=f"{PROBE_PREFIX}/tail")

            for raw_target in (f"{PROBE_PREFIX}/%", f"{PROBE_PREFIX}/%ZZ", f"{PROBE_PREFIX}/%FF"):
                malformed = _request(next_port, "GET", raw_target, cookie=cookie)
                responses.append(malformed)
                _expect(scenarios, f"Q5-{raw_target.rsplit('/', 1)[1]}", malformed, state, 400, expected_hits, expected_arrivals)

            options = _request(next_port, "OPTIONS", a)
            responses.append(options)
            expected_arrivals += 1
            _expect(scenarios, "Q6-options", options, state, 204, expected_hits, expected_arrivals)
            anonymous = _request(next_port, "GET", a)
            responses.append(anonymous)
            expected_arrivals += 1
            _expect(scenarios, "Q6-anonymous", anonymous, state, 401, expected_hits, expected_arrivals)
            csrf = _request(next_port, "POST", a, cookie=cookie, sec_fetch_site="cross-site", body=b"{}")
            responses.append(csrf)
            _expect(scenarios, "Q6-csrf", csrf, state, 403, expected_hits, expected_arrivals)

            identities = [*state.headers, *invalid_headers.values()]
            macs = [identity.rsplit(".", 1)[1] for identity in identities]
            for result in responses:
                _assert_no_response_leak(result, identity_secret, identities, macs)

            # Stop both harness-owned servers before reading their final logs.
            _terminate_process_group(next_process, next_pgid, next_port)
            evidence["cleanup"]["next_process_group"] = "terminated"
            next_process = None
            server.shutdown()
            server_thread.join(timeout=10)
            _assert(not server_thread.is_alive(), "bare Flask thread did not stop")
            server.server_close()
            _assert(not _listener_pids(flask_port), "selected Flask port still has a listener after cleanup")
            evidence["cleanup"]["flask_thread"] = "joined"
            server = None
            server_thread = None
            flask_log = backend_capture.stop()
            backend_capture = None
            next_log_contents = next_log.read_bytes()
            _assert_execution_log_clean(next_log_contents, "Next", identity_secret, identities, macs)
            _assert_execution_log_clean(flask_log, "Flask", identity_secret, identities, macs)
            _assert_client_bundle_clean(identity_secret, identities, macs)
            _preserve_safe_log("next", next_log_contents)
            _preserve_safe_log("flask", flask_log)
            _assert(time.monotonic() - started_at <= HARNESS_TIMEOUT_SECONDS, "harness timeout exceeded")
            evidence["commit"] = _run_git("rev-parse", "HEAD")
            evidence["security"] = {
                "response_identity_headers": 0,
                "response_middleware_request_headers": 0,
                "response_secret_or_mac": 0,
                "next_log_identity_headers": 0,
                "next_log_secret_or_mac": 0,
                "flask_log_identity_headers": 0,
                "flask_log_secret_or_mac": 0,
                "client_bundle_secret_or_mac": 0,
            }
    except KeyboardInterrupt as error:
        # This explicit path has the same cleanup/evidence behavior as a
        # regular harness failure.  External process termination is not a
        # Python-finally guarantee and is deliberately outside this claim.
        failure = error
        evidence["failure"] = {"type": "KeyboardInterrupt", "message": "KeyboardInterrupt"}
    except Exception as error:  # evidence is intentionally written after cleanup below.
        failure = error
        evidence["failure"] = {
            "type": type(error).__name__,
            "message": str(error) if isinstance(error, HarnessFailure) else type(error).__name__,
        }
    finally:
        # Only this harness's start_new_session group and its in-process server
        # are stopped; no port discovery or broad process kill occurs.
        try:
            if next_process is not None and next_pgid is not None:
                _terminate_process_group(next_process, next_pgid, evidence.get("ports", {}).get("next"))
                evidence["cleanup"]["next_process_group"] = "terminated"
        except Exception as error:
            failure = error
            evidence["cleanup"]["next_process_group"] = "failed"
            evidence["cleanup_failure"] = type(error).__name__
        try:
            if server is not None:
                server.shutdown()
            if server_thread is not None:
                server_thread.join(timeout=10)
                _assert(not server_thread.is_alive(), "bare Flask thread did not stop")
            if server is not None:
                server.server_close()
                flask_port = evidence.get("ports", {}).get("flask")
                _assert(isinstance(flask_port, int), "selected Flask port is unavailable for cleanup verification")
                _assert(not _listener_pids(flask_port), "selected Flask port still has a listener after cleanup")
                evidence["cleanup"]["flask_thread"] = "joined"
        except Exception as error:
            failure = error
            evidence["cleanup"]["flask_thread"] = "failed"
            evidence["cleanup_failure"] = type(error).__name__
        if backend_capture is not None:
            # Normal return, caught Exception, and KeyboardInterrupt reach this
            # block.  No claim is made for external SIGTERM/SIGKILL or a leader
            # forcibly ending this interpreter before Python can run finally.
            backend_capture.stop()
        os.environ.pop("INTERNAL_IDENTITY_SECRET", None)

    evidence["status"] = "passed" if failure is None else "failed"
    return evidence


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the gated INFRA-062 identity transport QA harness")
    parser.add_argument("--commit", help="exact first implementation commit SHA")
    parser.add_argument("--self-test-cleanup", action="store_true", help="network-free owned process-group cleanup test")
    args = parser.parse_args()
    if args.self_test_cleanup:
        _assert(args.commit is None, "cleanup self-test does not accept a commit")
        _self_test_process_group_cleanup()
        print("INFRA-062 owned process-group cleanup self-tests passed: dead-leader-child, live-leader-child")
        return 0
    _assert(args.commit is not None, "--commit is required for transport QA")
    evidence = _run_transport(args.commit)
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    output = EVIDENCE_DIR / "transport.json"
    output.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if evidence["status"] != "passed":
        # Failure text intentionally contains only harness assertions, never
        # headers, secrets, response payloads, child output, or generated JWTs.
        print(f"INFRA-062 transport QA failed: {output.relative_to(ROOT)}", file=sys.stderr)
        return 1
    print(f"INFRA-062 transport QA passed: {output.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
