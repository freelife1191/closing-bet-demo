from pathlib import Path
import os
P=Path(__file__).resolve().parent
(P/'fixture.sb').write_text('(version 1)(allow default)(deny network-outbound)(allow network-outbound (remote ip "localhost:*"))\n')
env={k:os.environ[k] for k in ('PATH','HOME','USER','LOGNAME','LANG','LC_ALL','SHELL','TMPDIR') if k in os.environ}
env.update(SCHEDULER_ENABLED='false',PYTHONDONTWRITEBYTECODE='1',NEXT_TELEMETRY_DISABLED='1',NEXT_TRACE_UPLOAD_DISABLED='1')
args=['/usr/bin/sandbox-exec','-f',str(P/'fixture.sb'),str(P/'checkout/venv/bin/python'),'-B',str(P/'interval_fixture.py')]
os.chdir(P/'checkout')
log=os.open(P/'supervisor.log',os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
os.dup2(log,1);os.dup2(log,2);os.close(log)
os.execve(args[0],args,env)
