# INFRA-056 interval fixture

`python3 interval_fixture.py` must run only from this temporary fixture root.
It requires `checkout/` to be the isolated clone and selects two unused
loopback ports, never 3500 or 5501.  The launcher writes `ready.json` with the
dashboard URL, owned PIDs, generation, and 0600 synthetic-cookie file paths.
Cookie values and generated secrets are never printed.

The unchanged Next `/dashboard/kr` runs once.  `API_URL` points only to the
owned Flask loopback port.  Flask is a separate process and uses bare
`Flask(...)`; it registers `_register_request_context` plus the real
`kr_market.get_interval_config` and decorated
`kr_market.set_interval_config` view functions.  It asserts that the product
resolver already resolves to `checkout/.env`; it never replaces that resolver.
The initial clone dotenv contains only interval `30` and `QA_SENTINEL`.  The
actual interval HTTP service, persistence helper, atomic write path, and
decorator remain active.  Only `services.scheduler` is a recording no-op so no
scheduler job is ever registered.

`RESTART` requests an owned Flask restart while leaving Next running.  The new
process explicitly removes the interval from its inherited environment, then
reads the clone dotenv again and the supervisor probes the real GET;
for example, after a successful change to 15 it verifies 15 before replacing
the PID and generation in `ready.json`.  `STOP` ends the fixture.  Its 20
minute lifetime and every startup wait are bounded (90 seconds).

Two file controls intentionally create adversarial states without replacing
interval code: `revoke-admin` makes the real `is_admin_email` see no admin,
and `failwrite` injects `ENOSPC` only at the real `os.replace` boundary when
the clone `.env` is persisted.  All other unknown API mutation methods return
405.  The auxiliary Market Gate GET response is fixed to score 72 and has no
analysis, data collection, LLM, trade, or save action.

The parent launcher should apply its localhost-only Seatbelt policy.  This
harness itself never reads or writes the original repository dotenv files or
`data/`, never contacts production, and never starts the repository's normal
3500/5501 services.  Cleanup kills only the owned Next process group, then
uses `wait`, `pgrep`, and `lsof`; Flask receives terminate and is awaited.
`ready.json` and append-only `metrics.jsonl` include the owned PID, generation,
clone cwd, checkout HEAD/source SHA, owned loopback API URL, and the child
interval-unset proof.  Request records contain only method/path/status/interval
and error kind; no header, request body, cookie, or secret is stored.
