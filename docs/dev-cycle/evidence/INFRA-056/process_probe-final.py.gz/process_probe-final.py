import os,sys,json,multiprocessing as mp,faulthandler
from pathlib import Path
P=Path(__file__).resolve().parent;C=P/'checkout';sys.path.insert(0,str(C))

def interval_writer(path, entered, release):
    from services.kr_market_interval_service import persist_market_gate_interval_to_env
    from services.kr_market_data_cache_core import atomic_write_text
    def apply(value):
        entered.set()
        if not release.wait(15): raise TimeoutError('release absent')
    persist_market_gate_interval_to_env(interval=15,env_path=path,atomic_write_text=atomic_write_text,apply_interval_fn=apply)

def common_writer(path,attempt,done):
    from services.common_env_service import update_env_file
    attempt.set();update_env_file(path,{'SMTP_HOST':'new-host'},{});done.set()

if __name__=='__main__':
    from dotenv import dotenv_values
    faulthandler.dump_traceback_later(30, exit=True)
    ctx=mp.get_context('spawn');results=[]
    for kill in (False,True):
        folder=P/('process-v2-kill' if kill else 'process-v2-normal');folder.mkdir()
        path=folder/'.env';path.write_text('SMTP_HOST=old-host\nMARKET_GATE_UPDATE_INTERVAL_MINUTES=30\n')
        entered=ctx.Event();release=ctx.Event();attempt=ctx.Event();done=ctx.Event()
        a=ctx.Process(target=interval_writer,args=(str(path),entered,release));b=ctx.Process(target=common_writer,args=(str(path),attempt,done))
        a.start()
        try:
            assert entered.wait(10),'first writer not entered'
            b.start();assert attempt.wait(10),'second not attempted'
            assert not done.wait(.3),'second writer bypassed held lock'
            if kill:a.terminate()
            else:release.set()
            a.join(10);b.join(10)
            assert not a.is_alive() and not b.is_alive()
            assert b.exitcode==0 and (a.exitcode==-15 if kill else a.exitcode==0)
            values=dotenv_values(path)
            assert values['SMTP_HOST']=='new-host' and values['MARKET_GATE_UPDATE_INTERVAL_MINUTES']=='15'
            results.append({'mode':'kill-lock-owner' if kill else 'two-writers','a_exit':a.exitcode,'b_exit':b.exitcode,'values':dict(values),'blocked_while_held':True})
        finally:
            # A terminated child may leave its Event mutex locked; never touch it here.
            for child in (a,b):
                if child.pid and child.is_alive():child.kill();child.join(5)
                if child.pid:assert not child.is_alive()
    (P/'process-results.json').write_text(json.dumps(results,indent=2)+'\n')
    faulthandler.cancel_dump_traceback_later()
    print(json.dumps(results))
