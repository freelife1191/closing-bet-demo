#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""INFRA-056 interval browser fixture.

This is an isolated-checkout harness.  It starts the unchanged Next dashboard
once and supervises a separately spawned, bare Flask process.  The Flask
process registers only the real interval GET/POST views; every other mutation
is rejected before it can reach a product route.
"""

from __future__ import annotations

import argparse
import base64
import errno
import hashlib
import hmac
import json
import os
import secrets
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from types import ModuleType
from typing import Any

from flask import Flask, Response, jsonify, request
from werkzeug.serving import make_server


ROOT = Path(__file__).resolve().parent
CLONE = ROOT / "checkout"
FRONTEND = CLONE / "frontend"
DOTENV = CLONE / ".env"
SECRETS = ROOT / "fixture-secrets.json"
READY = ROOT / "ready.json"
METRICS = ROOT / "metrics.jsonl"
STOP = ROOT / "STOP"
RESTART = ROOT / "RESTART"
REVOKE_ADMIN = ROOT / "revoke-admin"
FAILWRITE = ROOT / "failwrite"
BACKEND_LOG = ROOT / "backend.log"
NEXT_LOG = ROOT / "next.log"
ADMIN_COOKIE = ROOT / "admin.cookies.json"
VIEWER_COOKIE = ROOT / "viewer.cookies.json"
LIFETIME_SECONDS = 20 * 60
START_TIMEOUT_SECONDS = 90
ADMIN_EMAIL = "infra056-admin@example.test"
VIEWER_EMAIL = "infra056-viewer@example.test"
SAFE_ENV_KEYS = ("PATH", "HOME", "USER", "LOGNAME", "SHELL", "TMPDIR", "TMP", "TEMP", "LANG", "LC_ALL", "XDG_CACHE_HOME")


class FixtureFailure(RuntimeError):
    """Raised when this isolated fixture cannot prove a safe state."""


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise FixtureFailure(message)


def _safe_environment() -> dict[str, str]:
    """Keep child inheritance small; interval configuration never inherits."""
    return {key: os.environ[key] for key in SAFE_ENV_KEYS if key in os.environ}


def _atomic_json(path: Path, payload: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as candidate:
        candidate.bind(("127.0.0.1", 0))
        port = int(candidate.getsockname()[1])
    _assert(port not in {3500, 5501}, "fixture selected a production port")
    return port


def _listener_pids(port: int) -> list[int]:
    result = subprocess.run(
        ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-Fp"],
        check=False,
        capture_output=True,
        text=True,
    )
    _assert(result.returncode in (0, 1), "lsof failed")
    return [int(line[1:]) for line in result.stdout.splitlines() if line.startswith("p")]


def _wait_listening(port: int, process: subprocess.Popen[bytes], description: str, pgid: int | None = None) -> None:
    deadline = time.monotonic() + START_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        _assert(process.poll() is None, f"{description} exited before readiness")
        listeners = _listener_pids(port)
        if listeners:
            try:
                owned = all(
                    os.getpgid(pid) == pgid if pgid is not None else pid == process.pid
                    for pid in listeners
                )
            except ProcessLookupError:
                owned = False
            _assert(owned, f"{description} listener is not owned by fixture")
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=2):
                    return
            except OSError:
                pass
        time.sleep(0.2)
    raise FixtureFailure(f"{description} readiness timed out")


def _read_interval() -> int:
    """Read only the isolated clone's two-line fixture dotenv."""
    lines = DOTENV.read_text(encoding="utf-8").splitlines()
    pairs = dict(line.split("=", 1) for line in lines if "=" in line)
    _assert(set(pairs).issubset({"MARKET_GATE_UPDATE_INTERVAL_MINUTES", "QA_SENTINEL"}), "fixture dotenv contains unexpected keys")
    try:
        interval = int(pairs["MARKET_GATE_UPDATE_INTERVAL_MINUTES"])
    except (KeyError, ValueError) as error:
        raise FixtureFailure("fixture dotenv has no valid interval") from error
    _assert(1 <= interval <= 1440 and bool(pairs.get("QA_SENTINEL")), "fixture dotenv is invalid")
    return interval


def _write_initial_dotenv() -> None:
    _assert(not DOTENV.is_symlink(), "fixture refuses a linked clone dotenv")
    DOTENV.write_text(
        "MARKET_GATE_UPDATE_INTERVAL_MINUTES=30\nQA_SENTINEL=INFRA056_ISOLATED\n",
        encoding="utf-8",
    )
    os.chmod(DOTENV, 0o600)


def _write_secrets() -> dict[str, str]:
    values = {
        "identity_secret": secrets.token_urlsafe(32),
        "nextauth_secret": secrets.token_urlsafe(32),
        "flask_secret": secrets.token_urlsafe(32),
    }
    _atomic_json(SECRETS, values)
    return values


def _read_secrets() -> dict[str, str]:
    values = json.loads(SECRETS.read_text(encoding="utf-8"))
    _assert(all(isinstance(values.get(key), str) and values[key] for key in ("identity_secret", "nextauth_secret", "flask_secret")), "synthetic secrets file is invalid")
    return values


def _sign_identity(email: str, secret: str, method: str, path: str) -> str:
    encoded_email = base64.urlsafe_b64encode(email.encode("utf-8")).decode("ascii").rstrip("=")
    encoded_path = base64.urlsafe_b64encode(path.encode("utf-8")).decode("ascii").rstrip("=")
    expires = str(int(time.time()) + 120)
    payload = f"v2.{encoded_email}.{expires}.{method}.{encoded_path}"
    mac = hmac.new(secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"v2.{encoded_email}.{expires}.{mac}"


def _head() -> str:
    result = subprocess.run(
        ["git", "-C", str(CLONE), "rev-parse", "--verify", "HEAD"],
        capture_output=True,
        check=False,
        text=True,
    )
    _assert(result.returncode == 0 and result.stdout.strip(), "isolated checkout has no HEAD")
    return result.stdout.strip()


def _source_sha() -> str:
    result = subprocess.run(
        ["git", "-C", str(CLONE), "hash-object", "app/routes/kr_market.py"],
        capture_output=True,
        check=False,
        text=True,
    )
    _assert(result.returncode == 0 and result.stdout.strip(), "cannot fingerprint interval route source")
    return result.stdout.strip()


def _append_metric(record: dict[str, Any]) -> None:
    # JSONL keeps evidence from earlier backend generations intact.  It excludes
    # headers, bodies, cookies, synthetic secrets, and response text.
    with METRICS.open("a", encoding="utf-8") as output:
        output.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
    os.chmod(METRICS, 0o600)


def _backend_main(port: int, generation: int) -> int:
    _assert(CLONE.is_dir() and DOTENV.is_file(), "isolated checkout or dotenv is missing")
    _read_interval()
    inherited_environment = _safe_environment()
    os.chdir(CLONE)
    os.environ.clear()
    os.environ.update(inherited_environment)
    os.environ.pop("MARKET_GATE_UPDATE_INTERVAL_MINUTES", None)
    interval_unset_before_dotenv = "MARKET_GATE_UPDATE_INTERVAL_MINUTES" not in os.environ
    secrets_file = _read_secrets()
    os.environ.update({
        "INTERNAL_IDENTITY_SECRET": secrets_file["identity_secret"],
        "FLASK_SECRET_KEY": secrets_file["flask_secret"],
        "SCHEDULER_ENABLED": "false",
    })
    sys.path.insert(0, str(CLONE))

    # The real interval application function imports this module at call time.
    # Its only scheduler edge becomes evidence, while validation and persistence
    # in the interval route remain production functions.
    runtime = {
        "pid": os.getpid(),
        "generation": generation,
        "cwd": str(CLONE),
        "head": _head(),
        "source_sha": _source_sha(),
        "api_url": f"http://127.0.0.1:{port}",
        "child_interval_env_unset": interval_unset_before_dotenv,
    }
    scheduler_module = ModuleType("services.scheduler")

    def record_scheduler_interval(minutes: int) -> None:
        _append_metric({**runtime, "method": "INERT", "path": "services.scheduler.update_market_gate_interval", "status": 200, "interval": int(minutes), "error_kind": None})

    scheduler_module.update_market_gate_interval = record_scheduler_interval
    sys.modules["services.scheduler"] = scheduler_module

    from app import _register_request_context
    from app.routes import kr_market

    _assert(interval_unset_before_dotenv, "child inherited an interval before dotenv")
    _assert(os.environ.get("MARKET_GATE_UPDATE_INTERVAL_MINUTES") == str(_read_interval()), "clone dotenv did not load the interval into child")
    _assert(Path(kr_market._project_env_path()).resolve() == DOTENV.resolve(), "product interval resolver does not target clone root dotenv")
    original_replace = os.replace

    def replace_at_boundary(source: str | bytes | os.PathLike[str] | os.PathLike[bytes], target: str | bytes | os.PathLike[str] | os.PathLike[bytes]) -> None:
        if FAILWRITE.exists() and Path(target).resolve() == DOTENV.resolve():
            raise OSError(errno.ENOSPC, "fixture requested ENOSPC at .env replace")
        original_replace(source, target)

    # The write path still calls the real atomic helper; this is only a syscall
    # boundary fault injection point for the clone .env target.
    os.replace = replace_at_boundary
    app = Flask("infra056_interval_fixture")
    app.config["SECRET_KEY"] = secrets_file["flask_secret"]

    @app.before_request
    def fixture_controls() -> None:
        # is_admin_email itself remains real and reads this process environment.
        os.environ["ADMIN_EMAILS"] = "" if REVOKE_ADMIN.exists() else ADMIN_EMAIL

    _register_request_context(app)

    @app.after_request
    def evidence(response: Response) -> Response:
        payload = response.get_json(silent=True)
        interval = payload.get("interval") if isinstance(payload, dict) else None
        error_kind = None
        if response.status_code >= 400:
            error_kind = "enospc" if FAILWRITE.exists() and response.status_code == 500 else "http_error"
        _append_metric({**runtime, "method": request.method, "path": request.path, "status": response.status_code, "interval": interval, "error_kind": error_kind})
        return response

    # Register the actual decorated view functions, never their entire product
    # blueprint.  That keeps all unrelated product mutation routes unreachable.
    app.add_url_rule("/api/kr/config/interval", "interval_get", kr_market.get_interval_config, methods=["GET"])
    app.add_url_rule("/api/kr/config/interval", "interval_set", kr_market.set_interval_config, methods=["POST"])

    @app.get("/api/admin/check")
    def admin_check() -> Response:
        from flask import g
        from services.admin_helpers import is_admin_email

        return jsonify(isAdmin=is_admin_email(g.get("user_email")))

    @app.get("/api/kr/market-gate")
    def market_gate() -> Response:
        return jsonify(total_score=72, score=72, status="GREEN", source="fixture")

    @app.get("/api/kr/signals")
    def signals() -> Response:
        return jsonify(signals=[], total_scanned=0)

    @app.get("/api/kr/status")
    def status() -> Response:
        return jsonify(status="success", data={"files": {}, "signals_count": 0})

    @app.get("/api/kr/backtest-summary")
    def backtest_summary() -> Response:
        return jsonify({})

    @app.get("/api/kr/user/quota")
    def user_quota() -> Response:
        return jsonify(usage=0, limit=10, remaining=10)

    @app.get("/api/kr/signals/status")
    def signals_status() -> Response:
        return jsonify(running=False, status="idle", progress=0)

    @app.get("/api/kr/signals/dates")
    def signals_dates() -> Response:
        return jsonify([])

    @app.get("/api/kr/ai-analysis")
    def ai_analysis() -> Response:
        return jsonify(signals=[], analyses={})

    @app.get("/api/system/data-status")
    @app.get("/api/system/update-status")
    def system_status() -> Response:
        return jsonify(files=[], isRunning=False, update_status={"isRunning": False})

    @app.route("/api/<path:unknown>", methods=["POST", "PUT", "PATCH", "DELETE"])
    def reject_unknown_mutation(unknown: str) -> Response:
        return jsonify(error="fixture rejects unknown mutation"), 405

    server = make_server("127.0.0.1", port, app)
    try:
        server.serve_forever()
    finally:
        server.server_close()
        os.replace = original_replace
    return 0


def _start_backend(port: int, generation: int) -> subprocess.Popen[bytes]:
    environment = _safe_environment()
    with BACKEND_LOG.open("ab") as output:
        process = subprocess.Popen(
            [sys.executable, "-B", str(Path(__file__).resolve()), "--backend", "--flask-port", str(port), "--generation", str(generation)],
            cwd=ROOT,
            env=environment,
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=subprocess.STDOUT,
        )
    try:
        _wait_listening(port, process, "Flask")
    except Exception:
        _terminate_backend(process, port)
        raise
    return process


def _terminate_backend(process: subprocess.Popen[bytes], port: int) -> None:
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired as error:
            process.kill()
            process.wait(timeout=10)
            raise FixtureFailure("owned Flask did not terminate") from error
    else:
        process.wait(timeout=1)
    _assert(not _listener_pids(port), "owned Flask port still listening")


def _start_next(port: int, flask_port: int, secret_values: dict[str, str]) -> tuple[subprocess.Popen[bytes], int]:
    environment = _safe_environment()
    environment.update({
        "API_URL": f"http://127.0.0.1:{flask_port}",
        "INTERNAL_IDENTITY_SECRET": secret_values["identity_secret"],
        "NEXTAUTH_SECRET": secret_values["nextauth_secret"],
        "AUTH_SECRET": secret_values["nextauth_secret"],
        "NEXTAUTH_URL": f"http://localhost:{port}",
        "ADMIN_EMAILS": ADMIN_EMAIL,
        "SCHEDULER_ENABLED": "false",
        "NODE_ENV": "development",
        "NEXT_TELEMETRY_DISABLED": "1",
        "NEXT_TRACE_UPLOAD_DISABLED": "1",
    })
    with NEXT_LOG.open("ab") as output:
        process = subprocess.Popen(
            ["node", "node_modules/next/dist/bin/next", "dev", "--hostname", "127.0.0.1", "--port", str(port)],
            cwd=FRONTEND,
            env=environment,
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    pgid = os.getpgid(process.pid)
    _assert(pgid == process.pid, "Next process group is not owned")
    try:
        _wait_listening(port, process, "Next", pgid)
    except Exception:
        _terminate_next(process, pgid, port)
        raise
    return process, pgid


def _terminate_next(process: subprocess.Popen[bytes], pgid: int, port: int) -> None:
    _assert(process.pid == pgid, "refusing to kill an unowned Next process group")
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired as error:
        raise FixtureFailure("owned Next group did not stop") from error
    pgrep = subprocess.run(["pgrep", "-g", str(pgid)], capture_output=True, text=True, check=False)
    _assert(pgrep.returncode in (0, 1), "pgrep failed")
    _assert(pgrep.returncode == 1, "owned Next process group still has members")
    _assert(not _listener_pids(port), "owned Next port still listening")


def _write_cookie(path: Path, email: str, secret_value: str) -> None:
    script = (
        "const fs=require('fs');const {encode}=require('next-auth/jwt');"
        "encode({token:{email:process.env.QA_EMAIL,sub:'infra056'},secret:process.env.QA_SECRET,maxAge:1800})"
        ".then(v=>fs.writeFileSync(process.env.QA_OUTPUT,JSON.stringify([{name:'next-auth.session-token',value:v,domain:'localhost',path:'/',httpOnly:true,secure:false,sameSite:'Lax'}]),{mode:0o600}))"
        ".catch(()=>process.exit(1));"
    )
    environment = _safe_environment()
    environment.update(QA_EMAIL=email, QA_SECRET=secret_value, QA_OUTPUT=str(path))
    result = subprocess.run(["node", "-e", script], cwd=FRONTEND, env=environment, capture_output=True, text=True, timeout=15)
    _assert(result.returncode == 0 and path.is_file(), "synthetic cookie creation failed")
    os.chmod(path, 0o600)


def _probe_interval(port: int, expected: int, secret_value: str) -> None:
    import http.client

    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    connection.request("GET", "/api/kr/config/interval", headers={"X-Auth-Identity": _sign_identity(ADMIN_EMAIL, secret_value, "GET", "/api/kr/config/interval")})
    response = connection.getresponse()
    payload = json.loads(response.read().decode("utf-8"))
    connection.close()
    _assert(response.status == 200 and payload.get("interval") == expected, "real interval GET did not return reloaded dotenv value")


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the isolated INFRA-056 interval fixture")
    parser.add_argument("--backend", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--flask-port", type=int)
    parser.add_argument("--next-port", type=int)
    parser.add_argument("--generation", type=int, default=0, help=argparse.SUPPRESS)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    if args.backend:
        _assert(args.flask_port is not None, "backend requires Flask port")
        return _backend_main(args.flask_port, args.generation)
    _assert(CLONE.is_dir() and FRONTEND.is_dir(), "isolated checkout is missing")
    _assert(not (CLONE / ".env.production").exists() and not (CLONE / ".env.vertex").exists(), "fixture refuses extra clone dotenv files")
    _assert(
        not any((FRONTEND / name).exists() for name in (".env", ".env.local", ".env.development", ".env.production")),
        "fixture refuses frontend dotenv files",
    )
    flask_port = args.flask_port or _free_port()
    next_port = args.next_port or _free_port()
    while next_port == flask_port:
        next_port = _free_port()
    _assert(flask_port != next_port and flask_port not in {3500, 5501} and next_port not in {3500, 5501}, "invalid fixture ports")
    _assert(not _listener_pids(flask_port) and not _listener_pids(next_port), "requested fixture port is already listening")
    _write_initial_dotenv()
    METRICS.unlink(missing_ok=True)
    secret_values = _write_secrets()
    backend: subprocess.Popen[bytes] | None = None
    next_process: subprocess.Popen[bytes] | None = None
    next_pgid: int | None = None
    generation = 0
    try:
        backend = _start_backend(flask_port, generation)
        _probe_interval(flask_port, 30, secret_values["identity_secret"])
        next_process, next_pgid = _start_next(next_port, flask_port, secret_values)
        _write_cookie(ADMIN_COOKIE, ADMIN_EMAIL, secret_values["nextauth_secret"])
        _write_cookie(VIEWER_COOKIE, VIEWER_EMAIL, secret_values["nextauth_secret"])
        _atomic_json(READY, {
            "url": f"http://localhost:{next_port}/dashboard/kr",
            "flask_port": flask_port,
            "next_port": next_port,
            "next_pid": next_process.pid,
            "next_pgid": next_pgid,
            "backend_pid": backend.pid,
            "backend_generation": generation,
            "cwd": str(CLONE),
            "head": _head(),
            "source_sha": _source_sha(),
            "api_url": f"http://127.0.0.1:{flask_port}",
            "child_interval_env_unset": True,
            "admin_cookie_file": str(ADMIN_COOKIE),
            "viewer_cookie_file": str(VIEWER_COOKIE),
        })
        deadline = time.monotonic() + LIFETIME_SECONDS
        while not STOP.exists():
            _assert(time.monotonic() < deadline, "fixture lifetime expired")
            _assert(next_process.poll() is None, "Next exited unexpectedly")
            if RESTART.exists():
                RESTART.unlink()
                _terminate_backend(backend, flask_port)
                generation += 1
                backend = _start_backend(flask_port, generation)
                expected = _read_interval()
                _probe_interval(flask_port, expected, secret_values["identity_secret"])
                _atomic_json(READY, {
                    "url": f"http://localhost:{next_port}/dashboard/kr",
                    "flask_port": flask_port,
                    "next_port": next_port,
                    "next_pid": next_process.pid,
                    "next_pgid": next_pgid,
                    "backend_pid": backend.pid,
                    "backend_generation": generation,
                    "cwd": str(CLONE),
                    "head": _head(),
                    "source_sha": _source_sha(),
                    "api_url": f"http://127.0.0.1:{flask_port}",
                    "child_interval_env_unset": True,
                    "admin_cookie_file": str(ADMIN_COOKIE),
                    "viewer_cookie_file": str(VIEWER_COOKIE),
                })
            time.sleep(0.2)
        return 0
    finally:
        errors: list[str] = []
        if next_process is not None and next_pgid is not None:
            try:
                _terminate_next(next_process, next_pgid, next_port)
            except Exception as error:
                errors.append(type(error).__name__)
        if backend is not None:
            try:
                _terminate_backend(backend, flask_port)
            except Exception as error:
                errors.append(type(error).__name__)
        _atomic_json(ROOT / "cleanup.json", {"error_kinds": errors})
        if errors:
            raise FixtureFailure("fixture cleanup did not reach terminal state")


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"INFRA-056 fixture failed: {type(error).__name__}", file=sys.stderr)
        raise
