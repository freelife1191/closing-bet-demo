from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, threading, time
root = Path(__file__).resolve().parent
counts = {"blocked": 0}
class Deny(BaseHTTPRequestHandler):
    def do_CONNECT(self):
        counts["blocked"] += 1
        self.send_response(403); self.end_headers(); self.close_connection = True
        (root/"proxy-counts.json").write_text(json.dumps(counts))
    do_GET = do_CONNECT
    do_POST = do_CONNECT
    def log_message(self,*args): pass
server = ThreadingHTTPServer(("127.0.0.1",0),Deny)
thread = threading.Thread(target=server.serve_forever,daemon=True); thread.start()
(root/"proxy-ready.json").write_text(json.dumps({"port":server.server_port}))
try:
    deadline=time.monotonic()+900
    while not (root/"stop").exists() and time.monotonic()<deadline: time.sleep(.2)
finally:
    server.shutdown();thread.join(timeout=5);server.server_close()
    (root/"proxy-cleanup.json").write_text(json.dumps({"stopped":not thread.is_alive(),"blocked":counts["blocked"]}))

