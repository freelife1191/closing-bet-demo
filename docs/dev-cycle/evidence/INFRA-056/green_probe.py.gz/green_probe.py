from pathlib import Path
import sys,json
P=Path(__file__).resolve().parent;C=P/'checkout';sys.path.insert(0,str(C))
from app.routes import kr_market
from services.kr_market_interval_service import persist_market_gate_interval_to_env
from services.kr_market_data_cache_core import atomic_write_text
from dotenv import dotenv_values
folder=P/'green-data';folder.mkdir();path=folder/'.env'
path.write_text('export MARKET_GATE_UPDATE_INTERVAL_MINUTES="30"\nMARKET_GATE_UPDATE_INTERVAL_MINUTES = 60\nKEEP=unchanged\n')
persist_market_gate_interval_to_env(interval=15,env_path=str(path),atomic_write_text=atomic_write_text,apply_interval_fn=lambda interval: None)
checks={'real_route_resolves_root':Path(kr_market._project_env_path())==C/'.env','single_interval_key':sum('MARKET_GATE_UPDATE_INTERVAL_MINUTES' in line for line in path.read_text().splitlines())==1,'value15':dotenv_values(path)['MARKET_GATE_UPDATE_INTERVAL_MINUTES']=='15'}
(P/'green-probe-result.json').write_text(json.dumps(checks,indent=2)+'\n');print(checks)
raise SystemExit(0 if all(checks.values()) else 1)
