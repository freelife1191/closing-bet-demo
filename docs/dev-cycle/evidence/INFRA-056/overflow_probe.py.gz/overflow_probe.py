import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'checkout'))
from services.kr_market_interval_http_service import handle_interval_config_request
calls=[]
status,payload=handle_interval_config_request(method='POST',req_data={'interval':float('inf')},current_interval=30,set_interval_fn=calls.append)
assert status==400 and calls==[]
print('overflow rejected before write: PASS')
