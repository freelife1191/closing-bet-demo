#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Own and verify only the JONGGA polling scratch processes."""

from __future__ import annotations

import json
import os
import signal
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
CHECKOUT = ROOT / "checkout"
FRONTEND = CHECKOUT / "frontend"
FIXTURE = ROOT / "jongga_poll_fixture.py"
SANDBOX = Path("/usr/bin/sandbox-exec")
POLICY = ROOT / "local-only.sb"
PIDS = ROOT / "pids.json"
CLEANUP = ROOT / "cleanup.json"
FAKE_ENV = ROOT / "fake.env"
LOG_DIR = ROOT / "logs"
PORTS = (57361, 57362)


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def _write_json(path: Path, value: Any) -> None:
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=path.name + ".",
        suffix=".tmp",
        delete=False,
    ) as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
        temporary = Path(handle.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)
    os.chmod(path, 0o600)


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    _assert(isinstance(value, dict), f"invalid object file: {path.name}")
    return value


def _base_env() -> dict[str, str]:
    keys = ("PATH", "HOME", "USER", "TMPDIR", "LANG")
    return {key: os.environ[key] for key in keys if key in os.environ}


def _fake_env() -> dict[str, str]:
    _assert(FAKE_ENV.is_file() and not FAKE_ENV.is_symlink(), "fixture prepare has not produced fake.env")
    values: dict[str, str] = {}
    for raw_line in FAKE_ENV.read_text(encoding="utf-8").splitlines():
        key, separator, value = raw_line.partition("=")
        _assert(bool(separator) and key.isupper() and bool(value), "invalid fake.env line")
        values[key] = value
    return values


def _sandbox_command(*command: str) -> list[str]:
    return [str(SANDBOX), "-f", str(POLICY), *command]


def _assert_ports_free() -> None:
    busy: list[int] = []
    for port in PORTS:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.settimeout(0.2)
            if probe.connect_ex(("127.0.0.1", port)) == 0:
                busy.append(port)
    _assert(not busy, f"scratch ports already have listeners: {busy}")


def _prepare() -> None:
    python = CHECKOUT / "venv" / "bin" / "python"
    _assert(python.is_file(), "checkout python is unavailable")
    result = subprocess.run(
        _sandbox_command(str(python), str(FIXTURE), "prepare"),
        cwd=ROOT,
        env=_base_env(),
        text=True,
        capture_output=True,
        timeout=30,
        check=False,
    )
    _assert(result.returncode == 0, f"fixture prepare failed: {result.stderr.strip()}")


def start() -> int:
    _assert(CHECKOUT.is_dir() and FRONTEND.is_dir(), "run setup.sh before start")
    _assert(not PIDS.exists(), "owned process record already exists")
    _assert(SANDBOX.is_file() and POLICY.is_file() and FIXTURE.is_file(), "launcher inputs are missing")
    _assert_ports_free()
    if not FAKE_ENV.exists():
        _prepare()

    environment = _base_env()
    environment.update(_fake_env())
    LOG_DIR.mkdir(mode=0o700, exist_ok=True)
    python = CHECKOUT / "venv" / "bin" / "python"
    node = Path("/opt/homebrew/bin/node")
    if not node.is_file():
        node = Path("/usr/local/bin/node")
    next_bin = FRONTEND / "node_modules" / "next" / "dist" / "bin" / "next"
    _assert(python.is_file() and node.is_file() and next_bin.is_file(), "absolute python/node/next executable is unavailable")

    backend_log = (LOG_DIR / "backend.log").open("w", encoding="utf-8")
    next_log = (LOG_DIR / "next.log").open("w", encoding="utf-8")
    backend = subprocess.Popen(
        _sandbox_command(str(python), str(FIXTURE), "serve"),
        cwd=ROOT,
        env=environment,
        stdout=backend_log,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    frontend = subprocess.Popen(
        _sandbox_command(str(node), str(next_bin), "dev", "--webpack", "--hostname", "127.0.0.1", "--port", "57361"),
        cwd=FRONTEND,
        env=environment,
        stdout=next_log,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    _write_json(
        PIDS,
        {
            "scratch_root": str(ROOT),
            "backend": {"pid": backend.pid, "pgid": os.getpgid(backend.pid)},
            "frontend": {"pid": frontend.pid, "pgid": os.getpgid(frontend.pid)},
            "root_commands": {
                "backend": _sandbox_command(str(python), str(FIXTURE), "serve"),
                "frontend": _sandbox_command(str(node), str(next_bin), "dev", "--webpack", "--hostname", "127.0.0.1", "--port", "57361"),
            },
            "ports": list(PORTS),
        },
    )
    print(json.dumps({"started": True, "pids_file": str(PIDS), "ports": list(PORTS)}))
    return 0


def _process_group_alive(pgid: int) -> bool:
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return False
    return True


def cleanup() -> int:
    _assert(PIDS.is_file() and not PIDS.is_symlink(), "owned process record is missing")
    payload = _read_json(PIDS)
    _assert(Path(str(payload.get("scratch_root", ""))).resolve() == ROOT, "refusing unowned process record")
    _assert(tuple(payload.get("ports", ())) == PORTS, "refusing altered port record")
    groups = []
    for name in ("backend", "frontend"):
        record = payload.get(name)
        _assert(isinstance(record, dict), f"missing {name} process record")
        pid, pgid = int(record.get("pid", 0)), int(record.get("pgid", 0))
        _assert(pid > 1 and pgid > 1, f"invalid {name} process record")
        try:
            _assert(os.getpgid(pid) == pgid, f"refusing changed {name} process group")
        except ProcessLookupError:
            _assert(not _process_group_alive(pgid), f"missing {name} root with a live child group")
            continue
        process_list = subprocess.run(
            ["ps", "-o", "pid=,pgid=,command=", "-g", str(pgid)],
            capture_output=True,
            text=True,
            check=False,
        ).stdout.splitlines()
        _assert(process_list and all(str(ROOT) in line for line in process_list), f"refusing process group outside scratch: {name}")
        groups.append((name, pgid))

    for _, pgid in groups:
        os.killpg(pgid, signal.SIGTERM)

    deadline = time.monotonic() + 10
    while any(_process_group_alive(pgid) for _, pgid in groups) and time.monotonic() < deadline:
        time.sleep(0.1)
    alive = [name for name, pgid in groups if _process_group_alive(pgid)]
    _assert(not alive, f"owned process groups did not exit: {alive}")

    _assert_ports_free()
    PIDS.unlink()
    _write_json(CLEANUP, {"cleanup": "complete", "ports_free": True, "groups": [name for name, _ in groups]})
    print(json.dumps({"cleanup": "complete", "ports_free": True}))
    return 0


if __name__ == "__main__":
    _assert(len(sys.argv) == 2 and sys.argv[1] in {"start", "cleanup"}, "usage: launcher.py start|cleanup")
    raise SystemExit(start() if sys.argv[1] == "start" else cleanup())
