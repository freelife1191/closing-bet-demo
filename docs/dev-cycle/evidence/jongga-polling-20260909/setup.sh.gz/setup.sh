#!/bin/zsh
set -euo pipefail

readonly SOURCE_ROOT="/Users/freelife/vibe/lecture/hodu/closing-bet-demo"
readonly SCRATCH_ROOT="${0:A:h}"
readonly CHECKOUT="$SCRATCH_ROOT/checkout"
readonly FIXTURE="$SCRATCH_ROOT/jongga_poll_fixture.py"
readonly SANDBOX="$SCRATCH_ROOT/local-only.sb"

if [[ ! -d "$SOURCE_ROOT/.git" ]]; then
  print -u2 "source repository is unavailable"
  exit 1
fi

tracked_envs=$(git -C "$SOURCE_ROOT" ls-tree -r --name-only HEAD | awk -F/ '$NF ~ /^[.]env/ && $NF != ".env.example"')
if [[ -n "$tracked_envs" ]]; then
  print -u2 "tracked runtime environment files are forbidden: $tracked_envs"
  exit 1
fi
if [[ ! -f "$FIXTURE" || ! -f "$SANDBOX" ]]; then
  print -u2 "fixture or sandbox policy is missing"
  exit 1
fi
if [[ -e "$CHECKOUT" ]]; then
  print -u2 "scratch checkout already exists; do not reuse it"
  exit 1
fi

umask 077
mkdir -p "$CHECKOUT"
git -C "$SOURCE_ROOT" archive --format=tar HEAD -- . ':(exclude)data' | tar -xf - -C "$CHECKOUT"

for blocked in "$CHECKOUT/.env" "$CHECKOUT/.env.local" "$CHECKOUT/frontend/.env" "$CHECKOUT/frontend/.env.local" "$CHECKOUT/data"; do
  if [[ -e "$blocked" || -L "$blocked" ]]; then
    print -u2 "unexpected copied runtime state: $blocked"
    exit 1
  fi
done

if [[ ! -d "$SOURCE_ROOT/venv" || ! -d "$SOURCE_ROOT/frontend/node_modules" ]]; then
  print -u2 "shared dependency directories are unavailable"
  exit 1
fi
ln -s "$SOURCE_ROOT/venv" "$CHECKOUT/venv"
ln -s "$SOURCE_ROOT/frontend/node_modules" "$CHECKOUT/frontend/node_modules"

print -r -- "scratch checkout prepared: $CHECKOUT"
print -r -- "next step only when QA begins: /usr/bin/sandbox-exec -f $SANDBOX $CHECKOUT/venv/bin/python $FIXTURE prepare"
