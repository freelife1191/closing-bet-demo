#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""JONGGA-014/032/037의 로컬 전용 합성 API fixture.

이 파일은 checkout을 준비한 뒤에만 prepare/serve를 수행한다. 모든 외부 네트워크와
원본 저장소 쓰기는 local-only.sb가 막고, HTTP write는 synthetic run endpoint 하나만
상태 전이 mock으로 허용한다. LLM·거래·발송·삭제 경로는 구현하지 않는다.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import secrets
import subprocess
import sys
import tempfile
import time
from datetime import date
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


ROOT = Path(__file__).resolve().parent
CHECKOUT = ROOT / "checkout"
FRONTEND = CHECKOUT / "frontend"
BACKEND_PORT = 57362
NEXT_PORT = 57361
ORIGINAL_ROOT = Path("/Users/freelife/vibe/lecture/hodu/closing-bet-demo").resolve()
CONTROL = ROOT / "control.json"
FAKE_ENV = ROOT / "fake.env"
ADMIN_COOKIE = ROOT / "admin-nextauth-cookie.json"
VIEWER_COOKIE = ROOT / "viewer-nextauth-cookie.json"
REQUESTS = ROOT / "requests.jsonl"

MODES = frozenset({"normal", "typeerror", "conflict", "delayed-complete", "neverending"})
STATUS_SEQUENCE = {
    "normal": (True, False),
    "conflict": (True, False),
    "delayed-complete": (True, True, False),
    # 화면 이탈 뒤 정리 검사용: 완료 응답을 내지 않는다.
    "neverending": (True,),
}


class FixtureError(RuntimeError):
    """합성 fixture 계약 위반."""


def _assert(value: bool, message: str) -> None:
    if not value:
        raise FixtureError(message)


def _private_write(path: Path, text: str) -> None:
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        dir=path.parent,
        prefix=path.name + ".",
        suffix=".tmp",
        delete=False,
    ) as handle:
        handle.write(text)
        temporary = Path(handle.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)
    os.chmod(path, 0o600)


def _write_json(path: Path, value: Any) -> None:
    _private_write(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def _read_json(path: Path) -> dict[str, Any]:
    _assert(path.is_file() and not path.is_symlink(), f"missing fixture file: {path.name}")
    value = json.loads(path.read_text(encoding="utf-8"))
    _assert(isinstance(value, dict), f"fixture file must contain an object: {path.name}")
    return value


def _assert_checkout(*, require_empty_data: bool) -> None:
    _assert(CHECKOUT.is_dir() and FRONTEND.is_dir(), "run setup.sh before prepare")
    _assert(CHECKOUT.resolve() != ORIGINAL_ROOT, "original checkout is forbidden")
    _assert((CHECKOUT / "venv").is_symlink(), "checkout venv link is missing")
    _assert((FRONTEND / "node_modules").is_symlink(), "checkout node_modules link is missing")
    for forbidden in (CHECKOUT / ".env", CHECKOUT / ".env.local", FRONTEND / ".env", FRONTEND / ".env.local"):
        _assert(not forbidden.exists() and not forbidden.is_symlink(), f"runtime state copied into checkout: {forbidden.name}")
    data_dir = CHECKOUT / "data"
    if require_empty_data:
        _assert(not data_dir.exists() and not data_dir.is_symlink(), "runtime data was copied into checkout")
    else:
        _assert(not data_dir.is_symlink(), "checkout data must never link to original data")


def _make_cookie(email: str, name: str, secret: str) -> list[dict[str, Any]]:
    source = """
const { encode } = require('next-auth/jwt');
let input = ''; process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => input += chunk);
process.stdin.on('end', async () => {
  const token = await encode({ token: JSON.parse(input), secret: process.env.NEXTAUTH_SECRET, maxAge: 3600 });
  process.stdout.write(JSON.stringify({name: 'next-auth.session-token', value: token}));
});
"""
    result = subprocess.run(
        ["node", "-e", source],
        cwd=FRONTEND,
        env={"PATH": os.environ.get("PATH", ""), "HOME": os.environ.get("HOME", ""), "NEXTAUTH_SECRET": secret},
        input=json.dumps({"name": name, "email": email, "sub": email}),
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )
    _assert(result.returncode == 0, "synthetic NextAuth cookie creation failed")
    token = json.loads(result.stdout)
    _assert(token.get("name") == "next-auth.session-token" and bool(token.get("value")), "synthetic cookie is empty")
    return [{"name": token["name"], "value": token["value"], "domain": "127.0.0.1", "path": "/", "httpOnly": True, "secure": False, "sameSite": "Lax"}]


def prepare() -> int:
    _assert_checkout(require_empty_data=True)
    values = {
        "GOOGLE_CLIENT_ID": "qa-client",
        "GOOGLE_CLIENT_SECRET": "qa-secret",
        "NEXTAUTH_SECRET": secrets.token_urlsafe(32),
        "NEXTAUTH_URL": f"http://127.0.0.1:{NEXT_PORT}",
        "NEXTAUTH_URL_INTERNAL": f"http://127.0.0.1:{NEXT_PORT}",
        "API_URL": f"http://127.0.0.1:{BACKEND_PORT}",
        "INTERNAL_IDENTITY_SECRET": secrets.token_urlsafe(32),
        "ADMIN_EMAILS": "qa-admin@example.test",
        "SCHEDULER_ENABLED": "false",
        "NEXT_TELEMETRY_DISABLED": "1",
        "NEXT_TRACE_UPLOAD_DISABLED": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "CI": "1",
    }
    _private_write(FAKE_ENV, "".join(f"{key}={value}\n" for key, value in values.items()))
    _write_json(ADMIN_COOKIE, _make_cookie("qa-admin@example.test", "QA Admin", values["NEXTAUTH_SECRET"]))
    _write_json(VIEWER_COOKIE, _make_cookie("qa-viewer@example.test", "QA Viewer", values["NEXTAUTH_SECRET"]))
    _write_json(CONTROL, {"mode": "normal", "status_reads": 0, "completed": False})
    REQUESTS.unlink(missing_ok=True)
    print(json.dumps({"prepared": True, "ports": [NEXT_PORT, BACKEND_PORT], "synthetic_cookies": True}))
    return 0


def set_mode(mode: str) -> int:
    _assert(mode in MODES, "unsupported fixture mode")
    control = _read_json(CONTROL)
    control.update({"mode": mode, "status_reads": 0, "completed": False})
    _write_json(CONTROL, control)
    print(json.dumps({"mode": mode, "synthetic_api": True}))
    return 0


def _pipeline_result() -> dict[str, Any]:
    from engine.phases_pipeline import SignalGenerationPipeline

    calls: list[str] = []
    internal_error = TypeError("synthetic phase1 internal error")

    class Phase1:
        async def execute(self, candidates: list[dict[str, Any]], target_date: date) -> list[dict[str, Any]]:
            calls.append(target_date.isoformat())
            raise internal_error

        def get_stats(self) -> dict[str, int]: return {"processed": 1}
        def get_drop_stats(self) -> dict[str, int]: return {}

    class PassPhase:
        async def execute(self, candidates, *_args): return candidates
        def get_stats(self) -> dict[str, int]: return {"processed": 1}
        def get_no_news_count(self) -> int: return 0
        def get_final_stats(self) -> dict[str, int]: return {"S": 1}

    pipeline = SignalGenerationPipeline(Phase1(), PassPhase(), PassPhase(), PassPhase())
    try:
        asyncio.run(pipeline.execute([{"ticker": "005930"}], {"status": "GREEN"}, date(2026, 9, 9)))
    except TypeError as error:
        return {"status": "error", "error_type": "TypeError", "message": str(error), "phase1_calls": calls, "same_exception": error is internal_error}
    raise FixtureError("typeerror fixture did not propagate")


def _result_payload() -> dict[str, Any]:
    signal = {
        "stock_code": "005930", "stock_name": "삼성전자", "market": "KOSPI", "sector": "반도체", "grade": "S",
        "entry_price": 100000, "buy_price": 100000, "current_price": 101000, "signal_date": "2026-09-09", "trading_value": 100000000000, "change_pct": 7.0,
        "score": {"total": 88, "news": 3, "volume": 4, "chart": 4, "candle": 3, "consolidation": 3, "timing": 4, "supply": 4, "llm_reason": "합성 점수"},
        "checklist": {"has_news": True, "news_sources": ["synthetic"], "is_new_high": False, "is_breakout": True, "supply_positive": True, "volume_surge": True},
        "themes": ["합성 검증"],
        "ai_evaluation": {"action": "BUY", "confidence": 80, "model": "synthetic", "reason": "합성 AI 의견"},
    }
    return {
        "date": "2026-09-09", "total_candidates": 1, "filtered_count": 1,
        "updated_at": "2026-09-09T17:00:00+09:00", "status": "success", "source": "synthetic-jongga-polling",
        "signals": [signal],
    }


def _status() -> dict[str, Any]:
    control = _read_json(CONTROL)
    mode = str(control.get("mode"))
    sequence = STATUS_SEQUENCE.get(mode, (False,))
    index = min(int(control.get("status_reads", 0)), len(sequence) - 1)
    running = bool(sequence[index])
    control["status_reads"] = index + 1
    control["completed"] = not running and index == len(sequence) - 1
    _write_json(CONTROL, control)
    return {"isRunning": running, "is_running": running, "status": "RUNNING" if running else "IDLE", "message": "합성 종가 업데이트 진행 중" if running else "합성 종가 업데이트 완료"}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, _format: str, *_args: object) -> None: return

    def _reply(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        with REQUESTS.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"method": self.command, "path": urlparse(self.path).path, "status": status, "synthetic": True}) + "\n")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path in {"/api/kr/jongga-v2/latest", "/api/kr/jongga-v2/results", "/api/kr/jongga-v2/history/2026-09-09"}:
            self._reply(200, _result_payload())
        elif path == "/api/kr/jongga-v2/dates":
            self._reply(200, ["2026-09-09"])
        elif path == "/api/kr/jongga-v2/status":
            self._reply(200, _status())
        elif path == "/api/kr/market-gate":
            self._reply(200, {"score": 72, "status": "GREEN", "label": "합성 시장", "sectors": []})
        elif path == "/api/admin/check":
            self._reply(200, {"isAdmin": True})
        elif path == "/api/kr/user/quota":
            self._reply(200, {"remaining": 20, "daily_limit": 20, "used": 0, "is_admin": True})
        else:
            self._reply(404, {"error": "synthetic API allowlist only"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path != "/api/kr/jongga-v2/run":
            self._reply(405, {"error": "fixture blocks LLM, trading, notifications, reanalysis, and deletion"})
            return
        mode = str(_read_json(CONTROL).get("mode"))
        if mode == "typeerror":
            self._reply(500, _pipeline_result())
        elif mode == "conflict":
            self._reply(409, {"status": "running", "message": "합성 실행이 이미 진행 중입니다"})
        else:
            self._reply(200, {"status": "started", "message": "합성 실행 시작"})

    def do_DELETE(self) -> None: self._reply(405, {"error": "method blocked"})
    do_PUT = do_DELETE
    do_PATCH = do_DELETE


def serve() -> int:
    _assert_checkout(require_empty_data=False)
    _assert(CONTROL.exists(), "run prepare before serve")
    sys.path.insert(0, str(CHECKOUT))
    ThreadingHTTPServer(("127.0.0.1", BACKEND_PORT), Handler).serve_forever(poll_interval=0.2)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "set-mode", "serve"))
    parser.add_argument("mode", nargs="?")
    args = parser.parse_args()
    if args.command == "prepare": return prepare()
    if args.command == "set-mode":
        _assert(args.mode is not None, "mode is required")
        return set_mode(args.mode)
    return serve()


if __name__ == "__main__":
    raise SystemExit(main())
