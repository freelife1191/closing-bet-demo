#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Temporary real Next UI + real Flask message route, synthetic dependencies."""
from pathlib import Path
import json, os, secrets, subprocess, sys, time
import runtime_support as runtime
ROOT = Path(__file__).resolve().parent
CLONE = ROOT / "checkout"
sys.path.insert(0, str(CLONE))
from flask import Flask, Blueprint, request, jsonify, g
from app import _register_request_context
from app.routes.kr_market_jongga_execution_routes import _register_jongga_message_route
from services.admin_helpers import is_admin_email
import engine.messenger as messenger

admin = "browser-admin@example.test"
identity = secrets.token_urlsafe(32)
jwt = secrets.token_urlsafe(32)
os.environ["INTERNAL_IDENTITY_SECRET"] = identity
os.environ["ADMIN_EMAILS"] = admin
runtime._assert_no_runtime_secrets()
control = ROOT / "control.json"
control.write_text('{"revoked":false}')
state = {"requests": [], "send": 0, "construct": 0, "targets": []}
def save():
    tmp = ROOT / "state.tmp"
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2))
    tmp.replace(ROOT / "state.json")
app = Flask("browser_measurement_fixture")
_register_request_context(app)
@app.before_request
def observe():
    os.environ["ADMIN_EMAILS"] = "" if json.loads(control.read_text())["revoked"] else admin
    if request.method == "POST":
        assert request.path == "/api/kr/jongga-v2/message", "unexpected fixture write route"
@app.after_request
def record(response):
    item = {"path":request.path, "method":request.method, "status":response.status_code}
    if request.method == "POST":
        item.update(content_type=request.content_type, body=request.get_data(as_text=True))
    state["requests"].append(item)
    save()
    return response
class DummyMessenger:
    def __init__(self): state["construct"] += 1
    def send_screener_result(self, result): state["send"] += 1
messenger.Messenger = DummyMessenger
def filename(target):
    state["targets"].append(target)
    return "synthetic.json"
bp = Blueprint("message", __name__)
_register_jongga_message_route(bp,data_dir=str(ROOT/"guard-r2"),logger=app.logger,
    load_json_file=lambda *a,**k:{"signals":[{"stock_code":"005930","stock_name":"QA fixture"}]},
    resolve_jongga_message_filename=filename,
    build_screener_result_for_message=lambda data:({"fixture":True},1,"2026-09-08"))
app.register_blueprint(bp,url_prefix="/api/kr")
@app.get("/api/admin/check")
def admin_check(): return jsonify(isAdmin=is_admin_email(g.get("user_email")))
@app.get("/api/system/data-status")
def status():
    return jsonify(files=[{"name":"AI Jongga V2","path":"data/jongga_v2_latest.json","exists":True,
        "lastModified":"2026-09-08T09:00:00Z","size":"1 KB","rowCount":1,"dataDate":"2026-09-08",
        "dataTimestamp":"2026-09-08T09:00:00Z","link":"","menu":"종가베팅"}],
        update_status={"isRunning":False,"lastRun":"","progress":""})
@app.get("/api/system/update-status")
def update_status(): return jsonify(isRunning=False,startTime=None,currentItem=None,items=[])
@app.get("/api/kr/jongga-v2/status")
def jongga_status(): return jsonify(isRunning=False)
@app.get("/api/kr/signals/status")
def signals_status(): return jsonify(running=False)
@app.get("/api/<path:unused>")
def other(unused): return jsonify({})
fport, nport = runtime._free_loopback_port(), runtime._free_loopback_port()
assert fport != nport
server = thread = proc = pgid = None
try:
    server,thread = runtime._start_flask(app,fport)
    proc,pgid = runtime._start_next(nport,fport,identity,jwt,ROOT/"next.log",admin_emails=admin)
    runtime._wait_for_next(nport,proc,pgid,time.monotonic()+90)
    for label,email,name in [("admin",admin,"QA Admin"),("user","browser-user@example.test","QA Viewer")]:
        script = "const fs=require('fs');require('next-auth/jwt').encode({token:{email:process.env.QA_EMAIL,name:process.env.QA_NAME,sub:'qa'},secret:process.env.QA_SECRET,maxAge:1800}).then(value=>fs.writeFileSync(process.env.QA_OUTPUT,JSON.stringify([{name:'next-auth.session-token',value,domain:'localhost',path:'/',httpOnly:true,secure:false,sameSite:'Lax'}]),{mode:0o600})).catch(()=>process.exit(1))"
        env = runtime._safe_child_environment()
        env.update(QA_EMAIL=email,QA_NAME=name,QA_SECRET=jwt,QA_OUTPUT=str(ROOT/(label+".cookies.json")))
        subprocess.run(["node","-e",script],cwd=CLONE/"frontend",env=env,check=True,timeout=15)
    save()
    (ROOT/"ready.json").write_text(json.dumps({"url":f"http://localhost:{nport}/dashboard/data-status",
        "flask_port":fport,"next_port":nport,"next_pid":proc.pid,"next_pgid":pgid}))
    print("fixture ready",flush=True)
    deadline=time.monotonic()+1200
    while not (ROOT/"stop").exists():
        if time.monotonic()>deadline: raise TimeoutError("fixture lifetime expired")
        time.sleep(.2)
finally:
    if proc is not None: runtime._terminate_process_group(proc,pgid,nport,force_kill_first=True)
    if server is not None:
        server.shutdown();thread.join(timeout=10);server.server_close()
    (ROOT/"cleanup.json").write_text(json.dumps({"next_stopped":not runtime._listener_pids(nport),
        "flask_stopped":not runtime._listener_pids(fport),"thread_stopped":thread is None or not thread.is_alive()}))

