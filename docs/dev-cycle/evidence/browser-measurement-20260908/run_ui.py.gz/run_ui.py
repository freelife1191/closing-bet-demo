from pathlib import Path
import subprocess,json,re,time
root=Path(__file__).resolve().parent
deadline=time.monotonic()+60
while not (root/"ready.json").exists() or not (root/"proxy-ready.json").exists():
    if time.monotonic()>deadline: raise TimeoutError("fixture readiness")
    time.sleep(.1)
url=json.loads((root/"ready.json").read_text())["url"]
shots=root/"screenshots-r2";shots.mkdir()
results={}
def ab(session,*args):
    r=subprocess.run(["python3",str(root/"browser_cli.py"),session,*args],cwd=root,capture_output=True,text=True,timeout=70)
    if r.returncode: raise RuntimeError(f"{session} {args[0]} exit{r.returncode}: {r.stderr}")
    return r.stdout
def snap(s):return ab(s,"snapshot","-i")
def click_named(s,label):
    content=snap(s)
    refs=re.findall(r'^- button "'+re.escape(label)+r'"[^\n]*\[ref=(e\d+)\]',content,re.M)
    assert len(refs)==1,(label,content)
    ab(s,"click","@"+refs[0])
def wait_gone(s,title):
    expr="!Array.from(document.querySelectorAll('h3')).some(e=>e.textContent==="+json.dumps(title)+")"
    ab(s,"wait","--fn",expr)
def state():return json.loads((root/"state.json").read_text())
def posts():return [x for x in state()["requests"] if x["method"]=="POST"]
def screenshot(s,name):ab(s,"screenshot",str(shots/(name+".png")))
def set_revoked(value):
    p=root/"control.tmp";p.write_text(json.dumps({"revoked":value}));p.replace(root/"control.json")
try:
    for s,cookie,label in [("admin","admin.cookies.json","QA Admin")]:
        ab(s,"launch")
        ab(s,"cookies","set","--curl",str(root/cookie),"--domain","localhost")
        ab(s,"network","route","**:3500/**","--abort");ab(s,"network","route","**:5501/**","--abort")
        ab(s,"open",url);ab(s,"wait","--text",label)
    click_named("admin","메시지 발송");ab("admin","wait","--text","메시지 발송 확인");screenshot("admin","confirm")
    click_named("admin","취소");wait_gone("admin","메시지 발송 확인");snap("admin")
    assert posts()==[] and state()["send"]==0;results["B2"]="cancel POST0/send0"
    click_named("admin","메시지 발송");ab("admin","wait","--text","메시지 발송 확인");click_named("admin","확인")
    ab("admin","wait","--text","발송 성공");assert "메시지 발송 요청 완료 (1개 종목)" in ab("admin","get","text","body");screenshot("admin","success")
    assert len(posts())==1 and posts()[0]["status"]==200 and json.loads(posts()[0]["body"])=={"target_date":None} and state()["send"]==1
    results["B3"]="JSON null date -> HTTP200, success modal, send1"
    click_named("admin","확인");wait_gone("admin","발송 성공")
    click_named("admin","메시지 발송");ab("admin","wait","--text","메시지 발송 확인");click_named("admin","확인")
    ab("admin","wait","--text","이미 발송된 종가베팅 메시지입니다.");screenshot("admin","duplicate")
    assert len(posts())==2 and state()["send"]==1;results["B4"]="duplicate HTTP200, message shown, send still1"
    before_errors=ab("admin","errors");before_console=ab("admin","console");assert not before_errors.strip() and "[error]" not in before_console
    click_named("admin","확인");wait_gone("admin","발송 성공");set_revoked(True)
    click_named("admin","메시지 발송");ab("admin","wait","--text","메시지 발송 확인");click_named("admin","확인")
    ab("admin","wait","--text","발송 실패");assert "오류: Forbidden" in ab("admin","get","text","body");screenshot("admin","revoked")
    assert [x["status"] for x in posts()]==[200,200,403] and state()["send"]==1;results["B5"]="real403, failure modal, send still1"
    console=ab("admin","console");errors=ab("admin","errors");assert not errors.strip()
    error_lines=[x for x in console.splitlines() if x.startswith("[error]")]
    assert len(error_lines)==1 and "Failed to send message" in error_lines[0] and "403" in error_lines[0]
    network=ab("admin","network","requests","--filter","jongga-v2/message")
    (root/"network-r2.txt").write_text(network)
    set_revoked(False)
    ab("viewer","launch");ab("viewer","cookies","set","--curl",str(root/"user.cookies.json"),"--domain","localhost")
    ab("viewer","network","route","**:3500/**","--abort");ab("viewer","network","route","**:5501/**","--abort")
    ab("viewer","open",url);ab("viewer","wait","--text","QA Viewer")
    content=snap("viewer");assert 'button "메시지 발송"' not in content and 'heading "AI Jongga V2"' in content
    assert ab("viewer","get","count",'[title="메시지 발송"]').strip()=="0";screenshot("viewer","viewer")
    assert not ab("viewer","errors").strip() and "[error]" not in ab("viewer","console")
    results["B6"]="authenticated QA Viewer, file visible, send button0"
    results["B7_browser"]="page errors0; only expected403 application console error; screenshots captured"
    (root/"ui-results-r2.json").write_text(json.dumps({"passed":True,"results":results,"post_statuses":[x["status"] for x in posts()],"send":state()["send"],"url":url},ensure_ascii=False,indent=2))
    print(json.dumps(results,ensure_ascii=False),flush=True)
finally:
    close_results={}
    for s in ["admin","viewer"]:
        try:close_results[s]=ab(s,"close").strip()
        except Exception as error:close_results[s]=str(error)
    (root/"stop").touch()
    (root/"browser-close-r2.json").write_text(json.dumps(close_results,ensure_ascii=False,indent=2))

