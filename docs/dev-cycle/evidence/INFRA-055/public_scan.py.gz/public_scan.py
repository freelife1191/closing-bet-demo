from pathlib import Path
import json,sys
p=Path(__file__).resolve().parent;c=p/'checkout'
values=dict(line.split('=',1) for line in (p/'fake.env').read_text().splitlines() if '=' in line)
keys=['SMTP_PASSWORD','UNKNOWN_BACKEND_SECRET','GOOGLE_API_KEY','GOOGLE_CLIENT_SECRET','NEXTAUTH_SECRET','ADMIN_API_TOKEN','INTERNAL_IDENTITY_SECRET']
needles=[values[k].encode() for k in keys]
files=[f for d in [c/'frontend/.next/static',c/'frontend/.next/dev/static'] if d.exists() for f in d.rglob('*') if f.is_file() and not f.is_symlink()]
files += [p/n for n in ['next.log','backend.log','browser-commands.jsonl'] if (p/n).exists()]
matches=sum(data.count(n) for f in files for data in [f.read_bytes()] for n in needles)
result={'files':len(files),'full_secret_matches':matches,'keys_checked':keys}
print(json.dumps(result));sys.exit(0 if files and matches==0 else 1)
