# INFRA-055 Architecture / Devil's-Advocate Review

## Summary

환경 격리의 주 구조는 타당하다. `dev/build/start`가 단일 launcher를 통과하고, launcher가 부모·frontend·루트 환경을 허용 목록으로 축소한 뒤 고정된 frontend 경로로 Next를 실행한다 (`frontend/package.json:6`, `frontend/scripts/run-next.js:75`, `frontend/scripts/run-next.js:122`, `frontend/scripts/run-next.js:147`). `restart_all.sh`도 별도 링크/복사 경로를 만들지 않고 같은 npm 경계를 쓴다 (`restart_all.sh:17`, `restart_all.sh:93`).

하지만 현재 변경은 명세가 요구한 “두 번째 위치 인수 거부”를 구현하지 않았고, 테스트 stub이 그 동작을 대신 구현해 거짓 양성을 만든다. 이 계약은 launcher가 직접 소유해야 하므로 **Architectural Status: `BLOCK`** 이다.

## Scope

- Base: `97113d4de47be2a4567e7c8587fbf88f7635a8bc`
- Reviewed: `.env.example`, `CLAUDE.md`, `frontend/package.json`, `frontend/scripts/run-next.js`, `restart_all.sh`, `tests/scripts/test_next_environment.py`, `docs/superpowers/plans/2026-09-09-infra055-next-environment.md`
- Scope SHA-256: `b25fe059f5fba7fae6ecaee7d8d5cd00e0e56737e5e00c2daf9649850f9ee3f8`
- Hash method: 위 7개 파일의 `sha256 path` 행을 경로순 정렬한 manifest의 SHA-256

## Analysis

### 1. BLOCK — launcher가 추가 위치 인수를 거부하지 않는다

계획은 고정 frontend 경로 뒤에 두 번째 프로젝트 디렉터리가 오면 Next가 거부해야 한다고 명시한다 (`docs/superpowers/plans/2026-09-09-infra055-next-environment.md:26`). 구현은 사용자 옵션을 해석하지 않고 고정 경로 뒤에 그대로 붙인다 (`frontend/scripts/run-next.js:147`). 설치된 Next 16.3.4 CLI는 `build`에 위치 인수를 하나만 선언한다 (`frontend/node_modules/next/dist/bin/next:109`)지만, 실제 실행에서 여분 위치 인수를 오류로 만들지 않고 고정 frontend 빌드를 성공시킨다는 독립 실측 결과가 제공됐다.

현재 테스트는 실제 Next CLI가 아니라 stub 안에서 `process.argv.slice(4)`의 비옵션 인수를 찾아 exit 2를 반환한다 (`tests/scripts/test_next_environment.py:66`, `tests/scripts/test_next_environment.py:67`). 따라서 `test_launcher_keeps_fixed_project_before_rejected_extra_directory`는 launcher의 거부를 검증하지 않고 stub의 자가 구현만 검증한다 (`tests/scripts/test_next_environment.py:410`, `tests/scripts/test_next_environment.py:416`). 대상 테스트 21개가 모두 통과해도 이 결함이 드러나지 않는 이유다.

위험은 다른 디렉터리로 전환되는 직접적인 보안 우회보다 계약과 운영 안전성에 있다. 현재 고정 frontend 경로가 첫 위치 인수이므로 여분 디렉터리가 프로젝트를 바꾸지는 않지만, 오타나 잘못된 호출이 성공으로 보고되어 사용자가 의도하지 않은 프로젝트를 빌드했다고 오인할 수 있다. 더 큰 문제는 하위 CLI가 보장한다고 가정한 불변식을 test double이 대신 보장해 검증 신뢰도를 깨뜨린 점이다.

### 2. 환경 경계와 우선순위는 일관된다

launcher는 시작 시 부모 환경에서 애플리케이션/런타임 허용 키만 남기고 `NODE_ENV`를 명령별 mode로 고정한다 (`frontend/scripts/run-next.js:8`, `frontend/scripts/run-next.js:13`, `frontend/scripts/run-next.js:75`, `frontend/scripts/run-next.js:83`). frontend 활성 파일을 먼저, 루트 활성 파일을 다음에 넣어 빠진 값만 채우며 (`frontend/scripts/run-next.js:54`, `frontend/scripts/run-next.js:68`, `frontend/scripts/run-next.js:89`), 최종 자식 환경도 같은 허용 목록으로 다시 투영한다 (`frontend/scripts/run-next.js:122`). 문서의 우선순위·`.env.vertex` 제외·부모 `NODE_OPTIONS` 한계 설명과 일치한다 (`CLAUDE.md:409`, `CLAUDE.md:413`, `CLAUDE.md:420`).

frontend 환경 파일의 미허용 키는 시작 전에 거부된다 (`frontend/scripts/run-next.js:95`). 루트 파일의 백엔드 키는 파싱될 수 있지만 최종 자식 투영에서 제거된다 (`frontend/scripts/run-next.js:122`). 실제 Next가 사용하는 서버 키는 코드 검색 결과와 허용 목록이 맞는다: Google/NextAuth (`frontend/src/lib/auth.ts:8`, `frontend/src/lib/auth.ts:29`), 관리자 경계 (`frontend/src/app/api/system/env/route.ts:17`, `frontend/src/app/api/system/env/route.ts:28`, `frontend/src/app/api/system/env/route.ts:31`), 신원 서명 (`frontend/src/proxy.ts:81`), API rewrite (`frontend/next.config.js:18`).

### 3. 파일/캐시 경계는 보존적이다

환경 입력은 `lstat` 후 일반 파일만 `O_NOFOLLOW`로 열며 (`frontend/scripts/run-next.js:26`, `frontend/scripts/run-next.js:35`, `frontend/scripts/run-next.js:43`), 정확한 기존 `frontend/.env -> ../.env`만 모든 preflight 뒤 제거한다 (`frontend/scripts/run-next.js:116`). `.next`는 링크/일반 파일을 거부하고 기존 디렉터리를 삭제하지 않은 채 `0700`으로 제한한다 (`frontend/scripts/run-next.js:101`, `frontend/scripts/run-next.js:110`, `frontend/scripts/run-next.js:111`). 이는 필요한 서버 인증 비밀이 private compiler cache에 남을 수 있다는 명시된 잔여 위험과 맞는다 (`CLAUDE.md:430`).

### 4. WATCH — 허용 목록과 env parser가 수동 결합점이다

애플리케이션 키 추가 시 실제 frontend 소비 코드와 `APPLICATION_KEYS`를 함께 갱신해야 한다 (`frontend/scripts/run-next.js:8`). 문서가 실행기를 정확한 목록의 정본으로 지정해 이 결합을 드러내고 있으므로 현재는 비차단이다 (`CLAUDE.md:416`). 다만 새 서버 환경 키가 코드에 추가되고 목록이 빠지면 배포 시 조용한 기본값/인증 실패가 생길 수 있으므로, 향후 환경 소비 키 변경은 이 테스트 파일의 관측 목록과 함께 리뷰해야 한다 (`tests/scripts/test_next_environment.py:25`).

또한 launcher는 `@next/env`를 직접 import하지만 (`frontend/scripts/run-next.js:6`), `frontend/package.json`의 직접 의존성에는 `next`만 있고 `@next/env`는 없다 (`frontend/package.json:17`, `frontend/package.json:19`). 현재 lockfile에서는 Next 16.3.4의 정확한 전이 의존성으로 설치된다 (`frontend/package-lock.json:7616`, `frontend/package-lock.json:7622`). npm lockfile/hoisting을 유지하는 현재 배포에서는 작동하지만, 패키지 관리자나 설치 토폴로지를 바꾸면 launcher의 직접 import가 먼저 깨지는 숨은 결합이다.

## Root Cause

근본 원인은 “고정 프로젝트 경로와 추가 위치 인수 거부”를 launcher의 불변식으로 정의해 놓고 실제 책임은 Next CLI에 위임한 데 있다. Next CLI의 실제 관대성은 검증하지 않은 채 test double이 원하는 거부 동작을 자체 구현해, 구현과 검증의 책임 경계가 갈라졌다 (`frontend/scripts/run-next.js:147`, `tests/scripts/test_next_environment.py:66`).

## Recommendations

1. **추가 위치 인수를 spawn 전에 거부 — 작은 수정, 병합 차단 해소.** `options`를 훑어 비옵션 토큰을 거부하되, 현재 Next 16.3.4의 값 인수 옵션(`--port/-p`, `--hostname/-H`, `--keepAliveTimeout`, HTTPS key/cert/CA, upload trace, debug build paths 등)은 다음 토큰을 소비하도록 명시한다. `--flag=value`와 붙인 short option은 그대로 Next에 넘기고, unknown option의 유효성 판정은 Next에 맡긴다. 이 작은 표는 Next CLI 버전에 결합되므로 실제 지원 옵션 회귀를 같이 둔다.
2. **stub의 위치 인수 거부 로직 제거 — 작은 수정, 테스트 신뢰도 회복.** launcher가 거부한 경우 stub이 실행되지 않아 `observed.json`이 생기지 않았음을 검증한다. 최소 한 번은 실제 설치된 Next CLI로 `npm run build -- unexpected-directory`가 nonzero인지 확인해 test double과 실제 경계가 다시 갈리지 않게 한다.
3. **직접 env parser 의존성을 명시하거나 설치 전제를 자동 검증 — 작은 수정, 패키지 토폴로지 위험 감소.** `@next/env`를 직접 의존성으로 선언해 API 사용 책임을 드러내는 쪽이 명확하다. Next와 parser 버전 정합성 정책도 함께 정해야 한다. 현 lockfile 고정을 신뢰한다면 이 항목은 후속 WATCH로 남길 수 있다.
4. **허용 목록 변경 체크를 유지 — 작은 노력, 인증 회귀 예방.** frontend의 `process.env.*` 소비가 바뀌는 PR에서는 launcher 목록·관측 테스트·문서를 한 변경 단위로 검토한다.

## Strongest Counterargument Against Approval

승인을 지지하는 가장 강한 논지는 여분 디렉터리가 실제 프로젝트를 바꾸지 못하고, 핵심 목표인 백엔드 비밀 제거·필요한 인증 키 유지·private cache `0700` 보호가 이미 구현 및 전체 검증을 통과했다는 것이다. 따라서 추가 위치 인수는 보안 격리와 무관한 CLI 사용성 문제로 낮출 수 있다.

그럼에도 승인을 막아야 한다. 명세가 이 동작을 명시적으로 요구하고, 테스트가 구현 결손을 가린 채 PASS를 만든 사실은 경계 검증 자체의 신뢰도 문제다. launcher가 작은 사전 검증으로 직접 소유할 수 있는 불변식이므로, 명세를 사후 완화할 이유보다 구현·테스트를 맞출 이유가 강하다.

## Architectural Status

`BLOCK`

차단 해제 조건: launcher 자체의 추가 위치 인수 거부, stub 자가 거부 제거, 실제 Next CLI를 포함한 nonzero 회귀 확인.

## Trade-offs

| Option | Pros | Cons |
|---|---|---|
| Launcher의 얕은 인수 preflight | 명세를 직접 보장하고 조용한 오사용을 차단하며 Next private API를 쓰지 않음 | 값 인수 옵션 표를 Next 업그레이드 때 유지해야 함 |
| 계약에서 추가 위치 인수 거부 삭제 | 구현이 가장 단순하고 핵심 환경 격리에는 영향 없음 | 승인된 명세를 약화하고 잘못된 호출이 성공하는 운영 혼동을 남김 |
| Next Commander 구성을 재사용/복제 | CLI 문법을 더 정밀하게 해석 가능 | private API 결합 또는 과도한 옵션 복제로 유지비가 큼 |

## Validation

- `venv/bin/pytest -q tests/scripts/test_next_environment.py`: `21 passed in 2.13s`; 결함을 포함한 현재 테스트가 거짓 양성임을 재확인.
- `node --check frontend/scripts/run-next.js`: exit 0.
- `bash -n restart_all.sh`: exit 0.
- `python3 -m py_compile tests/scripts/test_next_environment.py`: exit 0.
- 제공된 상위 검증: full pytest 2048 passed / 3 skipped, Vitest 373 passed와 실제 npm build, typecheck 0, lint 0(203 warnings). 이 레인에서는 전체 suite와 서버를 재실행하지 않았다.
- 실제 Next 16.3.4 `npm run build -- unexpected-directory`가 exit 0이었다는 상위 독립 probe를 결함 근거로 사용했다. 이 레인에서는 full build를 반복하지 않았다.

## Residual Boundaries

- launcher 프로세스가 시작되기 전 부모 `NODE_OPTIONS` 실행과 실행 중 frontend env 파일 변경 감시는 승인 범위 밖이며 문서화돼 있다 (`CLAUDE.md:420`, `CLAUDE.md:427`).
- 기존 원본 cache 정리, 운영 재시작, 배포는 수행 대상이 아니며 문서가 이를 명시한다 (`CLAUDE.md:430`, `CLAUDE.md:432`).
- 원본 `.env`, `.env.production`, `.env.vertex`, `data/`, Next 3500, Flask 5501, live URL에는 접근하지 않았다. 서버·LLM·발송·매매·설정 저장·refresh·삭제·reset·배포·재시작도 수행하지 않았다.

---

# v10 Fix-wave Delta Review

## Summary

이전 `BLOCK`의 원인이었던 추가 위치 인수 책임 분리와 test-double 거짓 양성은 해소됐다. 후속 보안 검토에서 발견된 환경 참조 기반 비밀 전달, 숫자 시작 변수명 우회, `.next` 경로 교체, env parser 설치 토폴로지 결합도 같은 실행 경계 안에서 닫혔다. **최종 Architectural Status: `CLEAR`** 이다.

## Scope

- Frozen input: `docs/dev-cycle/evidence/INFRA-055/review-input-v10.json`
- Manifest SHA-256: `cb557abe0334fe95473fbdada7f5e9634d7ca8ac6f36a9af7740772b40a9e712`
- Seven-file scope aggregate SHA-256: `4ddf07460099e8cc33aa351d3dadee59f756ae492c3c36169fe281d7b92d9f2a`
- Manifest의 7개 파일은 재검토 시작 시 모두 실제 SHA-256과 일치했다.

## Analysis

### 1. 이전 추가 위치 인수 BLOCK 해소

launcher가 `spawn` 전에 옵션 토큰을 검사하고 비옵션 토큰과 `--`를 거부한다 (`frontend/scripts/run-next.js:86`, `frontend/scripts/run-next.js:89`, `frontend/scripts/run-next.js:255`). 필수 값 옵션과 선택 값 옵션을 나눠 bare optional flag를 보존하며 (`frontend/scripts/run-next.js:26`, `frontend/scripts/run-next.js:31`, `frontend/scripts/run-next.js:91`, `frontend/scripts/run-next.js:95`), 실제 Next의 unknown option/value 판정은 계속 하위 CLI에 남긴다.

stub은 더 이상 추가 위치 인수를 자체 거부하지 않고 단순히 받은 인수를 기록한다 (`tests/scripts/test_next_environment.py:47`, `tests/scripts/test_next_environment.py:67`, `tests/scripts/test_next_environment.py:68`). 따라서 위치 인수 회귀의 nonzero와 `observed.json` 부재는 launcher 자체 동작을 증명한다 (`tests/scripts/test_next_environment.py:485`, `tests/scripts/test_next_environment.py:492`, `tests/scripts/test_next_environment.py:493`). 옵션 값과 bare optional flag의 정상 전달도 별도 회귀가 고정한다 (`tests/scripts/test_next_environment.py:496`, `tests/scripts/test_next_environment.py:520`). 계획도 실제 Next 16.3이 여분 위치 인수를 무시하므로 launcher가 소유한다고 바로잡혔다 (`docs/superpowers/plans/2026-09-09-infra055-next-environment.md:26`).

### 2. 참조 기반 비밀 전달 경계 해소

허용 목록만 최종 자식에 복사해도 `NEXT_PUBLIC_API_URL=$SMTP_PASSWORD` 같은 dotenv 확장이 먼저 일어나면 비밀 값이 허용 키에 실릴 수 있다. v10은 원문 dollar를 충돌 없는 marker로 치환한 뒤 같은 `@next/env` parser로 raw key/value를 얻고 (`frontend/scripts/run-next.js:136`, `frontend/scripts/run-next.js:145`, `frontend/scripts/run-next.js:149`, `frontend/scripts/run-next.js:154`), 부모 우선순위를 반영한 effective application 값의 참조 정책을 확장 전에 검사한다 (`frontend/scripts/run-next.js:163`, `frontend/scripts/run-next.js:187`, `frontend/scripts/run-next.js:217`). 실제 확장 뒤에도 application 값을 다시 검사하므로 이스케이프 해제나 재귀 확장으로 새 참조가 남는 경우를 시작 전에 막는다 (`frontend/scripts/run-next.js:224`, `frontend/scripts/run-next.js:231`).

공개 키는 두 공개 키만, 서버 application 키는 application 허용 목록만 참조할 수 있다 (`frontend/scripts/run-next.js:23`, `frontend/scripts/run-next.js:190`, `frontend/scripts/run-next.js:191`). 참조 문법은 설치 parser의 ASCII word 범위와 맞춰 숫자 시작 이름도 잡고, `$()` 외의 bare/escaped dollar 구성을 fail closed로 처리한다 (`frontend/scripts/run-next.js:173`, `frontend/scripts/run-next.js:176`, `frontend/scripts/run-next.js:179`, `frontend/scripts/run-next.js:180`, `frontend/scripts/run-next.js:181`). 숫자 시작 두 형식과 간접·default·동적 dollar 구성의 회귀가 이를 고정한다 (`tests/scripts/test_next_environment.py:255`, `tests/scripts/test_next_environment.py:261`, `tests/scripts/test_next_environment.py:263`, `tests/scripts/test_next_environment.py:541`, `tests/scripts/test_next_environment.py:546`).

런타임 키는 root dotenv 확장 결과가 아니라 호출자 부모 환경에서만 만든다 (`frontend/scripts/run-next.js:200`, `frontend/scripts/run-next.js:204`, `frontend/scripts/run-next.js:239`, `frontend/scripts/run-next.js:240`). 따라서 root `PORT`·telemetry 키를 backend 값으로 확장해 자식으로 옮기는 우회도 차단된다 (`tests/scripts/test_next_environment.py:529`, `tests/scripts/test_next_environment.py:533`, `tests/scripts/test_next_environment.py:538`). 이 동작과 제한은 운영 문서에 동기화됐다 (`CLAUDE.md:417`, `CLAUDE.md:425`, `CLAUDE.md:428`).

### 3. 파일·의존성 경계 해소

`.next`는 `O_DIRECTORY|O_NOFOLLOW`로 연 descriptor에 `fchmod`를 적용하고, descriptor와 현재 pathname의 device/inode가 같은지 확인한다 (`frontend/scripts/run-next.js:116`, `frontend/scripts/run-next.js:119`, `frontend/scripts/run-next.js:121`, `frontend/scripts/run-next.js:122`). 안전 플래그가 없으면 파일을 읽기 전에 실패한다 (`frontend/scripts/run-next.js:196`); 플래그 부재와 경로 교체가 외부 대상 권한을 바꾸지 않는 회귀가 있다 (`tests/scripts/test_next_environment.py:555`, `tests/scripts/test_next_environment.py:576`, `tests/scripts/test_next_environment.py:620`, `tests/scripts/test_next_environment.py:622`). 문서도 지원하지 않는 플랫폼에서 fail closed하는 portability 선택을 명시한다 (`CLAUDE.md:439`, `CLAUDE.md:440`).

`@next/env`는 일반 hoisting을 가정하지 않고 실제 `NEXT_BINARY` 위치를 시작점으로 해석한다 (`frontend/scripts/run-next.js:8`, `frontend/scripts/run-next.js:9`, `frontend/scripts/run-next.js:10`). hoisted와 `next/node_modules` nested 배치 양쪽을 fixture가 검증하므로 이전 WATCH는 해소됐다 (`tests/scripts/test_next_environment.py:74`, `tests/scripts/test_next_environment.py:81`, `tests/scripts/test_next_environment.py:510`, `tests/scripts/test_next_environment.py:516`). 새 패키지나 Node 버전 상승 없이 Next가 가져온 동일 parser API를 재사용한다는 계획과도 일치한다 (`docs/superpowers/plans/2026-09-09-infra055-next-environment.md:7`, `docs/superpowers/plans/2026-09-09-infra055-next-environment.md:90`).

## Root Cause Resolution

이전 근본 원인은 launcher가 소유해야 할 실행 불변식을 Next와 test double에 분산한 것이었다. v10은 위치 인수, raw reference 정책, runtime origin, cache pathname 안전성을 모두 launcher의 preflight로 끌어오고, stub은 관측만 담당하게 바꿨다. 구현 경계와 검증 경계가 다시 일치한다 (`frontend/scripts/run-next.js:195`, `frontend/scripts/run-next.js:255`, `frontend/scripts/run-next.js:270`, `tests/scripts/test_next_environment.py:47`).

## Architectural Status

`CLEAR`

현재 frozen scope에서 병합을 막거나 COMMENT로 남길 구조 문제는 없다.

## Strongest Counterargument Against Approval

가장 강한 반론은 launcher가 Next CLI 값 옵션 목록과 dotenv reference semantics 일부를 명시적으로 모델링해 Next 업그레이드 결합을 만들고, `O_NOFOLLOW`·`O_DIRECTORY`가 없는 플랫폼을 아예 거부하며, literal dollar 표현도 보수적으로 제한한다는 점이다 (`frontend/scripts/run-next.js:26`, `frontend/scripts/run-next.js:173`, `frontend/scripts/run-next.js:196`).

이 반론은 현재 승인 차단 사유가 아니다. package lock은 Next와 parser 버전을 고정하고, 옵션·참조·nested 설치·플랫폼 플래그 회귀가 실제 경계를 검증한다. 이 저장소의 목표는 임의 환경 표현이나 모든 플랫폼 지원보다 backend 비밀이 Next 환경과 cache로 들어가지 않는 것을 우선한다 (`docs/superpowers/plans/2026-09-09-infra055-next-environment.md:5`, `docs/superpowers/plans/2026-09-09-infra055-next-environment.md:18`). 제한도 사용자 문서에 명시돼 있어 숨은 동작이 아니다 (`CLAUDE.md:425`, `CLAUDE.md:439`).

## Trade-offs

| Decision | Benefit | Cost |
|---|---|---|
| Launcher-owned option preflight | 고정 project 경로 계약을 Next 버전의 관대한 parsing과 분리 | Next 옵션 추가 시 값 옵션 표 갱신 필요 |
| 두 단계 raw/expanded reference 검사 | 허용 키를 통한 backend 비밀 전달과 재귀 dollar 구성을 차단 | 허용되는 dotenv 표현을 의도적으로 좁힘 |
| Runtime parent-only | root dotenv의 backend→PORT/telemetry 우회를 제거 | 파일 기반 runtime 설정은 더 이상 적용되지 않음 |
| no-follow 플래그 필수 | symlink 대상 chmod와 파일 추적을 fail closed | 해당 플래그가 없는 플랫폼에서는 기동 불가 |

## Validation

- v10 manifest 해시 7개 모두 일치.
- `venv/bin/pytest -q tests/scripts/test_next_environment.py`: `50 passed in 3.97s`.
- 숫자 시작 우회 재검증: synthetic `9SECRET` → `NEXT_PUBLIC_API_URL=$9SECRET`은 nonzero, child 미기동.
- `node --check frontend/scripts/run-next.js`: exit 0.
- `bash -n restart_all.sh`: exit 0.
- `venv/bin/python -m py_compile tests/scripts/test_next_environment.py`: exit 0.
- 이 레인은 전체 suite와 서버를 실행하지 않았다. 상위 full-suite 완료 여부는 leader가 최종 gate에서 별도로 확인한다.

## Stop Condition

v10 frozen scope의 이전 차단 조건과 후속 보안 우회가 구현·회귀·문서에서 모두 닫혔다. 원본 `.env` 계열, `data/`, Next 3500, Flask 5501, live URL에는 접근하지 않았고 서버·LLM·발송·매매·설정·reset·refresh·delete·배포도 실행하지 않았다.
