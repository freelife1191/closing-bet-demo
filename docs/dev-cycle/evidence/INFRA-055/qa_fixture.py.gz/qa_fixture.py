#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""INFRA-055의 실제 Next/Flask QA를 위한 격리 fixture.

이 파일은 임시 clone만 다룬다. Flask는 제품의 요청 컨텍스트, 관리자 판정, system/env
GET 핸들러를 그대로 등록하고, 그 밖의 읽기는 실제 화면을 열기 위한 작은 고정 응답만
낸다. 모든 쓰기 HTTP 메서드는 제품 핸들러에 닿기 전에 405로 막는다.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import logging
import os
import secrets
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
CLONE = ROOT / "checkout"
FRONTEND = CLONE / "frontend"
CLONE_ENV = CLONE / ".env"
FAKE_ENV = ROOT / "fake.env"
SECRETS = ROOT / "fixture-secrets.json"
ADMIN_COOKIE = ROOT / "admin-nextauth-cookie.json"
VIEWER_COOKIE = ROOT / "viewer-nextauth-cookie.json"
LEGACY_LINK_MARKER = ROOT / "legacy-link-created.json"
READY = ROOT / "ready.json"
BACKEND_LOG = ROOT / "backend.log"
NEXT_LOG = ROOT / "next.log"
NO_NETWORK_POLICY = ROOT / "no-network.sb"

ADMIN_EMAIL = "infra055-admin@example.test"
VIEWER_EMAIL = "infra055-viewer@example.test"
SAFE_ENV_KEYS = (
    "PATH", "HOME", "USER", "LOGNAME", "SHELL", "TMPDIR", "TMP", "TEMP",
    "LANG", "LC_ALL", "TZ", "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT",
)
MUTATING_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})
SENTINEL_KEYS = ("SMTP_PASSWORD", "UNKNOWN_BACKEND_SECRET", "GOOGLE_API_KEY")


class FixtureFailure(RuntimeError):
    """격리 규약을 만족하지 못했을 때 사용한다."""


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise FixtureFailure(message)


def _safe_environment() -> dict[str, str]:
    return {key: os.environ[key] for key in SAFE_ENV_KEYS if key in os.environ}


def _write_private(path: Path, content: str) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(content, encoding="utf-8")
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)
    os.chmod(path, 0o600)


def _write_json(path: Path, payload: Any) -> None:
    _write_private(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def _head() -> str:
    result = subprocess.run(
        ["git", "-C", str(CLONE), "rev-parse", "--verify", "HEAD"],
        check=False,
        capture_output=True,
        text=True,
    )
    _assert(result.returncode == 0 and bool(result.stdout.strip()), "clone HEAD를 읽지 못했습니다")
    return result.stdout.strip()


def _new_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as candidate:
        candidate.bind(("127.0.0.1", 0))
        port = int(candidate.getsockname()[1])
    _assert(port not in {3500, 5501}, "운영 포트를 fixture에 사용할 수 없습니다")
    return port


def _fixture_values(backend_port: int, next_port: int) -> dict[str, str]:
    nonce = secrets.token_hex(16)
    return {
        "GOOGLE_CLIENT_ID": "infra055-google-client",
        "NEXT_PUBLIC_GOOGLE_CLIENT_ID": "infra055-public-google-client",
        "GOOGLE_CLIENT_SECRET": "infra055-google-secret",
        "NEXTAUTH_SECRET": secrets.token_urlsafe(32),
        "NEXTAUTH_URL": f"http://127.0.0.1:{next_port}",
        "NEXTAUTH_URL_INTERNAL": f"http://127.0.0.1:{next_port}",
        "ADMIN_EMAILS": ADMIN_EMAIL,
        "ADMIN_API_TOKEN": secrets.token_urlsafe(32),
        "INTERNAL_IDENTITY_SECRET": secrets.token_urlsafe(32),
        "API_URL": f"http://127.0.0.1:{backend_port}",
        # 이 값들은 Next 경계 밖에만 있어야 한다. 값은 로그나 stdout에 내보내지 않는다.
        "SMTP_PASSWORD": f"INFRA055_BACKEND_SENTINEL_SMTP_{nonce}",
        "UNKNOWN_BACKEND_SECRET": f"INFRA055_BACKEND_SENTINEL_UNKNOWN_{nonce}",
        "GOOGLE_API_KEY": f"INFRA055_BACKEND_SENTINEL_GOOGLE_{nonce}",
        "SCHEDULER_ENABLED": "false",
    }


def _parse_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    return values


def _write_clone_env(values: dict[str, str]) -> None:
    content = "".join(f"{key}={value}\n" for key, value in values.items())
    _write_private(FAKE_ENV, content)
    _write_private(CLONE_ENV, content)


def _ensure_legacy_link() -> None:
    legacy = FRONTEND / ".env"
    if LEGACY_LINK_MARKER.exists() or LEGACY_LINK_MARKER.is_symlink():
        _assert(LEGACY_LINK_MARKER.is_file() and not LEGACY_LINK_MARKER.is_symlink(), "legacy link marker가 안전하지 않습니다")
        # run-next의 preflight가 지원하는 legacy 링크를 지울 수 있다. 이후 warm 실행에서
        # 다시 만들면 최초 준비 당시 없던 frontend .env를 되살리므로 marker만 보고 넘긴다.
        return
    if legacy.exists() or legacy.is_symlink():
        _write_json(LEGACY_LINK_MARKER, {"state": "pre-existing"})
        return
    legacy.symlink_to("../.env")
    _write_json(LEGACY_LINK_MARKER, {"state": "created"})


def _cookie_for(email: str, name: str, secret: str) -> list[dict[str, Any]]:
    script = """
const { encode } = require('next-auth/jwt');
let body = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => body += chunk);
process.stdin.on('end', async () => {
  const input = JSON.parse(body);
  const value = await encode({ token: { name: input.name, email: input.email, sub: input.email }, secret: input.secret, maxAge: 3600 });
  process.stdout.write(JSON.stringify({ name: 'next-auth.session-token', value }));
});
"""
    result = subprocess.run(
        ["/usr/bin/sandbox-exec", "-f", str(NO_NETWORK_POLICY), "node", "-e", script],
        cwd=FRONTEND,
        env=_safe_environment(),
        input=json.dumps({"email": email, "name": name, "secret": secret}),
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )
    _assert(result.returncode == 0, "가짜 NextAuth 쿠키를 만들지 못했습니다")
    payload = json.loads(result.stdout)
    _assert(payload.get("name") == "next-auth.session-token" and bool(payload.get("value")), "가짜 NextAuth 쿠키가 비어 있습니다")
    return [{"name": payload["name"], "value": payload["value"], "domain": "127.0.0.1", "path": "/", "httpOnly": True, "secure": False, "sameSite": "Lax"}]


def prepare(*, fresh_cache: bool) -> dict[str, int | str]:
    _assert(CLONE.is_dir() and FRONTEND.is_dir(), "격리 checkout이 없습니다")
    if FAKE_ENV.is_file() and SECRETS.is_file():
        _assert(not FAKE_ENV.is_symlink() and not SECRETS.is_symlink(), "기존 fixture 비밀 파일이 링크입니다")
        values = _parse_env(FAKE_ENV)
        saved = json.loads(SECRETS.read_text(encoding="utf-8"))
        backend_port, next_port = int(saved["backend_port"]), int(saved["next_port"])
        required = ("NEXTAUTH_SECRET", "ADMIN_API_TOKEN", "INTERNAL_IDENTITY_SECRET", *SENTINEL_KEYS)
        _assert(all(values.get(key) for key in required), "기존 fake.env가 불완전합니다")
    else:
        backend_port, next_port = _new_port(), _new_port()
        values = _fixture_values(backend_port, next_port)
        _write_private(FAKE_ENV, "".join(f"{key}={value}\n" for key, value in values.items()))
        _write_json(SECRETS, {"backend_port": backend_port, "next_port": next_port, "head": _head()})
    _write_clone_env(values)
    _ensure_legacy_link()
    # 쿠키는 시작 직전에 항상 새로 만든다. warm cache는 보존하지만 만료된 세션은 재사용하지 않는다.
    _write_json(ADMIN_COOKIE, _cookie_for(ADMIN_EMAIL, "INFRA-055 Admin", values["NEXTAUTH_SECRET"]))
    _write_json(VIEWER_COOKIE, _cookie_for(VIEWER_EMAIL, "INFRA-055 Viewer", values["NEXTAUTH_SECRET"]))
    if fresh_cache:
        cache = FRONTEND / ".next"
        if cache.exists() or cache.is_symlink():
            _assert(cache.is_dir() and not cache.is_symlink(), "fixture는 링크 .next를 지우지 않습니다")
            shutil.rmtree(cache)
    # 값 자체가 아닌 경로, 포트, HEAD만 출력 가능한 준비 정보다.
    return {"backend_port": backend_port, "next_port": next_port, "head": _head()}


def _fixture_context() -> Any:
    from app.routes.common_route_context import CommonRouteContext

    def no_op(*_args: Any, **_kwargs: Any) -> None:
        return None

    return CommonRouteContext(
        logger=logging.getLogger("infra055.fixture"), update_lock=None, update_status_file=str(ROOT / "update-status.json"),
        load_update_status=lambda *_args, **_kwargs: {}, start_update=no_op, update_item_status=no_op,
        stop_update=no_op, finish_update=no_op, run_background_update=no_op, paper_trading=None,
    )


def _configure_backend_environment() -> dict[str, str]:
    _assert(CLONE_ENV.is_file() and not CLONE_ENV.is_symlink(), "clone .env fixture가 없습니다")
    values = _parse_env(CLONE_ENV)
    _assert(all(values.get(key) for key in ("ADMIN_API_TOKEN", "INTERNAL_IDENTITY_SECRET", "ADMIN_EMAILS")), "필수 fake 관리자 키가 없습니다")
    inherited = _safe_environment()
    os.chdir(CLONE)
    os.environ.clear()
    os.environ.update(inherited)
    os.environ.update(values)
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    sys.path.insert(0, str(CLONE))
    return values


def build_backend_app() -> Any:
    from flask import Blueprint, Flask, jsonify, request, g

    # 제품의 request context와 실제 관리자/system-env 등록 함수를 그대로 쓴다.
    from app import _register_request_context
    from app.routes.common_admin_routes import register_common_admin_routes
    from app.routes.common_update_routes import _register_manage_env_route

    app = Flask("infra055-isolated-fixture")
    _register_request_context(app)

    @app.before_request
    def block_all_mutations() -> Any:
        if request.method in MUTATING_METHODS:
            return jsonify({"error": "QA fixture blocks writes"}), 405
        return None

    @app.after_request
    def record_response(response: Any) -> Any:
        email = g.get("user_email")
        role = "admin" if email == ADMIN_EMAIL else "viewer" if email == VIEWER_EMAIL else "anonymous"
        with (ROOT / "requests.jsonl").open("a", encoding="utf-8") as output:
            output.write(json.dumps({"at": time.time(), "pid": os.getpid(), "method": request.method, "path": request.path, "status": response.status_code, "verified_identity": role}) + "\n")
        return response

    common_bp = Blueprint("infra055_common", __name__)
    context = _fixture_context()
    register_common_admin_routes(common_bp, context)
    _register_manage_env_route(common_bp, context)
    app.register_blueprint(common_bp, url_prefix="/api")

    # SettingsModal/sidebar의 읽기만 고정 응답으로 제공한다. market-gate는 외부 수집을
    # 부르지 않는 보조 fixture이며, 실제 market-gate 제품 핸들러를 가져오지 않는다.
    @app.get("/api/kr/user/quota")
    def fixture_quota() -> Any:
        return jsonify({"usage": 0, "limit": 10, "remaining": 10})

    @app.get("/api/kr/config/interval")
    def fixture_interval() -> Any:
        return jsonify({"interval": 30})

    @app.get("/api/kr/market-gate")
    def fixture_market_gate() -> Any:
        return jsonify({"total_score": 72, "score": 72, "label": "QA fixture", "status": "GREEN", "kospi_close": 0, "kospi_change_pct": 0, "kosdaq_close": 0, "kosdaq_change_pct": 0, "sectors": []})

    @app.get("/api/kr/signals")
    def fixture_signals() -> Any:
        return jsonify({"signals": [], "total_scanned": 0, "source": "qa-fixture"})

    @app.get("/api/kr/status")
    @app.get("/api/kr/data-status")
    def fixture_data_status() -> Any:
        return jsonify({"last_update": None, "collected_stocks": 0, "signals_count": 0, "market_status": "GRAY", "files": {}})

    @app.get("/api/kr/backtest-summary")
    def fixture_backtest_summary() -> Any:
        empty = {"status": "PENDING", "count": 0, "win_rate": 0, "avg_return": 0}
        return jsonify({"vcp": empty, "closing_bet": empty})

    return app


def backend_main(port: int) -> int:
    from werkzeug.serving import make_server

    _configure_backend_environment()
    app = build_backend_app()

    server = make_server("127.0.0.1", port, app)
    server.timeout = 1
    while True:
        server.handle_request()


def _identity_header(email: str, secret: str, method: str, path: str) -> str:
    encoded_email = base64.urlsafe_b64encode(email.encode("utf-8")).decode("ascii").rstrip("=")
    expires = str(int(time.time()) + 120)
    encoded_path = base64.urlsafe_b64encode(path.encode("utf-8")).decode("ascii").rstrip("=")
    payload = f"v2.{encoded_email}.{expires}.{method}.{encoded_path}"
    signature = hmac.new(secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"v2.{encoded_email}.{expires}.{signature}"


def backend_check() -> int:
    values = _configure_backend_environment()
    before = CLONE_ENV.read_bytes()
    client = build_backend_app().test_client()
    _assert(client.get("/api/system/env").status_code == 403, "실제 env 토큰 검증이 닫히지 않았습니다")
    identity = _identity_header(ADMIN_EMAIL, values["INTERNAL_IDENTITY_SECRET"], "GET", "/api/admin/check")
    admin = client.get("/api/admin/check", headers={"X-Auth-Identity": identity})
    _assert(admin.status_code == 200 and admin.get_json() == {"isAdmin": True}, "실제 admin/check이 관리자 신원을 확인하지 못했습니다")
    env_response = client.get("/api/system/env", headers={"X-Admin-Token": values["ADMIN_API_TOKEN"]})
    _assert(env_response.status_code == 200, "실제 system/env GET이 실패했습니다")
    body = env_response.get_data()
    _assert(all(values[key].encode("utf-8") not in body for key in SENTINEL_KEYS), "마스킹 응답에 backend sentinel이 있습니다")
    blocked = client.post("/api/system/env", headers={"X-Admin-Token": values["ADMIN_API_TOKEN"]}, json={"SMTP_PASSWORD": "changed"})
    _assert(blocked.status_code == 405 and CLONE_ENV.read_bytes() == before, "fixture가 system/env 쓰기를 막지 못했습니다")
    print(json.dumps({"actual_request_context": True, "actual_admin_check": True, "actual_env_get": True, "post_blocked": True}))
    return 0


def scan_caches() -> int:
    values = _parse_env(CLONE_ENV)
    cache = FRONTEND / ".next"
    _assert(cache.is_dir() and not cache.is_symlink(), "검사할 실제 .next 캐시가 없습니다")
    fixture_head = str(json.loads(SECRETS.read_text(encoding="utf-8"))["head"])
    parent_sentinels = (
        f"INFRA055_PARENT_SMTP_{fixture_head[:12]}",
        f"INFRA055_PARENT_UNKNOWN_{fixture_head[:12]}",
        f"INFRA055_PARENT_GOOGLE_{fixture_head[:12]}",
    )
    needles = [values[key].encode("utf-8") for key in SENTINEL_KEYS]
    needles.extend(value.encode("utf-8") for value in parent_sentinels)
    matches = 0
    artifacts = 0
    filesystem_cache_files = 0
    for path in cache.rglob("*"):
        if not path.is_file() or path.is_symlink():
            continue
        artifacts += 1
        if "cache" in path.relative_to(cache).parts and path.suffix == ".sst":
            filesystem_cache_files += 1
        data = path.read_bytes()
        matches += sum(data.count(needle) for needle in needles)
    cache_mode = cache.stat().st_mode & 0o777
    print(json.dumps({"next_mode": f"{cache_mode:04o}", "cache_artifacts": artifacts, "filesystem_cache_files": filesystem_cache_files, "backend_sentinel_matches": matches}))
    return 0 if cache_mode == 0o700 and filesystem_cache_files > 0 and matches == 0 else 1


def main() -> int:
    parser = argparse.ArgumentParser(description="INFRA-055 isolated QA fixture")
    subparsers = parser.add_subparsers(dest="command", required=True)
    prepare_parser = subparsers.add_parser("prepare")
    prepare_parser.add_argument("--fresh-cache", action="store_true")
    backend_parser = subparsers.add_parser("backend")
    backend_parser.add_argument("--port", type=int, required=True)
    subparsers.add_parser("backend-check")
    subparsers.add_parser("scan-caches")
    args = parser.parse_args()
    try:
        if args.command == "prepare":
            print(json.dumps(prepare(fresh_cache=args.fresh_cache)))
            return 0
        if args.command == "backend":
            return backend_main(args.port)
        if args.command == "backend-check":
            return backend_check()
        return scan_caches()
    except (FixtureFailure, OSError, ValueError, json.JSONDecodeError) as error:
        print(f"fixture error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
