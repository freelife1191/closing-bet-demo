# CODE REVIEW REPORT — INFRA-055 독립 코드 레인

**기준:** `97113d4de47be2a4567e7c8587fbf88f7635a8bc`

**검토 파일:** 6개

- `frontend/scripts/run-next.js`
- `frontend/package.json`
- `restart_all.sh`
- `tests/scripts/test_next_environment.py`
- `.env.example`
- `CLAUDE.md`

**명세:** `docs/superpowers/plans/2026-09-09-infra055-next-environment.md`

**입력 무결성:** `docs/dev-cycle/evidence/INFRA-055/review-input.json`의 구현·테스트·명세 SHA-256 7개를 현재 파일과 대조했으며 모두 일치했다.

## 결과

**Total Issues: 1**

- CRITICAL: 0
- HIGH: 0
- MEDIUM: 1
- LOW: 0

### [MEDIUM] 추가 프로젝트 위치 인수를 실제 실행기가 거부하지 않으며 테스트 더블이 거부 동작을 대신 만들어낸다

**파일:** `frontend/scripts/run-next.js:147`, `tests/scripts/test_next_environment.py:66-67`, `tests/scripts/test_next_environment.py:410-417`

**문제:** 명세 `docs/superpowers/plans/2026-09-09-infra055-next-environment.md:26`은 고정 frontend 디렉터리 뒤에 전달된 두 번째 위치 인수를 거부하도록 요구한다. 실행기는 모든 `options`를 검증 없이 Next CLI에 넘긴다. 테스트 더블은 `process.argv.slice(4)`의 비옵션 인수를 발견하면 임의로 exit 2를 반환하므로 테스트는 통과하지만, 실제 Next 16 CLI는 초과 위치 인수를 거부하지 않는다. 현재 입력과 함께 남은 실측 `docs/dev-cycle/evidence/INFRA-055/extra-directory-red.json`은 `npm run build -- unexpected-directory`가 기대 exit 1과 달리 exit 0이었다고 기록한다.

**위험:** 운영자 오타나 잘못된 자동화 인수가 조용히 무시된 채 실제 frontend 빌드가 성공한다. 고정 프로젝트 자체가 다른 디렉터리로 바뀌지는 않지만, 명시된 fail-closed CLI 계약이 구현되지 않았고 회귀 테스트가 실제 Next 동작을 잘못 모델링해 이를 숨긴다.

**수정:** spawn 전에 명령별 옵션 문법을 기준으로 추가 위치 인수를 실행기에서 거부한다. `dev/start`의 `-p 4000`, `-H host`, `--keepAliveTimeout 70000`처럼 분리된 옵션 값과 `--port=4000` 형식은 계속 허용해야 한다. 테스트 더블의 자체 `extraDirectory ? 2` 동작을 제거하고, 추가 위치 인수 입력에서는 자식이 시작되지 않아 `observed.json`이 생성되지 않으며 실행기 자체가 비영(非零)으로 끝나는지 검증한다. 실제 Next CLI를 사용한 작은 회귀도 유지해 테스트 더블과 실사용 CLI의 의미가 다시 갈리지 않게 한다.

## 검증 근거

- 직접 실행: `pytest -q -p no:cacheprovider tests/scripts/test_next_environment.py` → **21 passed**. 위 이슈처럼 테스트 더블이 실제 CLI와 다른 동작을 구현하므로 이 통과만으로 추가 위치 인수 계약은 증명되지 않는다.
- 직접 실행: `node --check frontend/scripts/run-next.js`, `bash -n restart_all.sh`, Python `ast.parse`, `git diff --check` → 모두 exit 0.
- 정적 진단: `frontend/scripts/run-next.js`와 `frontend/package.json`에 대해 TypeScript 프로젝트 진단 0건. Python·Shell·dotenv·Markdown 파일은 해당 LSP 백엔드가 없어 `tsc skipped`였으며, Python AST와 shell 구문 검사로 보완했다.
- AST 패턴 검사: 새 실행기에서 `console.log`, 빈 catch, 문자열 하드코딩 대입 패턴 없음. 테스트에서 빈 Python 예외 처리 패턴 없음.
- 보존된 전체 검증 증거 확인(재실행하지 않음): pytest **2048 passed, 3 skipped**; Vitest **57 files / 373 tests passed**; typecheck exit 0; lint **0 errors / 203 warnings**. lint 경고 중 새 실행기의 CommonJS `require` 4건은 현재 CommonJS 진입점 설계에서 비차단으로 판단했다.
- 실제 Next 추가 위치 인수 probe는 별도 증거에서 exit 0을 확인했다. 전체 빌드·전체 테스트는 중복 실행하지 않았다.
- 실제 `.env`, `.env.production`, `.env.vertex`, `data/`는 읽지 않았고 Next/Flask/live 서버에 요청하지 않았다. 재시작·배포·외부 호출도 실행하지 않았다.

환경 키 allowlist, 부모 우선순위와 `NODE_ENV` 정규화, env 입력의 일반 파일·symlink 검사, 비밀 값을 포함하지 않는 오류 메시지, `.next` 0700 보존, 자식 종료 상태와 신호 전파에서는 별도 이슈를 발견하지 못했다.

## Recommendation

**REQUEST CHANGES**

명세의 추가 위치 인수 거부를 실행기 경계에서 구현하고, 실제 자식 미실행을 확인하는 회귀 테스트로 교체한 뒤 재검토해야 한다. 아키텍처 판정은 별도 agent 범위다.

---

# v10 FIX-WAVE DELTA REVIEW

**입력:** `docs/dev-cycle/evidence/INFRA-055/review-input-v10.json`

**입력 무결성:** 구현·테스트·명세 SHA-256 7개를 현재 소스와 대조했으며 모두 일치했다.

**Files Reviewed:** 6

**Total Issues:** 0

- CRITICAL: 0
- HIGH: 0
- MEDIUM: 0
- LOW: 0

## 이전 차단점 및 후속 보안 점검

- **추가 위치 인수:** `frontend/scripts/run-next.js:86-100,248-270`에서 실행 전 옵션 문법을 검사한다. 추가 위치 인수와 `--`는 자식을 시작하기 전에 거부하며, 분리된 필수 옵션 값과 bare 선택값 옵션을 보존한다. `tests/scripts/test_next_environment.py:485-538`이 자식 미기동, 필수값 옵션 전달, 선택값 옵션 전달을 검증한다. 이전 테스트 더블의 자체 위치 인수 거부는 제거됐다.
- **dotenv 참조 경계:** `frontend/scripts/run-next.js:136-193,210-231`에서 설치된 `@next/env`로 원시 파싱 후 실제 파싱 상태를 복원한다. 숫자로 시작하는 ASCII word 참조도 검사하며, public 값은 두 public 키만, private application 값은 application allowlist만 참조할 수 있다. 이스케이프/`$$`로 재귀 중 새 참조를 합성하는 표현은 fail closed이고 inert `$(`만 보존한다. 갱신된 명세 `docs/superpowers/plans/2026-09-09-infra055-next-environment.md:86-97` 및 운영 문서 `CLAUDE.md:425-431`과 일치한다.
- **runtime-key 우회:** `frontend/scripts/run-next.js:198-208,239-245`에서 runtime 값은 부모에서만 취한다. root dotenv의 `PORT=$SMTP_PASSWORD` 또는 `NEXT_TELEMETRY_DISABLED=$SMTP_PASSWORD`가 자식으로 들어가던 재현은 `tests/scripts/test_next_environment.py:529-538`로 닫혔다.
- **파일 경계:** `frontend/scripts/run-next.js:37-61,102-130,195-196`은 `O_NOFOLLOW`/`O_DIRECTORY`가 없으면 기동을 거부하고, `.next`를 descriptor로 열어 `fchmod`/`fstat`한 뒤 path의 dev/inode를 재대조한다. 외부 symlink 대상 chmod 우회와 silent platform fallback 회귀가 추가됐다.
- **의존성 경계:** `frontend/scripts/run-next.js:8-11`은 실제 Next 바이너리를 기준으로 `@next/env`를 resolve하여 hoisted 설치 가정을 제거했다. 신규 의존성이나 Node floor 변경은 없다.

## v10 직접 검증

- `pytest -q -p no:cacheprovider tests/scripts/test_next_environment.py` → **50 passed in 4.13s**.
- `node --check frontend/scripts/run-next.js`, `bash -n restart_all.sh`, Python `ast.parse`, `git diff --check` → 모두 exit 0.
- LSP: `frontend/scripts/run-next.js`, `frontend/package.json` TypeScript 프로젝트 진단 0건. Python·Shell·dotenv·Markdown은 backend 부재로 `tsc skipped`; Python AST와 shell 구문 검사로 보완했다.
- AST 패턴: 새 실행기의 `console.log`, 빈 catch, 문자열 비밀 대입 없음. Python 테스트의 빈 예외 처리 없음.
- 전체 pytest/Vitest와 actual Next extra-positional probe는 상위 검증 레인에서 실행 중이므로 이 delta에서 중복 실행하지 않았다. 이 결과는 코드 레인 판정이며 전체 QA/아키텍처/보안 독립 레인의 최종 게이트를 대체하지 않는다.
- 실제 `.env`, `.env.production`, `.env.vertex`, `data/`와 원본 저장소는 읽거나 변경하지 않았다. Next/Flask/live 서버 요청, 서버 기동·재시작, 외부 호출, 배포도 수행하지 않았다.

## v10 Recommendation

**APPROVE**

v10 범위에서 명세·보안·품질·성능·유지보수 관점의 남은 코드 이슈를 찾지 못했다. 이전 `REQUEST CHANGES`는 이 delta 판정으로 대체한다. 아키텍처 상태는 별도 agent가 판정한다.
