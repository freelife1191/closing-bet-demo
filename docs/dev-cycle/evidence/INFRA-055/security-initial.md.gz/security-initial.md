# INFRA-055 독립 보안 리뷰 — 최초 판정

- 기준: `security-review`의 OWASP A01–A10, 시크릿, 입력·경로, 인증·인가, 의존성 기준
- 기준 커밋: `97113d4`
- 검토 파일: `frontend/scripts/run-next.js`, `frontend/package.json`, `restart_all.sh`, `tests/scripts/test_next_environment.py`, `.env.example`, `CLAUDE.md`, 승인 계획
- 검토 입력 SHA-256 묶음: `0f5d2d2b93cd6695b3ebff5c3508d03190a292ab90121f74178220e489d48ca0`
- 실행기 SHA-256: `429144cd29839cee002178fb55923ab88093c0a48247ca128bde1d0d7f86877b`
- 판정: **REQUEST CHANGES**
- 이슈: CRITICAL 0 / HIGH 0 / MEDIUM 1 / LOW 1

## 발견 사항

### [MEDIUM, 높은 신뢰도] 허용 키 확장이 백엔드·private 비밀값을 Next/public 환경으로 운반함

- 위치: `frontend/scripts/run-next.js:89`, `frontend/scripts/run-next.js:122`
- OWASP: A02 Cryptographic Failures, A05 Security Misconfiguration
- 근거: 실행기는 루트 환경 파일의 허용·비허용 키를 모두 `processEnv`에 넣어 먼저 확장하고, 확장이 끝난 뒤 키 이름만 `CHILD_KEYS`로 거릅니다. 따라서 허용된 sink가 비허용 backend 키를 참조하면 비밀값이 허용 키의 값으로 바뀌어 필터를 통과합니다. `NEXT_PUBLIC_*` sink이면 Next가 브라우저 번들에 넣을 수 있습니다. 허용된 private 키도 같은 방식으로 public sink에 들어갈 수 있습니다.
- 합성 재현: 루트 `.env.production`에 `SMTP_PASSWORD=QA_BACKEND_SENTINEL`과 `NEXT_PUBLIC_API_URL=$SMTP_PASSWORD`를 둔 소유 fixture에서 launcher가 exit 0이었고, Next 자식의 `NEXT_PUBLIC_API_URL` 값이 해당 backend sentinel이었습니다. 실제 비밀은 사용하거나 출력하지 않았습니다.
- 영향: 배포 설정의 변수 참조 한 줄이 backend 전용 자격 증명 또는 Next server 전용 인증값을 Next 자식과 public 산출물에 노출할 수 있어, 이 변경의 핵심 격리 보장을 깨뜨립니다. 공격자가 아닌 운영 설정 실수도 트리거가 될 수 있습니다.
- 수정: 최종 확장 전에 `@next/env`가 파싱한 raw assignment의 참조 그래프를 검사하십시오. application sink는 application allowlist 밖의 키를 참조하지 못하게 하고, `NEXT_PUBLIC_*` sink는 private application 키를 참조하지 못하게 해야 합니다. `${X}`, `$X`, `${X:-...}`, 중첩 default와 escaped `\$`를 실제 parser 의미와 일치시켜야 합니다. 위 backend→public 및 parent private→public 사례가 값 미출력·spawn 전 실패하는 회귀 테스트를 추가하십시오.

### [LOW, 높은 신뢰도] `.next` 검사와 경로 기반 chmod 사이 교체로 외부 대상 권한이 변경됨

- 위치: `frontend/scripts/run-next.js:104`, `frontend/scripts/run-next.js:111`, `frontend/scripts/run-next.js:112`
- OWASP/CWE: A01 Broken Access Control, A04 Insecure Design / CWE-367 TOCTOU
- 근거: 첫 `lstatSync`가 실제 디렉터리를 확인한 뒤 `chmodSync(path)`가 같은 경로를 다시 따라갑니다. 그 사이 `.next`를 symlink로 바꾸면 chmod는 링크 대상을 변경하고, 뒤의 lstat는 이미 발생한 외부 변경 뒤에 실패합니다.
- 합성 재현: 첫 검사 뒤 chmod 직전에 `.next`를 외부 fixture 디렉터리 링크로 바꾸자 launcher는 generic exit 1이었지만 외부 대상 mode가 `0755`에서 `0700`으로 바뀌었습니다. fixture는 임시 경로에서 정리했습니다.
- 영향: 같은 UID 또는 checkout 디렉터리 쓰기 권한을 가진 동시 주체가 있어야 하며, 이 저장소의 일반적인 신뢰된 로컬 운영자 모델에서는 추가 권한 획득보다 외부 파일 mode 변경·가용성 훼손이 주된 영향입니다. 그래서 LOW로 평가합니다. 다만 계획의 foreign-file preservation 보장은 현재 성립하지 않습니다.
- 수정: `.next`를 `O_DIRECTORY | O_NOFOLLOW`로 열고 같은 descriptor에 `fstat`·`fchmod`를 적용한 뒤 `finally`에서 닫으십시오. spawn 전 경로도 다시 확인하고, lstat 뒤 교체 fixture가 외부 대상 mode를 보존하는 회귀를 두십시오.

## 명세·경계 확인

- 승인된 공통 npm 경계와 backend-only 키 제외 방향은 맞습니다. `package.json`의 dependency 버전은 바뀌지 않았습니다.
- `ADMIN_API_TOKEN`과 `INTERNAL_IDENTITY_SECRET`은 기존 Next 서버 기능에 필요하고 공개 키가 아니므로 자식 전달 자체는 승인 범위입니다. private cache의 `0700` 보호와 잔존 가능성도 문서에 명시되어 있습니다.
- 기존 cache 삭제, 배포, 원본 실행 프로세스 갱신, launcher 시작 전 부모 Node 초기화 옵션 차단, 실행 중 frontend 파일 감시는 승인 범위 밖으로 올바르게 남았습니다.
- 현재 실행기는 추가 positional을 spawn 전에 거부하지 않습니다(`frontend/scripts/run-next.js:131`, `frontend/scripts/run-next.js:147`). 실제 Next 16.3이 이를 exit 0으로 무시한다는 별도 증거가 있어 승인 계획과 불일치합니다. 고정 `FRONTEND_DIRECTORY` 때문에 이번 보안 검토에서는 경로 전환 exploit을 확인하지 못했으며, 이 항목은 일반 코드/명세 리뷰에서 수정해야 할 비보안 Stage 1 결함으로 기록합니다.

## 실제 실행한 검사

- `venv/bin/python -m pytest -q tests/scripts/test_next_environment.py`: 21 passed
- `node --check frontend/scripts/run-next.js`: exit 0
- `bash -n restart_all.sh`: exit 0
- 변경 파일 whitespace 검사: 출력 없음
- LSP: `frontend/scripts/run-next.js`와 `frontend/package.json`은 TypeScript project 진단 0건. Python, shell, env, Markdown은 제공 LSP가 `tsc skipped: no tsconfig found`로 미지원이므로 PASS로 계산하지 않음
- AST 패턴: launcher의 `console.log`, 빈 catch, 문자열 대입형 hardcoded secret 패턴 없음. 테스트의 빈 Python except 패턴 없음
- 지정 파일 시크릿 패턴 정적 검색: 실제 키·private key 패턴 없음. `.env.example`의 예시 placeholder만 확인
- `git ls-files`의 `.env*`: `.env.example`만 추적
- 합성 fixture: backend/private 값 확장 누출 재현, `.next` symlink 교체 후 외부 chmod 재현. 원본 환경·서버·데이터 미접촉

## 실행하지 않은 검사

- `npm audit` 및 외부 CVE 조회: dependency/version 변경이 없고 요청 범위에서 제외되어 실행하지 않음. 의존성 취약점 PASS를 주장하지 않음
- 전체 pytest/Vitest/build/typecheck/lint: 상위 사이클의 기존 증거를 중복 실행하지 않음. 이번 독립 판정은 targeted 검사만 근거로 함
- 실제 `.env`, `.env.production`, `.env.vertex`, `data/` 읽기·변경: 금지 범위라 미실행
- 원본 Next 3500, Flask 5501, live URL 및 market-gate 요청: 금지 범위라 미실행
- 실제 LLM, 발송, 매매, 설정 저장, refresh/delete/reset, 배포·재시작: 미실행
- 실제 browser/cache QA: 후속 UltraQA 범위라 미실행

## 권고

**REQUEST CHANGES.** MEDIUM 비밀값 운반 경로와 LOW `.next` 외부 chmod 경로를 닫고, 추가 positional 명세 결함도 수정한 뒤 동일 합성 회귀와 정적 검사를 재실행해야 합니다.
