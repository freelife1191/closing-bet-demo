# INFRA-055 독립 보안 리뷰

## 최종 재검토 — v10

- frozen manifest: `docs/dev-cycle/evidence/INFRA-055/review-input-v10.json`
- 범위 aggregate SHA-256: `4ddf07460099e8cc33aa351d3dadee59f756ae492c3c36169fe281d7b92d9f2a`
- 판정: **APPROVE**
- 미해결 이슈: CRITICAL 0 / HIGH 0 / MEDIUM 0 / LOW 0

### 최초 발견 사항 해소

- 최초 MEDIUM secret smuggling은 `frontend/scripts/run-next.js:136`–`frontend/scripts/run-next.js:193`의 raw-reference pass와 `frontend/scripts/run-next.js:231`의 확장 결과 재검사로 닫혔습니다. application 값은 application allowlist만, public 값은 두 public 키만 참조할 수 있습니다. 숫자 시작 참조, braced/default/nested 참조, escaped variable-like dollar, bare dollar, `$$` 동적 이름 합성도 fail-closed입니다. 실제 parser에서 inert한 `$()`만 literal로 유지합니다.
- 루트 dotenv가 runtime key를 통해 값을 운반하는 갈래는 `frontend/scripts/run-next.js:239`–`frontend/scripts/run-next.js:245`에서 runtime을 부모 프로세스 값으로만 구성해 닫혔습니다.
- 최초 LOW `.next` TOCTOU는 `frontend/scripts/run-next.js:102`–`frontend/scripts/run-next.js:130`에서 `O_DIRECTORY | O_NOFOLLOW`로 연 descriptor에 `fstat`·`fchmod`를 적용하고 path의 dev/ino를 재대조해 닫혔습니다. 보안 플래그가 없거나 0인 플랫폼은 `frontend/scripts/run-next.js:196`에서 설정 파일을 읽기 전에 실패합니다.
- 추가 positional은 `frontend/scripts/run-next.js:86`–`frontend/scripts/run-next.js:100`에서 spawn 전에 거부합니다. 설치된 Next의 필수값·선택값 옵션은 분리하며, 고정 project directory는 `frontend/scripts/run-next.js:270`에서 항상 먼저 전달됩니다.
- `@next/env`는 `frontend/scripts/run-next.js:8`–`frontend/scripts/run-next.js:11`에서 실제 Next 설치를 기준으로 해석하므로 hoisted/nested 배치 모두 같은 parser를 사용합니다.

### 재검토에서 실제 확인한 증거

- v10 manifest 7개 SHA-256이 현재 파일과 모두 일치
- `venv/bin/python -m pytest -q tests/scripts/test_next_environment.py`: **50 passed in 4.12s**
- 최초 재현인 backend→public, parent private→file public, 숫자 시작 키, escaped/recursive dollar, 동적 `$$` 이름 구성, runtime smuggling, `.next` path swap, 안전 플래그 부재가 모두 회귀 행렬에 포함되어 spawn 전 실패 또는 외부 mode 보존을 확인
- `node --check frontend/scripts/run-next.js`: exit 0
- `bash -n restart_all.sh`: exit 0
- `npm run type-check`: exit 0
- `npx eslint scripts/run-next.js`: exit 0, error 0, CommonJS `require()` 경고 5건
- 정확한 v10 frozen snapshot에 대한 독립 code-review lane 증거: JS/package LSP 진단 0건, AST 위험 패턴 0건, 이슈 0, APPROVE. 보안 lane에서 LSP/AST MCP 재호출은 `Transport closed`로 실패했으므로 이 사실을 숨기지 않고 해당 exact-hash 증거와 직접 typecheck/syntax 결과를 사용했습니다.
- 지정 파일의 실제 key/private-key 패턴 정적 검색 결과 없음. `.env.example`의 placeholder만 존재
- `git ls-files`의 `.env*` 추적 파일은 `.env.example`만 확인
- 실제 `.env*`, `data/`, 원본·live 서버 및 외부 네트워크에 접근하지 않음

### 실행하지 않은 검사와 남은 경계

- `npm audit`·외부 CVE 조회는 dependency/version 변경이 없고 승인 범위에서 제외되어 실행하지 않았습니다. 의존성 취약점 PASS를 주장하지 않습니다.
- 전체 pytest/Vitest/build/full lint는 이 독립 재검토에서 중복 실행하지 않았습니다. 상위 사이클이 보유한 이전 전체 검사 결과와 현재 실행 중인 후속 검증을 이 보고서의 독립 PASS로 바꾸어 적지 않습니다.
- 실제 browser/cache QA는 후속 UltraQA 대상입니다. 새 cache와 public 산출물의 backend sentinel 0건은 그 단계에서 확인해야 합니다.
- 공개 변수에 비밀 문자열을 직접 복사하는 신뢰된 운영자 오설정, launcher 시작 전 부모 Node 초기화 옵션, 실행 중 같은 UID의 지속적인 파일 교체는 이 경계가 자동 판별·감시하지 않습니다. 이 제한은 `CLAUDE.md:422`, `CLAUDE.md:430`, `CLAUDE.md:436`에 명시되어 있습니다.
- 기존 cache 삭제와 배포·실행 프로세스 갱신은 제외 범위입니다. 필요한 Next server 인증키가 private cache에 남을 수 있어 `.next`의 `0700` 보호가 계속 필요합니다.

### 최종 권고

**APPROVE.** 승인된 Next 자식 환경 경계에서 secret exposure, command injection, project path bypass, access-control key 손실, symlink-following 외부 chmod에 대한 미해결 보안 이슈를 찾지 못했습니다. 후속 실제 cache/browser QA가 배포 전 동적 증거를 완성해야 합니다.

---

## 최초 판정 보존

- 기준: `security-review`의 OWASP A01–A10, 시크릿, 입력·경로, 인증·인가, 의존성 기준
- 기준 커밋: `97113d4`
- 검토 파일: `frontend/scripts/run-next.js`, `frontend/package.json`, `restart_all.sh`, `tests/scripts/test_next_environment.py`, `.env.example`, `CLAUDE.md`, 승인 계획
- 검토 입력 SHA-256 묶음: `0f5d2d2b93cd6695b3ebff5c3508d03190a292ab90121f74178220e489d48ca0`
- 실행기 SHA-256: `429144cd29839cee002178fb55923ab88093c0a48247ca128bde1d0d7f86877b`
- 판정: **REQUEST CHANGES**
- 이슈: CRITICAL 0 / HIGH 0 / MEDIUM 1 / LOW 1

## 발견 사항

### [MEDIUM, 높은 신뢰도] 허용 키 확장이 백엔드·private 비밀값을 Next/public 환경으로 운반함

- 위치: `frontend/scripts/run-next.js:89`, `frontend/scripts/run-next.js:122`
- OWASP: A02 Cryptographic Failures, A05 Security Misconfiguration
- 근거: 실행기는 루트 환경 파일의 허용·비허용 키를 모두 `processEnv`에 넣어 먼저 확장하고, 확장이 끝난 뒤 키 이름만 `CHILD_KEYS`로 거릅니다. 따라서 허용된 sink가 비허용 backend 키를 참조하면 비밀값이 허용 키의 값으로 바뀌어 필터를 통과합니다. `NEXT_PUBLIC_*` sink이면 Next가 브라우저 번들에 넣을 수 있습니다. 허용된 private 키도 같은 방식으로 public sink에 들어갈 수 있습니다.
- 합성 재현: 루트 `.env.production`에 `SMTP_PASSWORD=QA_BACKEND_SENTINEL`과 `NEXT_PUBLIC_API_URL=$SMTP_PASSWORD`를 둔 소유 fixture에서 launcher가 exit 0이었고, Next 자식의 `NEXT_PUBLIC_API_URL` 값이 해당 backend sentinel이었습니다. 실제 비밀은 사용하거나 출력하지 않았습니다.
- 영향: 배포 설정의 변수 참조 한 줄이 backend 전용 자격 증명 또는 Next server 전용 인증값을 Next 자식과 public 산출물에 노출할 수 있어, 이 변경의 핵심 격리 보장을 깨뜨립니다. 공격자가 아닌 운영 설정 실수도 트리거가 될 수 있습니다.
- 수정: 최종 확장 전에 `@next/env`가 파싱한 raw assignment의 참조 그래프를 검사하십시오. application sink는 application allowlist 밖의 키를 참조하지 못하게 하고, `NEXT_PUBLIC_*` sink는 private application 키를 참조하지 못하게 해야 합니다. `${X}`, `$X`, `${X:-...}`, 중첩 default와 escaped `\$`를 실제 parser 의미와 일치시켜야 합니다. 위 backend→public 및 parent private→public 사례가 값 미출력·spawn 전 실패하는 회귀 테스트를 추가하십시오.

### [LOW, 높은 신뢰도] `.next` 검사와 경로 기반 chmod 사이 교체로 외부 대상 권한이 변경됨

- 위치: `frontend/scripts/run-next.js:104`, `frontend/scripts/run-next.js:111`, `frontend/scripts/run-next.js:112`
- OWASP/CWE: A01 Broken Access Control, A04 Insecure Design / CWE-367 TOCTOU
- 근거: 첫 `lstatSync`가 실제 디렉터리를 확인한 뒤 `chmodSync(path)`가 같은 경로를 다시 따라갑니다. 그 사이 `.next`를 symlink로 바꾸면 chmod는 링크 대상을 변경하고, 뒤의 lstat는 이미 발생한 외부 변경 뒤에 실패합니다.
- 합성 재현: 첫 검사 뒤 chmod 직전에 `.next`를 외부 fixture 디렉터리 링크로 바꾸자 launcher는 generic exit 1이었지만 외부 대상 mode가 `0755`에서 `0700`으로 바뀌었습니다. fixture는 임시 경로에서 정리했습니다.
- 영향: 같은 UID 또는 checkout 디렉터리 쓰기 권한을 가진 동시 주체가 있어야 하며, 이 저장소의 일반적인 신뢰된 로컬 운영자 모델에서는 추가 권한 획득보다 외부 파일 mode 변경·가용성 훼손이 주된 영향입니다. 그래서 LOW로 평가합니다. 다만 계획의 foreign-file preservation 보장은 현재 성립하지 않습니다.
- 수정: `.next`를 `O_DIRECTORY | O_NOFOLLOW`로 열고 같은 descriptor에 `fstat`·`fchmod`를 적용한 뒤 `finally`에서 닫으십시오. spawn 전 경로도 다시 확인하고, lstat 뒤 교체 fixture가 외부 대상 mode를 보존하는 회귀를 두십시오.

## 명세·경계 확인

- 승인된 공통 npm 경계와 backend-only 키 제외 방향은 맞습니다. `package.json`의 dependency 버전은 바뀌지 않았습니다.
- `ADMIN_API_TOKEN`과 `INTERNAL_IDENTITY_SECRET`은 기존 Next 서버 기능에 필요하고 공개 키가 아니므로 자식 전달 자체는 승인 범위입니다. private cache의 `0700` 보호와 잔존 가능성도 문서에 명시되어 있습니다.
- 기존 cache 삭제, 배포, 원본 실행 프로세스 갱신, launcher 시작 전 부모 Node 초기화 옵션 차단, 실행 중 frontend 파일 감시는 승인 범위 밖으로 올바르게 남았습니다.
- 현재 실행기는 추가 positional을 spawn 전에 거부하지 않습니다(`frontend/scripts/run-next.js:131`, `frontend/scripts/run-next.js:147`). 실제 Next 16.3이 이를 exit 0으로 무시한다는 별도 증거가 있어 승인 계획과 불일치합니다. 고정 `FRONTEND_DIRECTORY` 때문에 이번 보안 검토에서는 경로 전환 exploit을 확인하지 못했으며, 이 항목은 일반 코드/명세 리뷰에서 수정해야 할 비보안 Stage 1 결함으로 기록합니다.

## 실제 실행한 검사

- `venv/bin/python -m pytest -q tests/scripts/test_next_environment.py`: 21 passed
- `node --check frontend/scripts/run-next.js`: exit 0
- `bash -n restart_all.sh`: exit 0
- 변경 파일 whitespace 검사: 출력 없음
- LSP: `frontend/scripts/run-next.js`와 `frontend/package.json`은 TypeScript project 진단 0건. Python, shell, env, Markdown은 제공 LSP가 `tsc skipped: no tsconfig found`로 미지원이므로 PASS로 계산하지 않음
- AST 패턴: launcher의 `console.log`, 빈 catch, 문자열 대입형 hardcoded secret 패턴 없음. 테스트의 빈 Python except 패턴 없음
- 지정 파일 시크릿 패턴 정적 검색: 실제 키·private key 패턴 없음. `.env.example`의 예시 placeholder만 확인
- `git ls-files`의 `.env*`: `.env.example`만 추적
- 합성 fixture: backend/private 값 확장 누출 재현, `.next` symlink 교체 후 외부 chmod 재현. 원본 환경·서버·데이터 미접촉

## 실행하지 않은 검사

- `npm audit` 및 외부 CVE 조회: dependency/version 변경이 없고 요청 범위에서 제외되어 실행하지 않음. 의존성 취약점 PASS를 주장하지 않음
- 전체 pytest/Vitest/build/typecheck/lint: 상위 사이클의 기존 증거를 중복 실행하지 않음. 이번 독립 판정은 targeted 검사만 근거로 함
- 실제 `.env`, `.env.production`, `.env.vertex`, `data/` 읽기·변경: 금지 범위라 미실행
- 원본 Next 3500, Flask 5501, live URL 및 market-gate 요청: 금지 범위라 미실행
- 실제 LLM, 발송, 매매, 설정 저장, refresh/delete/reset, 배포·재시작: 미실행
- 실제 browser/cache QA: 후속 UltraQA 범위라 미실행

## 권고

**REQUEST CHANGES.** MEDIUM 비밀값 운반 경로와 LOW `.next` 외부 chmod 경로를 닫고, 추가 positional 명세 결함도 수정한 뒤 동일 합성 회귀와 정적 검사를 재실행해야 합니다.
