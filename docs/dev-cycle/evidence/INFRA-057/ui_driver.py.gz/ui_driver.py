"""agent-browser의 최신 snapshot ref만 쓰는 소유 QA 편의 도구."""
import re
import subprocess
import sys
from pathlib import Path

p = Path(__file__).resolve().parent
session, action, *args = sys.argv[1:]
assert session in {'admin', 'viewer'}

def ab(*arguments):
    result = subprocess.run([sys.executable, str(p/'browser_cli.py'), session, *arguments], capture_output=True, text=True, timeout=75)
    if result.returncode:
        print(result.stdout + result.stderr)
        raise SystemExit(result.returncode)
    return result.stdout

def ref(kind, label, index=None):
    snapshot = ab('snapshot', '-i')
    matches = re.findall(r'^- ' + re.escape(kind) + r' "' + re.escape(label) + r'" \[ref=(e\d+)\]', snapshot, re.M)
    if index is None:
        assert len(matches) == 1, (kind, label, len(matches))
        return '@' + matches[0]
    assert len(matches) > index
    return '@' + matches[index]

if action == 'settings':
    ab('launch')
    ab('cookies', 'set', '--curl', str(p/(session+'-nextauth-cookie.json')))
    ab('launch')
    ab('click', ref('button', '설정 열기'))
    if session == 'admin':
        ab('click', ref('button', '알림 센터'))
elif action == 'click':
    ab('click', ref('button', args[0], int(args[1]) if len(args) > 1 else None))
elif action == 'fill':
    ab('fill', ref('textbox', args[0]), args[1])
else:
    raise SystemExit('unknown action')
print(ab('snapshot', '-i'))
