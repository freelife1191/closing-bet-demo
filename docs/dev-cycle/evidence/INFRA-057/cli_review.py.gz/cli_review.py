import json
import os
import subprocess
import sys
import time
from pathlib import Path

p = Path(__file__).resolve().parent
label = sys.argv[1]
assert label in {'057-arch', '058-arch', '051-arch', '041-arch'}
env = {key: os.environ[key] for key in ('PATH', 'HOME', 'USER', 'LOGNAME', 'SHELL', 'LANG', 'LC_ALL', 'TMPDIR') if key in os.environ}
command = ['codex', 'exec', '--ephemeral', '--ignore-user-config', '--sandbox', 'read-only', '-c', 'approval_policy="never"', '--cd', str(p/'checkout'), '--color', 'never', '--json', '--output-last-message', str(p/(label+'.md')), '-']
start = time.monotonic()
with (p/(label+'-cli.jsonl')).open('w') as output:
    result = subprocess.run(command, input=(p/(label+'-prompt.txt')).read_text(), text=True, stdout=output, stderr=subprocess.STDOUT, env=env, timeout=900)
meta = {'command': command, 'exit': result.returncode, 'seconds': round(time.monotonic()-start, 2), 'surface': 'independent ephemeral read-only Codex CLI; native architect thread limit fallback'}
(p/(label+'-meta.json')).write_text(json.dumps(meta, indent=2))
print(json.dumps(meta))
raise SystemExit(result.returncode)
