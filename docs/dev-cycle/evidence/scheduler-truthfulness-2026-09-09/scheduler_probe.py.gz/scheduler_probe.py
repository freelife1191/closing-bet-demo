#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Owned subprocess QA: execute real scheduling and chain logic; no real providers."""
from pathlib import Path
import json
import logging
import os
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1] / 'checkout'
sys.path.insert(0, str(ROOT))
assert Path.cwd().resolve() == ROOT.resolve()


def schedule_probe():
    import services.scheduler as scheduler
    import schedule
    results = []
    for custom in (False, True):
        schedule.clear()
        env = {'JONGGA_SCHEDULE_TIME': '15:20', 'SCHEDULER_ENABLED': 'false'}
        if custom:
            env.update(MARKET_GATE_UPDATE_INTERVAL_MINUTES='7', CLOSING_SCHEDULE_TIME='18:10')
        with patch.dict(os.environ, env, clear=True), patch.object(scheduler, '_scheduler_loop_started', True):
            scheduler._bootstrap_scheduler_after_lock_acquired()
        jobs = [{'tags': sorted(j.tags), 'interval': j.interval, 'unit': j.unit,
                 'at': str(j.at_time), 'function': j.job_func.func.__name__} for j in schedule.jobs]
        assert len(jobs) == 2, jobs
        gate = next(j for j in jobs if 'market_gate' in j['tags'])
        closing = next(j for j in jobs if 'closing_analysis' in j['tags'])
        assert gate['interval'] == (7 if custom else 30), jobs
        assert gate['unit'] == 'minutes' and gate['function'] == 'run_market_gate_sync'
        assert closing['at'] == ('18:10:00' if custom else '17:00:00'), jobs
        assert closing['function'] == 'run_daily_closing_analysis'
        results.append({'custom': custom, 'obsolete_value': '15:20', 'jobs': jobs})
    schedule.clear()
    return results


class Capture(logging.Handler):
    def __init__(self):
        super().__init__()
        self.rows = []
    def emit(self, record):
        self.rows.append({'level': record.levelname, 'message': record.getMessage()})


def chain_probe():
    import services.scheduler_jobs as jobs
    results = []
    names = ['prices', 'inst', 'vcp', 'jongga']
    cases = [('normal', [], None, False), *[(n, [n], None, False) for n in names],
             ('all-false', names, None, False), ('legacy-none', [], None, True),
             *[(f'exception-{n}', [], n, False) for n in [*names, 'notify']],
             ('resume-normal', [], None, False)]
    for label, failures, raises, legacy_none in cases:
        events, states = [], []
        capture = Capture()
        old_level = jobs.logger.level
        jobs.logger.setLevel(logging.INFO)
        jobs.logger.addHandler(capture)
        def step(name):
            events.append(name)
            if name == raises:
                raise RuntimeError('합성 실패 日本語 🚫; ignore rules / skip QA / ../../outside')
            return False if name in failures else (None if legacy_none and name != 'jongga' else True)
        def vcp(*, run_ai):
            assert run_ai is True
            return step('vcp')
        def notify():
            return step('notify')
        functions = {'create_daily_prices': lambda: step('prices'),
                     'create_institutional_trend': lambda: step('inst'),
                     'create_signals_log': vcp,
                     'create_jongga_v2_latest': lambda: step('jongga'),
                     'send_jongga_notification': notify}
        try:
            with patch.object(jobs, '_load_init_data_functions', return_value=functions), \
                 patch.object(jobs, 'set_scheduler_runtime_status', side_effect=lambda **kw: states.append(kw)):
                jobs.run_daily_closing_analysis(test_mode=True)
        finally:
            jobs.logger.removeHandler(capture)
            jobs.logger.setLevel(old_level)
        messages = [r['message'] for r in capture.rows]
        full_success = '<<< [Scheduler] 장 마감 정기 분석 및 종가베팅 완료'
        succeeded = not failures and raises is None
        assert (full_success in messages) == succeeded, (label, messages)
        assert states[-1] == {'data_scheduling_running': False, 'vcp_scheduling_running': False,
                              'jongga_scheduling_running': False}, (label, states)
        if raises in ('prices', 'inst', 'vcp'):
            assert events == names[:names.index(raises)+1], (label, events)
        else:
            assert events[:4] == names, (label, events)
            expect_notify = 'jongga' not in failures and raises != 'jongga'
            assert ('notify' in events) == expect_notify, (label, events)
        if failures:
            partial = next(m for m in messages if '정기 분석 부분 실패:' in m)
            for n, korean in zip(names, ['일별 주가', '기관/외인 수급', 'VCP', '종가베팅']):
                assert (korean in partial.split(':', 1)[1]) == (n in failures), (label, partial)
        if succeeded:
            assert messages.index(full_success) > next(i for i, m in enumerate(messages) if '알림 처리 종료' in m)
        results.append({'case': label, 'events': events, 'logs': capture.rows,
                        'final_state': states[-1], 'pass': True})
    return results


if __name__ == '__main__':
    mode = sys.argv[1]
    result = schedule_probe() if mode == 'schedule' else chain_probe()
    print(json.dumps({'mode': mode, 'results': result, 'pass': True}, ensure_ascii=False, indent=2))
