#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Own Next, API sink and deny proxy. Finalizer only terminates own live child."""
import http.server
import json
import os
import signal
import socket
import subprocess
import threading
import time
from pathlib import Path
P = Path(__file__).resolve().parents[1]
C = P/'checkout'
Q = P/'qa'
E = P/'evidence'
NEXT_PORT = 57272
class Sink(http.server.BaseHTTPRequestHandler):
    def reject(self):
        with (E/'api-requests.jsonl').open('a') as f:
            f.write(json.dumps({'method':self.command,'path':self.path,'status':403})+'\n')
        self.send_response(403); self.end_headers()
    do_GET = reject
    do_POST = reject
    do_DELETE = reject
    do_PUT = reject
    def log_message(self,*args): pass
class Deny(Sink):
    def reject(self):
        self.send_response(403);self.end_headers()
    do_GET = reject
    do_POST = reject
    do_CONNECT = reject
sink=http.server.ThreadingHTTPServer(('127.0.0.1',0),Sink)
proxy=http.server.ThreadingHTTPServer(('127.0.0.1',0),Deny)
for server in (sink,proxy):
    threading.Thread(target=server.serve_forever,daemon=True).start()
allowed=('PATH','HOME','USER','LOGNAME','SHELL','TMPDIR','TMP','TEMP','LANG','LC_ALL','TZ')
env={k:os.environ[k] for k in allowed if k in os.environ}
env.update({'NEXT_TELEMETRY_DISABLED':'1','SCHEDULER_ENABLED':'false','NEXTAUTH_SECRET':'fixture-only-no-real-credentials','INTERNAL_IDENTITY_SECRET':'fixture-only-no-real-identity','NEXTAUTH_URL':f'http://127.0.0.1:{NEXT_PORT}', 'API_URL':f'http://127.0.0.1:{sink.server_port}'})
with socket.socket() as check:
    assert check.connect_ex(('127.0.0.1',NEXT_PORT))!=0,'port already owned'
log=(E/'next-runtime.log').open('wb')
proc=subprocess.Popen(['/usr/bin/sandbox-exec','-f',str(P/'check-local.sb'),'npm','run','dev','--','--port',str(NEXT_PORT),'--hostname','127.0.0.1'],cwd=C/'frontend',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
stop=threading.Event()
def finish(*_): stop.set()
signal.signal(signal.SIGTERM,finish);signal.signal(signal.SIGINT,finish)
record={'supervisor_pid':os.getpid(),'pid':proc.pid,'pgid':os.getpgid(proc.pid),'cwd':str(C/'frontend'),'url':f'http://127.0.0.1:{NEXT_PORT}','port':NEXT_PORT,'api_port':sink.server_port,'proxy_port':proxy.server_port,'namespace':'devcycle-scheduler-ta7kuvwh','profile':str(Q/'browser-profile')}
try:
    deadline=time.monotonic()+60
    while time.monotonic()<deadline:
        assert proc.poll() is None, 'Next exited early'
        with socket.socket() as check:
            if check.connect_ex(('127.0.0.1',NEXT_PORT))==0: break
        time.sleep(.2)
    else: raise TimeoutError('Next not ready')
    (Q/'runtime.json').write_text(json.dumps(record,indent=2))
    print(json.dumps(record),flush=True)
    while not stop.wait(.2):
        if proc.poll() is not None: raise RuntimeError('Next unexpectedly exited')
finally:
    if proc.poll() is None:
        assert os.getpgid(proc.pid)==record['pgid']
        os.killpg(proc.pid,signal.SIGTERM)
        try: proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=5)
    sink.shutdown();proxy.shutdown();sink.server_close();proxy.server_close();log.close()
    (E/'runtime-cleanup.json').write_text(json.dumps({'supervisor_finalized':True,'child_exit':proc.returncode,'record':record},indent=2))
