import os,sys,subprocess,time,json,signal
from pathlib import Path
p=Path(__file__).resolve().parent;c=p/'checkout'
name=sys.argv[1]; folder=sys.argv[2]; command=sys.argv[3:]
allowed=('PATH','HOME','USER','LOGNAME','SHELL','TMPDIR','TMP','TEMP','LANG','LC_ALL','TZ')
env={k:os.environ[k] for k in allowed if k in os.environ};env.update({'SCHEDULER_ENABLED':'false','PYTHONDONTWRITEBYTECODE':'1','NEXT_TELEMETRY_DISABLED':'1','DATA_DIR':str(c/'data')})
limit=60 if name.startswith("qa-") else 900
start=time.time();out=p/'evidence'/f'{name}.log'
with out.open('wb') as f:
 proc=subprocess.Popen(['/usr/bin/sandbox-exec','-f',str(p/('check-local.sb' if folder == 'frontend' else 'qa/no-network.sb')),*command],cwd=c/folder,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try: code=proc.wait(timeout=limit)
 except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=15);code=124
meta={'command':command,'cwd':str(c/folder),'exit_code':code,'seconds':round(time.time()-start,3),'timeout_seconds':limit,'log':str(out)}
(p/'evidence'/f'{name}.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta));print(''.join(out.read_text(errors='replace').splitlines(True)[-15:]));sys.exit(code)
