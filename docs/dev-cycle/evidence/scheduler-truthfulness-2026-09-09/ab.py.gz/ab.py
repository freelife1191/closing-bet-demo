#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json,subprocess,sys,os,time
from pathlib import Path
P=Path(__file__).resolve().parents[1];Q=P/'qa';E=P/'evidence';r=json.loads((Q/'runtime.json').read_text())
label=sys.argv[1];args=sys.argv[2:]
assert label.replace('-','').replace('_','').isalnum()
command=['agent-browser','--namespace',r['namespace'],'--session','landing','--profile',r['profile'],'--proxy',f'http://127.0.0.1:{r["proxy_port"]}','--allowed-domains','127.0.0.1,localhost','--args','--disable-background-networking,--disable-component-update,--no-first-run',*args]
start=time.time()
env={k:os.environ[k] for k in ('PATH','HOME','USER','LOGNAME','SHELL','TMPDIR','LANG') if k in os.environ}
try:
 result=subprocess.run(command,input=sys.stdin.read() if '--stdin' in args else None,env=env,text=True,capture_output=True,timeout=60)
 code=result.returncode;out=result.stdout;err=result.stderr
except subprocess.TimeoutExpired as error:
 code=124;out=str(error.stdout or '');err='command timeout 60s'
(E/f'{label}.txt').write_text(out+err)
with (E/'browser-commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'args':args,'exit_code':code,'seconds':round(time.time()-start,3)})+'\n')
print(out[:14000]);print(err[:2000]);sys.exit(code)
