# FE-034 + FE-040 empty-state UI fixture

Prepared only; nothing has started. After the parent commits, `zsh setup.sh` then `zsh start.sh` uses real Next UI at 127.0.0.1:57381 and a fake allowlist API at 57382. `zsh cleanup.sh` verifies exact process-group members by PPID/CWD, sends SIGTERM, waits, and confirms both ports are free without calling killpg(0).

The fixture supplies empty cumulative data, empty paper portfolio/holdings/history/asset history, empty closing-bet data/dates/status, and ordinary-user auth/quota/header data. Every write/LLM/trade/send/delete endpoint returns 405.

Browser paths at 375x812: `/dashboard/kr/closing-bet` for FE-034 title/breadcrumb and the PaperTrading modal trigger; `/dashboard/kr/cumulative` for the empty trade table; PaperTrading `보유 종목` and `거래 내역` tabs for both modal empty tables. For StockTradeHistoryModal, keep API history empty but run `checkout/venv/bin/python empty_fixture.py set-mode history-row`, reopen the PaperTrading modal, and click the one synthetic holding's history button. This switches only scratch fixture state; it does not enable trade writes.

For FE-040 S7, run `checkout/venv/bin/python empty_fixture.py set-mode populated`, reload cumulative, verify the long Unicode row, choose a filter with no matching outcome, then restore `전체`. This changes only the fake response and permits no write endpoint.
