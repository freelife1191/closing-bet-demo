#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""FE-034/040 local-only empty-state API fixture. No source data or writes."""

from __future__ import annotations
import argparse, json, os, secrets, subprocess, sys, tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

ROOT=Path(__file__).resolve().parent
CHECKOUT=ROOT/"checkout"; FRONTEND=CHECKOUT/"frontend"
ENV=ROOT/"fake.env"; COOKIE=ROOT/"ordinary-cookie.json"; REQUESTS=ROOT/"requests.jsonl"
CONTROL=ROOT/"control.json"
PORT=57382; NEXT=57381
ORIGINAL=Path("/Users/freelife/vibe/lecture/hodu/closing-bet-demo").resolve()

def check(ok: bool, msg: str):
    if not ok: raise RuntimeError(msg)

def write(path: Path, value: Any):
    text=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)+"\n"
    with tempfile.NamedTemporaryFile(mode="w",encoding="utf-8",dir=path.parent,prefix=path.name+".",delete=False) as f:
        f.write(text); temp=Path(f.name)
    os.chmod(temp,0o600); os.replace(temp,path); os.chmod(path,0o600)

def cookie(secret: str):
    source="const {encode}=require('next-auth/jwt');let x='';process.stdin.on('data',c=>x+=c);process.stdin.on('end',async()=>process.stdout.write(JSON.stringify({value:await encode({token:JSON.parse(x),secret:process.env.NEXTAUTH_SECRET,maxAge:3600})})));"
    out=subprocess.run(["node","-e",source],cwd=FRONTEND,env={"PATH":os.environ.get("PATH",""),"HOME":os.environ.get("HOME",""),"NEXTAUTH_SECRET":secret},input=json.dumps({"name":"빈표 검수자","email":"empty@example.test","sub":"empty@example.test"}),text=True,capture_output=True,timeout=20)
    check(out.returncode==0,"cookie failed"); token=json.loads(out.stdout)["value"]
    return [{"name":"next-auth.session-token","value":token,"domain":"127.0.0.1","path":"/","httpOnly":True,"secure":False,"sameSite":"Lax"}]

def prepare():
    check(CHECKOUT.is_dir() and CHECKOUT.resolve()!=ORIGINAL,"run setup first")
    check(not (CHECKOUT/"data").exists() and not (CHECKOUT/"data").is_symlink(),"source data forbidden")
    secret=secrets.token_urlsafe(32)
    values={"GOOGLE_CLIENT_ID":"empty-qa","GOOGLE_CLIENT_SECRET":"empty-secret","NEXTAUTH_SECRET":secret,"NEXTAUTH_URL":"http://127.0.0.1:57381","NEXTAUTH_URL_INTERNAL":"http://127.0.0.1:57381","API_URL":"http://127.0.0.1:57382","INTERNAL_IDENTITY_SECRET":secrets.token_urlsafe(32),"ADMIN_EMAILS":"admin@example.test","SCHEDULER_ENABLED":"false","NEXT_TELEMETRY_DISABLED":"1","CI":"1"}
    write(ENV,"".join(f"{k}={v}\n" for k,v in values.items())); write(COOKIE,cookie(secret)); write(CONTROL,{"mode":"empty"}); REQUESTS.unlink(missing_ok=True)
    print(json.dumps({"prepared":True,"ports":[57381,57382],"synthetic_cookie":True}))

def log(method,path,status):
    with REQUESTS.open("a",encoding="utf-8") as f:f.write(json.dumps({"method":method,"path":path,"status":status,"synthetic":True})+"\n")

def empty_kpi():
    grade={"count":0,"avgRoi":0,"totalRoi":0,"wins":0,"losses":0,"winRate":0}
    return {"totalSignals":0,"winRate":0,"wins":0,"losses":0,"open":0,"avgRoi":0,"totalRoi":0,"roiByGrade":{"S":grade,"A":grade,"B":grade},"avgDays":0,"priceDate":"-","profitFactor":None}
def mode(): return json.loads(CONTROL.read_text())["mode"]
def populated_trade():
    return {"id":"synthetic-unicode-1","date":"2026-09-09","grade":"S","name":"긴 Unicode 종목명 🧪 漢字 검증용","code":"005930","market":"KOSPI","entry":100000,"outcome":"WIN","roi":1.5,"maxHigh":102000,"priceTrail":[100000,101500],"days":1,"score":88,"themes":["합성"]}
def populated_kpi():
    grade={"count":1,"avgRoi":1.5,"totalRoi":1.5,"wins":1,"losses":0,"winRate":100}
    return {"totalSignals":1,"winRate":100,"wins":1,"losses":0,"open":0,"avgRoi":1.5,"totalRoi":1.5,"roiByGrade":{"S":grade,"A":{**grade,"count":0,"avgRoi":0,"totalRoi":0,"wins":0,"winRate":0},"B":{**grade,"count":0,"avgRoi":0,"totalRoi":0,"wins":0,"winRate":0}},"avgDays":1,"priceDate":"2026-09-09","profitFactor":None}

class H(BaseHTTPRequestHandler):
    def log_message(self,*x):pass
    def reply(self,status,payload):
        body=json.dumps(payload,ensure_ascii=False).encode(); log(self.command,urlparse(self.path).path,status)
        self.send_response(status); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers();self.wfile.write(body)
    def do_GET(self):
        p=urlparse(self.path).path
        if p=="/api/kr/closing-bet/cumulative":
            populated=mode()=="populated"; self.reply(200,{"kpi":populated_kpi() if populated else empty_kpi(),"trades":[populated_trade()] if populated else [],"pagination":{"page":1,"limit":50,"total":1 if populated else 0,"totalPages":1}})
        elif p=="/api/portfolio":
            holdings=[] if mode()=="empty" else [{"ticker":"005930","name":"합성 보유종목","quantity":1,"avg_price":100000,"current_price":100000,"profit_rate":0,"profit":0}]
            self.reply(200,{"holdings":holdings,"cash":1000000,"total_asset_value":1000000,"total_stock_value":len(holdings)*100000,"total_profit":0,"total_profit_rate":0,"total_principal":1000000})
        elif p=="/api/portfolio/history": self.reply(200,{"trades":[]})
        elif p=="/api/portfolio/history/asset": self.reply(200,{"history":[]})
        elif p.startswith("/api/kr/stock-chart/"): self.reply(200,{"ticker":p.rsplit("/",1)[-1],"data":[]})
        elif p=="/api/kr/market-gate": self.reply(200,{"score":70,"status":"GREEN","label":"합성 시장","sectors":[]})
        elif p=="/api/kr/jongga-v2/latest":
            signal=[] if mode()!="populated" else [{"stock_code":"005930","stock_name":"긴 Unicode 종목명 🧪 漢字 검증용","market":"KOSPI","grade":"S","entry_price":100000,"buy_price":100000,"current_price":101000,"signal_date":"2026-09-09","score":{"total":88,"news":3,"volume":4,"chart":4,"candle":3,"consolidation":3,"timing":4,"supply":4,"llm_reason":"합성 점수"},"checklist":{},"themes":["합성"],"ai_evaluation":{"action":"BUY","confidence":80,"reason":"합성"}}]
            self.reply(200,{"date":"2026-09-09","signals":signal,"total_candidates":len(signal),"filtered_count":len(signal),"updated_at":"2026-09-09T17:00:00+09:00","status":"success"})
        elif p=="/api/kr/jongga-v2/dates": self.reply(200,["2026-09-09"])
        elif p=="/api/kr/jongga-v2/status": self.reply(200,{"isRunning":False,"status":"IDLE","message":"합성 유휴"})
        elif p=="/api/admin/check": self.reply(200,{"isAdmin":False})
        elif p=="/api/kr/user/quota": self.reply(200,{"usage":0,"limit":10,"remaining":10,"is_admin":False})
        else:self.reply(404,{"error":"synthetic empty-state allowlist only"})
    def do_POST(self):self.reply(405,{"error":"all writes, LLM, trade, send, deletion blocked"})
    do_DELETE=do_POST;do_PUT=do_POST;do_PATCH=do_POST

def set_mode(value):
    check(value in {"empty","history-row","populated"},"mode must be empty, history-row, or populated");write(CONTROL,{"mode":value})
def serve():
    check(ENV.exists() and CHECKOUT.is_dir(),"prepare first"); ThreadingHTTPServer(("127.0.0.1",PORT),H).serve_forever()

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("cmd",choices=("prepare","serve","set-mode"));p.add_argument("mode",nargs="?");a=p.parse_args();prepare() if a.cmd=="prepare" else set_mode(a.mode) if a.cmd=="set-mode" else serve()
