#!/bin/zsh
set -euo pipefail
readonly SRC="/Users/freelife/vibe/lecture/hodu/closing-bet-demo"
readonly ROOT="${0:A:h}"
readonly CHECKOUT="$ROOT/checkout"
[[ ! -e "$CHECKOUT" ]] || { print -u2 "scratch checkout exists"; exit 1; }
envs=$(git -C "$SRC" ls-tree -r --name-only HEAD | awk -F/ '$NF ~ /^[.]env/ && $NF != ".env.example"')
[[ -z "$envs" ]] || { print -u2 "tracked env forbidden: $envs"; exit 1; }
umask 077
mkdir -p "$CHECKOUT"
git -C "$SRC" archive --format=tar HEAD -- . ':(exclude)data' | tar -xf - -C "$CHECKOUT"
for check_path in "$CHECKOUT/.env" "$CHECKOUT/frontend/.env" "$CHECKOUT/data"; do [[ ! -e "$check_path" && ! -L "$check_path" ]] || { print -u2 "runtime copy: $check_path"; exit 1; }; done
ln -s "$SRC/venv" "$CHECKOUT/venv"
ln -s "$SRC/frontend/node_modules" "$CHECKOUT/frontend/node_modules"
print -r -- "empty-state checkout ready: $CHECKOUT"
