#!/bin/zsh
set -euo pipefail
readonly R="${0:A:h}"
[[ -d "$R/checkout" ]] || zsh "$R/setup.sh"
env -u OMX_ROOT -u OMX_STATE_ROOT "$R/checkout/venv/bin/python" "$R/launcher.py" start
