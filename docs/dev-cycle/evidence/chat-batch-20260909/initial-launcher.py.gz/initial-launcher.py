import json, os, signal, socket, subprocess, sys, tempfile, time
from pathlib import Path
R=Path(__file__).resolve().parent;C=R/'checkout';F=R/'chat_batch_fixture.py';P=R/'local-only.sb';E=R/'fake.env';I=R/'pids.json';PORTS=(57401,57402)
def fail(v,m):
 if not v: raise RuntimeError(m)
def environment():
 d={k:os.environ[k] for k in ('PATH','HOME','USER','TMPDIR','LANG') if k in os.environ}
 for l in E.read_text().splitlines():
  k,_,v=l.partition('=');fail(k.isupper() and v,'fake env');d[k]=v
 return d
def members(g):
 o=subprocess.run(['ps','-axo','pid=,ppid=,pgid=,command='],capture_output=True,text=True).stdout.splitlines();return [x.split(None,3) for x in o if len(x.split(None,3))==4 and int(x.split(None,3)[2])==g]
def start():
 fail(C.is_dir() and not I.exists(),'setup/stale');d={k:os.environ[k] for k in ('PATH','HOME','USER','TMPDIR','LANG') if k in os.environ}
 if not E.exists():subprocess.run(['/usr/bin/sandbox-exec','-f',str(P),str(C/'venv/bin/python'),str(F),'prepare'],cwd=R,env=d,check=True)
 d=environment();node=Path('/opt/homebrew/bin/node');node=node if node.exists() else Path('/usr/local/bin/node');n=C/'frontend/node_modules/next/dist/bin/next'
 b=subprocess.Popen(['/usr/bin/sandbox-exec','-f',str(P),str(C/'venv/bin/python'),str(F),'serve'],cwd=R,env=d,start_new_session=True)
 x=subprocess.Popen(['/usr/bin/sandbox-exec','-f',str(P),str(node),str(n),'dev','--webpack','--hostname','127.0.0.1','--port','57401'],cwd=C/'frontend',env=d,start_new_session=True)
 I.write_text(json.dumps({'root':str(R),'items':[(b.pid,os.getpgid(b.pid)),(x.pid,os.getpgid(x.pid))]}))
def clean():
 v=json.loads(I.read_text());fail(Path(v['root']).resolve()==R,'owner')
 for p,g in v['items']:
  m=members(g);fail(m and any(int(x[0])==p for x in m),'changed group');os.killpg(g,signal.SIGTERM)
 end=time.time()+10
 while time.time()<end and any(members(g) for _,g in v['items']):time.sleep(.1)
 fail(not any(members(g) for _,g in v['items']),'children alive');I.unlink()
if __name__=='__main__': start() if sys.argv[1]=='start' else clean()
