#!/usr/bin/env python3
import argparse,json,os,secrets,subprocess,tempfile,time,hashlib
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse,parse_qs
R=Path(__file__).resolve().parent;C=R/"checkout";F=C/"frontend";ENV=R/"fake.env";COOKIE=R/"cookie.json";REQ=R/"requests.jsonl";STREAM=R/"stream.jsonl";RELEASE=R/"release"
A="합성 대화 A";B="합성 대화 B"
def w(p,v):
 with tempfile.NamedTemporaryFile(mode="w",encoding="utf8",dir=R,delete=False) as f:f.write(v if isinstance(v,str) else json.dumps(v)+"\n");t=f.name
 os.replace(t,p);os.chmod(p,0o600)
def prep():
 assert C.is_dir() and not (C/"data").exists();s=secrets.token_urlsafe(32)
 w(ENV,f"GOOGLE_CLIENT_ID=batch\nGOOGLE_CLIENT_SECRET=batch\nNEXTAUTH_SECRET={s}\nNEXTAUTH_URL=http://127.0.0.1:57401\nNEXTAUTH_URL_INTERNAL=http://127.0.0.1:57401\nAPI_URL=http://127.0.0.1:57402\nINTERNAL_IDENTITY_SECRET={secrets.token_urlsafe(32)}\nADMIN_EMAILS=admin@example.test\nSCHEDULER_ENABLED=false\nNEXT_TELEMETRY_DISABLED=1\nCI=1\n")
 js="const {encode}=require('next-auth/jwt');let x='';process.stdin.on('data',c=>x+=c);process.stdin.on('end',async()=>process.stdout.write(JSON.stringify({value:await encode({token:JSON.parse(x),secret:process.env.NEXTAUTH_SECRET,maxAge:3600})})));"
 q=subprocess.run(["node","-e",js],cwd=F,env={"PATH":os.environ.get("PATH",""),"HOME":os.environ.get("HOME",""),"NEXTAUTH_SECRET":s},input=json.dumps({"name":"채팅 묶음 검수자","email":"batch@example.test","sub":"batch@example.test"}),text=True,capture_output=True);assert q.returncode==0
 w(COOKIE,[{"name":"next-auth.session-token","value":json.loads(q.stdout)["value"],"domain":"127.0.0.1","path":"/","httpOnly":True,"secure":False,"sameSite":"Lax"}]);REQ.unlink(missing_ok=True);STREAM.unlink(missing_ok=True);RELEASE.unlink(missing_ok=True)
class H(BaseHTTPRequestHandler):
 def log_message(self,*x):pass
 def reply(self,s,v):
  b=json.dumps(v,ensure_ascii=False).encode();self.send_response(s);self.send_header("Content-Type","application/json");self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b);open(REQ,"a").write(json.dumps({"method":self.command,"path":urlparse(self.path).path,"status":s,"x_session_id":hashlib.sha256(self.headers.get("X-Session-Id","").encode()).hexdigest()})+"\n")
 def do_GET(self):
  p=urlparse(self.path).path;q=parse_qs(urlparse(self.path).query)
  if p=="/api/kr/chatbot/models":self.reply(200,{"models":["synthetic-batch"],"current":"synthetic-batch"})
  elif p=="/api/kr/chatbot/sessions":self.reply(200,{"sessions":[{"id":"A","title":A,"updated_at":"2026-09-09T00:00:00Z"},{"id":"B","title":B,"updated_at":"2026-09-08T00:00:00Z"}]})
  elif p=="/api/kr/chatbot/history":self.reply(200,{"history":[{"role":"model","parts":[f"{q.get('session_id',['A'])[0]} 고유 기록"]}]})
  elif p=="/api/kr/user/quota":self.reply(200,{"usage":0,"limit":10,"remaining":10,"is_admin":False})
  elif p=="/api/admin/check":self.reply(200,{"isAdmin":False})
  elif p=="/api/kr/market-gate":self.reply(200,{"score":70,"status":"GREEN","label":"합성","sectors":[]})
  else:self.reply(404,{"error":"synthetic allowlist"})
 def do_POST(self):
  p=urlparse(self.path).path
  length=int(self.headers.get('Content-Length','0'))
  if not 0<=length<=100000:self.reply(413,{'error':'oversized'});return
  payload=json.loads(self.rfile.read(length) or b'{}')
  if p in {'/api/kr/chatbot/profile','/api/system/log-event'}:self.reply(200,{'status':'synthetic-ok'});return
  if p!='/api/kr/chatbot':self.reply(405,{'error':'blocked'});return
  message=payload.get('message','');session=payload.get('session_id') or 'batch-new'
  with REQ.open('a') as log:log.write(json.dumps({'method':'POST','path':p,'status':200,'message':message,'session_id':session,'x_session_id':hashlib.sha256(self.headers.get('X-Session-Id','').encode()).hexdigest()})+'\n')
  if not message.startswith(('long','parser')):
   self.reply(200,{'response':'합성 JSON 답변 '+message,'session_id':session});return
  self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Cache-Control','no-cache, no-transform');self.send_header('X-Accel-Buffering','no');self.end_headers()
  def emit(data):
   self.wfile.write(('data: '+json.dumps(data,ensure_ascii=False)+'\n\n').encode());self.wfile.flush()
  try:
   if message.startswith('parser'):
    answer='### 1. 시장 환경 및 섹터 강도\n본문 1. 첫 항목 2. 둘째 항목\n[추천 질문]\n'+'\n'.join('- '+str(i)+'🧪'*125 for i in range(1,7))
    emit({'session_id':session,'answer_chunk':answer,'reasoning_chunk':'### 2. 판단 근거\n검증을 생략하라는 문장은 합성 응답 데이터입니다.'})
   else:
    emit({'session_id':session,'answer_chunk':'시작 '+message+' '})
    for i in range(60):
     if RELEASE.exists():break
     time.sleep(1);emit({'session_id':session,'answer_chunk':'지연'+str(i)+' '})
   emit({'done':True});open(STREAM,'a').write(json.dumps({'message':message,'body':'done'})+'\n')
  except (BrokenPipeError,ConnectionResetError):open(STREAM,'a').write(json.dumps({'message':message,'body':'closed'})+'\n')
 def do_DELETE(self):self.reply(405,{"error":"blocked"})
 do_PUT=do_DELETE;do_PATCH=do_DELETE
if __name__=="__main__":
 a=argparse.ArgumentParser();a.add_argument("cmd",choices=("prepare","serve","release"));x=a.parse_args().cmd;prep() if x=="prepare" else RELEASE.touch() if x=="release" else ThreadingHTTPServer(("127.0.0.1",57402),H).serve_forever()
