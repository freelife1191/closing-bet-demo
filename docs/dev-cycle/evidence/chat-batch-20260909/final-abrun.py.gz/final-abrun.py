import subprocess,sys,json,time
from pathlib import Path
E=Path('/Users/freelife/vibe/lecture/hodu/closing-bet-demo/docs/dev-cycle/evidence/chat-batch-20260909')
label=sys.argv[1];args=sys.argv[2:];start=time.time()
try:
 r=subprocess.run(['agent-browser','--namespace','chat-batch-20260909','--session','qa',*args],input=sys.stdin.read() if '--stdin' in args else None,capture_output=True,text=True,timeout=35)
 (E/(label+'.txt')).write_text(r.stdout+r.stderr)
 with (E/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'args':args,'exit':r.returncode,'elapsed':time.time()-start},ensure_ascii=False)+'\n')
 print(r.stdout+r.stderr);sys.exit(r.returncode)
except subprocess.TimeoutExpired:
 with (E/'commands.jsonl').open('a') as f:f.write(json.dumps({'label':label,'args':args,'exit':'timeout35'})+'\n')
 raise
