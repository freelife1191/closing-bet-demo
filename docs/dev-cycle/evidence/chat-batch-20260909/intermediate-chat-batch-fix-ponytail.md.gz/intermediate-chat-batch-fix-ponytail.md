## Ponytail Re-review — CHAT-015 reasoning heading fix

**Scope:** `frontend/src/app/components/ThinkingProcess.tsx` and `frontend/src/app/chatbot/ChatMessage.regression-chat-015.test.tsx`, base `212c7194dc2d18cf6f4c315bf629c7ba0fd8a296`.

### Verdict

**APPROVE** — the QA fix is minimal, directly repairs the observed defect, and preserves the previous contract.

`ThinkingProcess.tsx:15-35` moves dense-number normalization inside a line loop and explicitly preserves lines matching Markdown heading syntax before applying the existing `1.`/`1)` dense-list regex. This prevents a heading such as `### 2. 수급 흐름` from being split into an empty heading plus a list item, while retaining support for the prior parenthesis marker form and dense inline numbering on ordinary lines.

`ChatMessage.regression-chat-015.test.tsx` adds the exact failing shape and asserts one populated level-3 heading after the reasoning toggle, preventing the empty-h3 regression. The test does not remove or weaken the prior suggestion interaction assertion.

No new abstraction, dependency, broad parser rewrite, or unrelated behavior was introduced. The reported RED→GREEN evidence and 2/2 targeted rerun support the correction. Confidence: high.

## Exact Scope SHA-256

```text
885c6677b55473d76ef3e67744f75e8bb6b0b6af7ed71a80bf0a7c43f9e0e973  frontend/src/app/components/ThinkingProcess.tsx
1f916e77b4bbbeb49a19b0e8c0afc1c89dac7cacd76e6192e4ce3fed3b352cff  frontend/src/app/chatbot/ChatMessage.regression-chat-015.test.tsx
```
