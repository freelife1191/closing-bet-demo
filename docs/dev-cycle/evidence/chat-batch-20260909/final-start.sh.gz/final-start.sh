#!/bin/zsh
set -euo pipefail
readonly R="${0:A:h}"
readonly C="$R/checkout"
env -u OMX_ROOT -u OMX_STATE_ROOT "$C/venv/bin/python" "$R/launcher.py" start
