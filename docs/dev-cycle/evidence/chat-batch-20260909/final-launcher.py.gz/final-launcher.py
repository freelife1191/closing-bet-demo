#!/usr/bin/env python3
import json, os, signal, socket, subprocess, sys, tempfile, time
from pathlib import Path

R=Path(__file__).resolve().parent; C=R/"checkout"; F=R/"chat_batch_fixture.py"; P=R/"local-only.sb"; E=R/"fake.env"; I=R/"pids.json"; L=R/"logs"; PORTS=(57401,57402)

def fail(ok,msg):
 if not ok: raise RuntimeError(msg)
def env():
 d={k:os.environ[k] for k in ("PATH","HOME","USER","TMPDIR","LANG") if k in os.environ}
 for x in E.read_text().splitlines():
  k,_,v=x.partition("=");fail(k.isupper() and v,"bad fake env");d[k]=v
 return d
def free():
 busy=[]
 for p in PORTS:
  s=socket.socket();s.settimeout(.2)
  if s.connect_ex(("127.0.0.1",p))==0:busy.append(p)
  s.close()
 fail(not busy,f"busy ports {busy}")
def write(v):
 with tempfile.NamedTemporaryFile(mode="w",dir=R,delete=False) as f:json.dump(v,f);t=f.name
 os.replace(t,I)
def start():
 fail(C.is_dir() and not I.exists(),"setup or stale PID problem");free()
 if not E.exists():
  q=subprocess.run(["/usr/bin/sandbox-exec","-f",str(P),str(C/"venv/bin/python"),str(F),"prepare"],cwd=R,env={k:os.environ[k] for k in ("PATH","HOME","USER","TMPDIR","LANG") if k in os.environ});fail(q.returncode==0,"prepare failed")
 d=env();L.mkdir(exist_ok=True);node=Path("/opt/homebrew/bin/node");node=node if node.is_file() else Path("/usr/local/bin/node");n=C/"frontend/node_modules/next/dist/bin/next"
 b=subprocess.Popen(["/usr/bin/sandbox-exec","-f",str(P),str(C/"venv/bin/python"),str(F),"serve"],cwd=R,env=d,stdout=(L/"backend.log").open("w"),stderr=subprocess.STDOUT,start_new_session=True)
 x=subprocess.Popen(["/usr/bin/sandbox-exec","-f",str(P),str(node),str(n),"dev","--webpack","--hostname","127.0.0.1","--port","57401"],cwd=C/"frontend",env=d,stdout=(L/"next.log").open("w"),stderr=subprocess.STDOUT,start_new_session=True)
 write({"root":str(R),"ports":PORTS,"items":[{"pid":b.pid,"pgid":os.getpgid(b.pid),"cwd":str(R)},{"pid":x.pid,"pgid":os.getpgid(x.pid),"cwd":str(C/"frontend")} ]})
def cwd(pid):
 o=subprocess.run(["lsof","-a","-p",str(pid),"-d","cwd","-Fn"],capture_output=True,text=True).stdout
 return next((Path(z[1:]).resolve() for z in o.splitlines() if z.startswith("n")),None)
def members(g):
 o=subprocess.run(["ps","-axo","pid=,ppid=,pgid=,command="],capture_output=True,text=True).stdout.splitlines();return [z.strip().split(None,3) for z in o if len(z.strip().split(None,3))==4 and int(z.strip().split(None,3)[2])==g]
def clean():
 v=json.loads(I.read_text());fail(Path(v["root"]).resolve()==R and tuple(v["ports"])==PORTS,"unowned record")
 for q in v["items"]:
  pid,g,c=int(q["pid"]),int(q["pgid"]),Path(q["cwd"]).resolve();fail(os.getpgid(pid)==g,"changed root");m=members(g);fail(m,"empty group")
  ids={pid};todo=[pid]
  while todo:
   p=todo.pop()
   for z in m:
    if int(z[1])==p and int(z[0]) not in ids:ids.add(int(z[0]));todo.append(int(z[0]))
  fail(all(int(z[0]) in ids and (cwd(int(z[0])) in {R,c} or c in (cwd(int(z[0])) or R).parents) for z in m),"unowned next-server group");os.killpg(g,signal.SIGTERM)
 end=time.time()+10
 while time.time()<end:
  alive=False
  for q in v["items"]:
   if members(int(q["pgid"])):alive=True
  if not alive:break
  time.sleep(.1)
 fail(all(not members(int(q["pgid"])) for q in v["items"]),"owned process group still alive");free();I.unlink()
if __name__=="__main__": (start() if sys.argv[1]=="start" else clean())
