#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Start and clean only profile-ui scratch process groups."""

from __future__ import annotations

import json
import os
import signal
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
CHECKOUT = ROOT / "checkout"
FRONTEND = CHECKOUT / "frontend"
FIXTURE = ROOT / "profile_fixture.py"
POLICY = ROOT / "local-only.sb"
SANDBOX = Path("/usr/bin/sandbox-exec")
FAKE_ENV = ROOT / "fake.env"
PIDS = ROOT / "pids.json"
CLEANUP = ROOT / "cleanup.json"
LOGS = ROOT / "logs"
PORTS = (57371, 57372)


def _assert(value: bool, message: str) -> None:
    if not value:
        raise RuntimeError(message)


def _write_json(path: Path, value: Any) -> None:
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, prefix=path.name + ".", suffix=".tmp", delete=False) as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
        temporary = Path(handle.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)
    os.chmod(path, 0o600)


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    _assert(isinstance(value, dict), "invalid process record")
    return value


def _base_env() -> dict[str, str]:
    return {key: os.environ[key] for key in ("PATH", "HOME", "USER", "TMPDIR", "LANG") if key in os.environ}


def _fake_env() -> dict[str, str]:
    _assert(FAKE_ENV.is_file() and not FAKE_ENV.is_symlink(), "fixture prepare has not created fake.env")
    values: dict[str, str] = {}
    for line in FAKE_ENV.read_text(encoding="utf-8").splitlines():
        key, sep, value = line.partition("=")
        _assert(bool(sep) and key.isupper() and bool(value), "invalid fake env line")
        values[key] = value
    return values


def _sandbox(*command: str) -> list[str]:
    return [str(SANDBOX), "-f", str(POLICY), *command]


def _ports_free() -> None:
    busy = []
    for port in PORTS:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            probe.settimeout(0.2)
            if probe.connect_ex(("127.0.0.1", port)) == 0:
                busy.append(port)
    _assert(not busy, f"profile scratch ports are busy: {busy}")


def _prepare() -> None:
    python = CHECKOUT / "venv" / "bin" / "python"
    result = subprocess.run(_sandbox(str(python), str(FIXTURE), "prepare"), cwd=ROOT, env=_base_env(), text=True, capture_output=True, timeout=30, check=False)
    _assert(result.returncode == 0, f"fixture prepare failed: {result.stderr.strip()}")


def start() -> int:
    _assert(CHECKOUT.is_dir() and FRONTEND.is_dir(), "run setup.sh after the approved commit")
    _assert(not PIDS.exists(), "owned process record exists")
    _assert(SANDBOX.is_file() and POLICY.is_file() and FIXTURE.is_file(), "fixture launcher input missing")
    _ports_free()
    if not FAKE_ENV.exists():
        _prepare()

    environment = _base_env()
    environment.update(_fake_env())
    python = CHECKOUT / "venv" / "bin" / "python"
    node = Path("/opt/homebrew/bin/node")
    if not node.is_file():
        node = Path("/usr/local/bin/node")
    next_bin = FRONTEND / "node_modules" / "next" / "dist" / "bin" / "next"
    _assert(python.is_file() and node.is_file() and next_bin.is_file(), "absolute executable missing")
    LOGS.mkdir(mode=0o700, exist_ok=True)
    backend_log = (LOGS / "backend.log").open("w", encoding="utf-8")
    next_log = (LOGS / "next.log").open("w", encoding="utf-8")

    backend = subprocess.Popen(_sandbox(str(python), str(FIXTURE), "serve"), cwd=ROOT, env=environment, stdout=backend_log, stderr=subprocess.STDOUT, start_new_session=True)
    frontend = subprocess.Popen(_sandbox(str(node), str(next_bin), "dev", "--webpack", "--hostname", "127.0.0.1", "--port", "57371"), cwd=FRONTEND, env=environment, stdout=next_log, stderr=subprocess.STDOUT, start_new_session=True)
    _write_json(PIDS, {
        "scratch_root": str(ROOT),
        "ports": list(PORTS),
        "roots": {
            "backend": {"pid": backend.pid, "pgid": os.getpgid(backend.pid), "cwd": str(ROOT)},
            "frontend": {"pid": frontend.pid, "pgid": os.getpgid(frontend.pid), "cwd": str(FRONTEND)},
        },
    })
    print(json.dumps({"started": True, "ports": list(PORTS), "pids_file": str(PIDS)}))
    return 0


def _group_members(pgid: int) -> list[tuple[int, int, int, str]]:
    output = subprocess.run(["ps", "-axo", "pid=,ppid=,pgid=,command="], capture_output=True, text=True, check=False).stdout.splitlines()
    members = []
    for line in output:
        parts = line.strip().split(None, 3)
        if len(parts) != 4:
            continue
        pid, parent, group = map(int, parts[:3])
        if group == pgid:
            members.append((pid, parent, group, parts[3]))
    return members


def _cwd(pid: int) -> Path | None:
    probe = subprocess.run(["lsof", "-a", "-p", str(pid), "-d", "cwd", "-Fn"], capture_output=True, text=True, check=False)
    for line in probe.stdout.splitlines():
        if line.startswith("n"):
            return Path(line[1:]).resolve()
    return None


def _assert_owned_group(root_pid: int, pgid: int, expected_cwd: Path) -> None:
    _assert(os.getpgid(root_pid) == pgid, "root process group changed")
    members = _group_members(pgid)
    _assert(members, "recorded process group is empty")
    descendants = {root_pid}
    pending = [root_pid]
    while pending:
        parent = pending.pop()
        for pid, ppid, _, _ in members:
            if ppid == parent and pid not in descendants:
                descendants.add(pid)
                pending.append(pid)
    _assert({pid for pid, _, _, _ in members}.issubset(descendants), "group has a non-descendant process")
    for pid, _, _, command in members:
        cwd = _cwd(pid)
        _assert(cwd is not None and (cwd == ROOT or cwd == expected_cwd or expected_cwd in cwd.parents), f"refusing next-server process outside scratch: {pid} {command}")


def _group_alive(pgid: int) -> bool:
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return False
    return True


def cleanup() -> int:
    _assert(PIDS.is_file() and not PIDS.is_symlink(), "owned process record missing")
    payload = _read_json(PIDS)
    _assert(Path(str(payload.get("scratch_root", ""))).resolve() == ROOT, "unowned scratch record")
    _assert(tuple(payload.get("ports", ())) == PORTS, "altered port record")
    groups: list[tuple[str, int]] = []
    for name in ("backend", "frontend"):
        record = payload.get("roots", {}).get(name)
        _assert(isinstance(record, dict), f"missing {name} root")
        pid, pgid = int(record.get("pid", 0)), int(record.get("pgid", 0))
        expected_cwd = Path(str(record.get("cwd", ""))).resolve()
        _assert(pid > 1 and pgid > 1 and expected_cwd in {ROOT, FRONTEND}, f"invalid {name} record")
        _assert_owned_group(pid, pgid, expected_cwd)
        groups.append((name, pgid))

    for _, pgid in groups:
        os.killpg(pgid, signal.SIGTERM)
    deadline = time.monotonic() + 10
    while any(_group_alive(pgid) for _, pgid in groups) and time.monotonic() < deadline:
        time.sleep(0.1)
    alive = [name for name, pgid in groups if _group_alive(pgid)]
    _assert(not alive, f"owned groups did not exit: {alive}")
    _ports_free()
    PIDS.unlink()
    _write_json(CLEANUP, {"cleanup": "complete", "ports_free": True, "groups": [name for name, _ in groups]})
    print(json.dumps({"cleanup": "complete", "ports_free": True}))
    return 0


if __name__ == "__main__":
    _assert(len(sys.argv) == 2 and sys.argv[1] in {"start", "cleanup"}, "usage: launcher.py start|cleanup")
    raise SystemExit(start() if sys.argv[1] == "start" else cleanup())

