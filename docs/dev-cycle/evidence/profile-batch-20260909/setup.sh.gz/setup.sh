#!/bin/zsh
set -euo pipefail

readonly SOURCE_ROOT="/Users/freelife/vibe/lecture/hodu/closing-bet-demo"
readonly SCRATCH_ROOT="${0:A:h}"
readonly CHECKOUT="$SCRATCH_ROOT/checkout"

[[ -d "$SOURCE_ROOT/.git" ]] || { print -u2 "source repository unavailable"; exit 1; }
[[ ! -e "$CHECKOUT" ]] || { print -u2 "scratch checkout already exists"; exit 1; }

tracked_envs=$(git -C "$SOURCE_ROOT" ls-tree -r --name-only HEAD | awk -F/ '$NF ~ /^[.]env/ && $NF != ".env.example"')
[[ -z "$tracked_envs" ]] || { print -u2 "tracked runtime env forbidden: $tracked_envs"; exit 1; }

umask 077
mkdir -p "$CHECKOUT"
git -C "$SOURCE_ROOT" archive --format=tar HEAD -- . ':(exclude)data' | tar -xf - -C "$CHECKOUT"
for blocked in "$CHECKOUT/.env" "$CHECKOUT/.env.local" "$CHECKOUT/frontend/.env" "$CHECKOUT/frontend/.env.local" "$CHECKOUT/data"; do
  [[ ! -e "$blocked" && ! -L "$blocked" ]] || { print -u2 "copied runtime state: $blocked"; exit 1; }
done
[[ -d "$SOURCE_ROOT/venv" && -d "$SOURCE_ROOT/frontend/node_modules" ]] || { print -u2 "dependency source unavailable"; exit 1; }
ln -s "$SOURCE_ROOT/venv" "$CHECKOUT/venv"
ln -s "$SOURCE_ROOT/frontend/node_modules" "$CHECKOUT/frontend/node_modules"
print -r -- "profile scratch checkout prepared: $CHECKOUT"
