#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""FE-022/FE-039 profile UI의 local-only synthetic API fixture."""

from __future__ import annotations

import argparse
import json
import os
import secrets
import subprocess
import sys
import tempfile
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
CHECKOUT = ROOT / "checkout"
FRONTEND = CHECKOUT / "frontend"
BACKEND_PORT = 57372
NEXT_PORT = 57371
ORIGINAL_ROOT = Path("/Users/freelife/vibe/lecture/hodu/closing-bet-demo").resolve()
FAKE_ENV = ROOT / "fake.env"
COOKIE = ROOT / "ordinary-nextauth-cookie.json"
PROFILE = ROOT / "profile.json"
REQUESTS = ROOT / "requests.jsonl"
CAPTURE = ROOT / "profile-posts.jsonl"


def _assert(value: bool, message: str) -> None:
    if not value:
        raise RuntimeError(message)


def _write(path: Path, text: str) -> None:
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, prefix=path.name + ".", suffix=".tmp", delete=False) as handle:
        handle.write(text)
        temporary = Path(handle.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)
    os.chmod(path, 0o600)


def _write_json(path: Path, value: Any) -> None:
    _write(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def _read_json(path: Path) -> dict[str, Any]:
    _assert(path.is_file() and not path.is_symlink(), f"missing synthetic state: {path.name}")
    value = json.loads(path.read_text(encoding="utf-8"))
    _assert(isinstance(value, dict), f"synthetic state must be an object: {path.name}")
    return value


def _assert_checkout(*, preparing: bool) -> None:
    _assert(CHECKOUT.is_dir() and FRONTEND.is_dir(), "run setup.sh before prepare")
    _assert(CHECKOUT.resolve() != ORIGINAL_ROOT, "original checkout is forbidden")
    _assert((CHECKOUT / "venv").is_symlink(), "checkout venv link is missing")
    _assert((FRONTEND / "node_modules").is_symlink(), "checkout node_modules link is missing")
    for forbidden in (CHECKOUT / ".env", CHECKOUT / ".env.local", FRONTEND / ".env", FRONTEND / ".env.local"):
        _assert(not forbidden.exists() and not forbidden.is_symlink(), f"copied runtime env: {forbidden.name}")
    data = CHECKOUT / "data"
    if preparing:
        _assert(not data.exists() and not data.is_symlink(), "copied runtime data")
    else:
        _assert(not data.is_symlink(), "scratch data must not link to source")


def _cookie(secret: str) -> list[dict[str, Any]]:
    source = """
const { encode } = require('next-auth/jwt');
let input = ''; process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => input += chunk);
process.stdin.on('end', async () => {
  const token = await encode({ token: JSON.parse(input), secret: process.env.NEXTAUTH_SECRET, maxAge: 3600 });
  process.stdout.write(JSON.stringify({name: 'next-auth.session-token', value: token}));
});
"""
    result = subprocess.run(
        ["node", "-e", source],
        cwd=FRONTEND,
        env={"PATH": os.environ.get("PATH", ""), "HOME": os.environ.get("HOME", ""), "NEXTAUTH_SECRET": secret},
        input=json.dumps({"name": "일반 사용자", "email": "ordinary@example.test", "sub": "ordinary@example.test"}),
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )
    _assert(result.returncode == 0, "synthetic cookie creation failed")
    token = json.loads(result.stdout)
    return [{"name": token["name"], "value": token["value"], "domain": "127.0.0.1", "path": "/", "httpOnly": True, "secure": False, "sameSite": "Lax"}]


def prepare() -> int:
    _assert_checkout(preparing=True)
    secret = secrets.token_urlsafe(32)
    values = {
        "GOOGLE_CLIENT_ID": "profile-qa-client",
        "GOOGLE_CLIENT_SECRET": "profile-qa-secret",
        "NEXTAUTH_SECRET": secret,
        "NEXTAUTH_URL": f"http://127.0.0.1:{NEXT_PORT}",
        "NEXTAUTH_URL_INTERNAL": f"http://127.0.0.1:{NEXT_PORT}",
        "API_URL": f"http://127.0.0.1:{BACKEND_PORT}",
        "INTERNAL_IDENTITY_SECRET": secrets.token_urlsafe(32),
        "ADMIN_EMAILS": "admin-only@example.test",
        "SCHEDULER_ENABLED": "false",
        "NEXT_TELEMETRY_DISABLED": "1",
        "NEXT_TRACE_UPLOAD_DISABLED": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "CI": "1",
    }
    _write(FAKE_ENV, "".join(f"{key}={value}\n" for key, value in values.items()))
    _write_json(COOKIE, _cookie(secret))
    _write_json(PROFILE, {
        "name": "일반 사용자",
        "email": "ordinary@example.test",
        "persona": "주식 투자를 배우고 있는 열정적인 투자자",
    })
    for path in (REQUESTS, CAPTURE):
        path.unlink(missing_ok=True)
    print(json.dumps({"prepared": True, "ports": [NEXT_PORT, BACKEND_PORT], "ordinary_user": True, "synthetic_cookie": True}))
    return 0


def _log_request(path: str, status: int) -> None:
    with REQUESTS.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"method": Handler.command_name, "path": path, "status": status, "synthetic": True}) + "\n")


def _read_body(handler: BaseHTTPRequestHandler) -> dict[str, Any]:
    length = int(handler.headers.get("Content-Length", "0"))
    _assert(0 <= length <= 4096, "profile body length is invalid")
    value = json.loads(handler.rfile.read(length).decode("utf-8")) if length else {}
    _assert(isinstance(value, dict), "profile body must be an object")
    return value


class Handler(BaseHTTPRequestHandler):
    server_version = "ProfileUiFixture/1"
    command_name = "GET"

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def _reply(self, status: int, value: Any) -> None:
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        with REQUESTS.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"method": self.command, "path": urlparse(self.path).path, "status": status, "synthetic": True}) + "\n")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/kr/chatbot/profile":
            self._reply(200, _read_json(PROFILE))
        elif path == "/api/kr/user/quota":
            self._reply(200, {"usage": 1, "limit": 10, "remaining": 9, "is_admin": False})
        elif path == "/api/admin/check":
            self._reply(200, {"isAdmin": False})
        elif path == "/api/kr/chatbot/models":
            self._reply(200, {"models": ["synthetic-model"], "current": "synthetic-model"})
        elif path == "/api/kr/chatbot/sessions":
            self._reply(200, {"sessions": []})
        elif path == "/api/kr/chatbot/history":
            self._reply(200, {"history": []})
        elif path == "/api/kr/market-gate":
            self._reply(200, {"score": 70, "status": "GREEN", "label": "합성 시장", "sectors": []})
        elif path in {"/api/kr/jongga-v2/latest", "/api/kr/jongga-v2/results", "/api/kr/jongga-v2/history/2026-09-09"}:
            self._reply(200, {
                "date": "2026-09-09", "total_candidates": 0, "filtered_count": 0,
                "signals": [], "updated_at": "2026-09-09T17:00:00+09:00",
                "status": "success", "source": "synthetic-profile-ui",
            })
        elif path == "/api/kr/jongga-v2/dates":
            self._reply(200, ["2026-09-09"])
        elif path == "/api/kr/jongga-v2/status":
            self._reply(200, {"isRunning": False, "is_running": False, "status": "IDLE", "message": "합성 유휴 상태"})
        else:
            self._reply(404, {"error": "synthetic profile API allowlist only"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/kr/chatbot/profile":
            body = _read_body(self)
            name, persona = body.get("name"), body.get("persona")
            if not isinstance(name, str) or not isinstance(persona, str) or not name.strip() or len(name) > 120 or len(persona) > 500:
                self._reply(400, {"error": "invalid synthetic profile"})
                return
            profile = _read_json(PROFILE)
            profile.update({"name": name, "persona": persona})
            _write_json(PROFILE, profile)
            with CAPTURE.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps({"name": name, "persona": persona, "synthetic": True}, ensure_ascii=False) + "\n")
            self._reply(200, {"status": "success", "profile": profile})
        elif path == "/api/system/log-event":
            # The real Sidebar issues this after profile success. Capture only path/status;
            # it never reaches a real activity log or profile store.
            self._reply(200, {"status": "captured"})
        else:
            self._reply(405, {"error": "fixture blocks LLM, trades, sends, deletion, env, and data writes"})

    def do_DELETE(self) -> None:
        self._reply(405, {"error": "method blocked"})

    do_PUT = do_DELETE
    do_PATCH = do_DELETE


def serve() -> int:
    _assert_checkout(preparing=False)
    _assert(FAKE_ENV.exists() and PROFILE.exists(), "run prepare before serve")
    ThreadingHTTPServer(("127.0.0.1", BACKEND_PORT), Handler).serve_forever(poll_interval=0.2)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "serve"))
    command = parser.parse_args().command
    return prepare() if command == "prepare" else serve()


if __name__ == "__main__":
    raise SystemExit(main())
