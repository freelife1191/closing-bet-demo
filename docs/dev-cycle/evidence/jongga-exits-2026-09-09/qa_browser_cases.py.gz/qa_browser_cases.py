import pathlib,subprocess,sys,json,re,time
P=pathlib.Path(__file__).resolve().parent;Q=P/'qa';E=P/'evidence'
def ab(*args,stdin=None):
 r=subprocess.run([sys.executable,str(P/'browser.py'),*map(str,args)],input=stdin,capture_output=True,text=True,timeout=55)
 if r.returncode:raise RuntimeError(r.stdout+r.stderr)
 return r.stdout.strip()
def js(code):return json.loads(ab('eval','--stdin',stdin=code))
def snap():return ab('snapshot','-i')
def click(pattern):
 tree=snap();lines=[line for line in tree.splitlines() if re.search(pattern,line)]
 assert len(lines)==1,(pattern,lines)
 ref=re.search(r'ref=(e\d+)',lines[0]);assert ref,lines
 return ab('click','@'+ref[1])
def mode(kind,name):
 r=subprocess.run([str(P/'checkout/venv/bin/python'),str(Q/'qa_fixture.py'),'set-mode',kind,name],capture_output=True,text=True,timeout=15)
 assert r.returncode==0,r.stderr
 return r.stdout

def capture(name):
 ab('wait','--fn',"document.readyState === 'complete'")
 data=js("({url:location.href,text:document.body.innerText,width:innerWidth,height:innerHeight,overflow:document.documentElement.scrollWidth-innerWidth})")
 (E/f'{name}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
 (E/f'{name}.snapshot.txt').write_text(snap())
 ab('screenshot',str(E/f'{name}.png'))
 (E/f'{name}.errors.json').write_text(ab('errors','--json'))
 (E/f'{name}.console.json').write_text(ab('console','--json'))
 return data

def ref_for(pattern):
 lines=[l for l in snap().splitlines() if re.search(pattern,l)];assert len(lines)==1,lines
 return '@'+re.search(r'ref=(e\d+)',lines[0])[1]
