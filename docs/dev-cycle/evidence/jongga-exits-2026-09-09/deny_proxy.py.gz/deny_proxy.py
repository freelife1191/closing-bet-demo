import http.server,json,os
from pathlib import Path
class Deny(http.server.BaseHTTPRequestHandler):
 def deny(self):
  self.send_response(403);self.end_headers()
 def log_message(self,*args):pass
 do_GET=deny;do_CONNECT=deny;do_POST=deny
p=Path(__file__).resolve().parent
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Deny)
(p/'proxy-ready.json').write_text(json.dumps({'pid':os.getpid(),'port':server.server_port,'cwd':str(p)}))
server.serve_forever()
