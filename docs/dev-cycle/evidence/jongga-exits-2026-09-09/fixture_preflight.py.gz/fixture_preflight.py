import sys,json,importlib.util
from pathlib import Path
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p/'checkout'))
spec=importlib.util.spec_from_file_location('qa_fixture',p/'qa/qa_fixture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results=[]
for variant in ['stored','missing','custom','malicious','empty-reason']:
 for daily in ['targethit','stophit','sameday','open']:
  result=m._calculation({'signal_variant':variant,'daily_outcome':daily});trade=result['trade'];stats=result['stats'];sig=result['signals'][0]
  expected='WIN' if daily=='targethit' else 'OPEN' if daily=='open' else 'LOSS'
  roi=(8 if variant=='custom' else 5) if expected=='WIN' else (-4 if variant=='custom' else -3) if expected=='LOSS' else 5
  assert trade['outcome']==expected and trade['roi']==roi,(variant,daily,trade)
  assert stats['count']==1 and stats['win_rate']==(100 if expected=='WIN' else 0),(variant,daily,stats)
  results.append({'variant':variant,'daily':daily,'outcome':expected,'roi':roi,'target':sig['target_price'],'stop':sig['stop_price']})
(p/'evidence/fixture-preflight-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('20 fixture calculation combinations passed; browser not run')
