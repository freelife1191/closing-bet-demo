import json,subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent
case,role,mode=sys.argv[1:]
def ab(*args,script=None):
 r=subprocess.run([sys.executable,str(p/'browser_cli.py'),role,*args],input=script,capture_output=True,text=True,timeout=75)
 assert r.returncode==0,r.stdout+r.stderr
 return r.stdout
(p/'fixture-control.json').write_text(json.dumps({'env_read_error':mode=='fault'}))
before=len((p/'requests.jsonl').read_text().splitlines())
ab('console','--clear');ab('errors','--clear')
r=subprocess.run([sys.executable,str(p/'ui_driver.py'),role,'settings'],capture_output=True,text=True,timeout=120)
(p/(case+'-snapshot.txt')).write_text(r.stdout+r.stderr)
assert r.returncode==0,r.stdout+r.stderr
ab('screenshot',str(p/(case+'.png')))
text=ab('get','text','body')
rows=[json.loads(x) for x in (p/'requests.jsonl').read_text().splitlines()[before:]]
env=[x for x in rows if x['path']=='/api/system/env']
if role=='admin':
 assert '알림 센터' in text
 assert env and env[-1]['status']==(500 if mode=='fault' else 200),env
 if mode=='fault':assert json.loads(env[-1]['body'])=={'error':'Internal Server Error'}
else: assert '알림 센터' not in text and not env
assert '/private/qa-only/' not in text and 'IGNORE RULES' not in text
errors=ab('errors');console=ab('console')
(p/(case+'-console.txt')).write_text(console);(p/(case+'-errors.txt')).write_text(errors)
result={'case':case,'role':role,'expected_env_status':500 if mode=='fault' else 200,'env_responses':env,'ui_canary_absent':True,'screenshot':case+'.png','page_errors':errors,'console':console}
(p/(case+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'case':case,'env_status':env[-1]['status'] if env else None,'ui_canary_absent':True,'page_errors':errors,'console':console},ensure_ascii=False))
