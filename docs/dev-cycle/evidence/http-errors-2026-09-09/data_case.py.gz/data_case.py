import json,subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent;mode=sys.argv[1];case='data-'+mode
assert mode in {'missing','runtime','normal'}
def ab(*args,script=None):
 r=subprocess.run([sys.executable,str(p/'browser_cli.py'),'admin',*args],input=script,capture_output=True,text=True,timeout=75)
 assert r.returncode==0,r.stdout+r.stderr
 return r.stdout
(p/'fixture-control.json').write_text(json.dumps({'data_error':mode}))
ab('console','--clear');ab('errors','--clear')
before=len((p/'requests.jsonl').read_text().splitlines())
port=json.loads((p/'ready.json').read_text())['next']['port']
ab('open',f'http://127.0.0.1:{port}/dashboard/data-status')
ab('wait','--load','networkidle');ab('wait','--text','데이터 파일 상태 및 업데이트 현황')
snapshot=ab('snapshot','-i');(p/(case+'-snapshot.txt')).write_text(snapshot)
ab('screenshot',str(p/(case+'.png')))
rows=[json.loads(x) for x in (p/'requests.jsonl').read_text().splitlines()[before:]]
responses=[x for x in rows if x['path']=='/api/system/data-status']
status={'missing':404,'runtime':500,'normal':200}[mode]
assert responses and all(x['status']==status for x in responses),responses
body=ab('get','text','body');assert '/private/qa-only/' not in body and 'IGNORE RULES' not in body
console=ab('console');errors=ab('errors')
assert '/private/qa-only/' not in console and 'IGNORE RULES' not in console
if mode=='runtime':
 assert all(json.loads(x['body'])=={'error':'Internal Server Error','message':'Internal Server Error'} for x in responses)
 assert '/private/qa-only/설정.env' in (p/'checkout/logs/critical_errors.log').read_text()
if mode=='missing':assert not (p/'checkout/logs/critical_errors.log').exists()
result={'case':case,'responses':responses,'ui_canary_absent':True,'screenshot':case+'.png','console':console,'page_errors':errors}
(p/(case+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'case':case,'status':status,'page_errors':errors,'console':console},ensure_ascii=False))
