#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""INFRA-055 fixture의 소유 프로세스를 시작·검증·종료한다."""

from __future__ import annotations

import argparse
import json
import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
CLONE = ROOT / "checkout"
FRONTEND = CLONE / "frontend"
FIXTURE = ROOT / "qa_fixture.py"
READY = ROOT / "ready.json"
SECRETS = ROOT / "fixture-secrets.json"
BACKEND_LOG = ROOT / "backend.log"
NEXT_LOG = ROOT / "next.log"
LOCAL_NETWORK_POLICY = ROOT / "local-network.sb"
START_TIMEOUT_SECONDS = 120


class LaunchFailure(RuntimeError):
    """소유 증명이 되지 않는 프로세스 조작을 막는다."""


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise LaunchFailure(message)


def _safe_environment() -> dict[str, str]:
    allowed = ("PATH", "HOME", "USER", "LOGNAME", "SHELL", "TMPDIR", "TMP", "TEMP", "LANG", "LC_ALL", "TZ")
    return {key: os.environ[key] for key in allowed if key in os.environ}


def _read_private_json(path: Path) -> dict[str, Any]:
    _assert(path.is_file() and not path.is_symlink(), f"{path.name}이 없습니다")
    return json.loads(path.read_text(encoding="utf-8"))


def _listeners(port: int) -> list[int]:
    result = subprocess.run(["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-Fp"], capture_output=True, text=True, check=False)
    _assert(result.returncode in (0, 1), "lsof 실행에 실패했습니다")
    return [int(line[1:]) for line in result.stdout.splitlines() if line.startswith("p")]


def _wait_listener(port: int, process: subprocess.Popen[bytes], name: str) -> None:
    deadline = time.monotonic() + START_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise LaunchFailure(f"{name}이 readiness 전에 종료했습니다")
        listeners = _listeners(port)
        if listeners:
            process_group = os.getpgid(process.pid)
            if all(os.getpgid(pid) == process_group for pid in listeners):
                try:
                    with socket.create_connection(("127.0.0.1", port), timeout=1):
                        return
                except OSError:
                    pass
        time.sleep(0.2)
    raise LaunchFailure(f"{name} readiness 시간이 초과했습니다")


def _process_cwd(pid: int) -> str | None:
    result = subprocess.run(["lsof", "-a", "-p", str(pid), "-d", "cwd", "-Fn"], capture_output=True, text=True, check=False)
    for line in result.stdout.splitlines():
        if line.startswith("n"):
            return line[1:]
    return None


def _group_members(pgid: int) -> list[int]:
    result = subprocess.run(["ps", "-axo", "pid=,pgid="], capture_output=True, text=True, check=False)
    _assert(result.returncode == 0, "ps 실행에 실패했습니다")
    members: list[int] = []
    for line in result.stdout.splitlines():
        fields = line.split()
        if len(fields) == 2 and int(fields[1]) == pgid:
            members.append(int(fields[0]))
    return members


def _spawn(command: list[str], *, cwd: Path, log: Path, env: dict[str, str]) -> subprocess.Popen[bytes]:
    output = log.open("ab")
    return subprocess.Popen(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)


def prepare(fresh_cache: bool) -> dict[str, Any]:
    command = [sys.executable, str(FIXTURE), "prepare"]
    if fresh_cache:
        command.append("--fresh-cache")
    result = subprocess.run(command, cwd=ROOT, env=_safe_environment(), capture_output=True, text=True, check=False, timeout=45)
    _assert(result.returncode == 0, "fixture 준비에 실패했습니다")
    return json.loads(result.stdout)


def start(mode: str, fresh_cache: bool) -> None:
    _assert(not READY.exists(), "ready.json이 남아 있습니다. 먼저 stop을 실행하세요")
    fixture = prepare(fresh_cache)
    backend_port, next_port = int(fixture["backend_port"]), int(fixture["next_port"])
    base_env = _safe_environment()
    base_env.update({"NEXT_TELEMETRY_DISABLED": "1", "NEXT_TRACE_UPLOAD_DISABLED": "1", "CI": "1"})
    fake_values = _read_private_json(ROOT / "fixture-secrets.json")
    # launcher가 부모 process env까지 필터하는지 실제로 증명할 별도 backend-only 값이다.
    # fake.env의 값과 별개라 cache scanner가 두 유입 경로를 모두 검사한다.
    parent_sentinels = {
        "SMTP_PASSWORD": f"INFRA055_PARENT_SMTP_{fake_values['head'][:12]}",
        "UNKNOWN_BACKEND_SECRET": f"INFRA055_PARENT_UNKNOWN_{fake_values['head'][:12]}",
        "GOOGLE_API_KEY": f"INFRA055_PARENT_GOOGLE_{fake_values['head'][:12]}",
    }
    backend_python = CLONE / "venv" / "bin" / "python"
    _assert(backend_python.is_file(), "clone venv Python이 없습니다")
    backend = _spawn(["/usr/bin/sandbox-exec", "-f", str(LOCAL_NETWORK_POLICY), str(backend_python), str(FIXTURE), "backend", "--port", str(backend_port)], cwd=CLONE, log=BACKEND_LOG, env=base_env)
    try:
        _wait_listener(backend_port, backend, "fixture Flask")
        npm_command = ["/usr/bin/sandbox-exec", "-f", str(LOCAL_NETWORK_POLICY), "npm", "run", "dev" if mode == "dev" else "build"]
        if mode == "dev":
            npm_command.extend(["--", "--port", str(next_port), "--hostname", "127.0.0.1"])
            next_process = _spawn(npm_command, cwd=FRONTEND, log=NEXT_LOG, env={**base_env, **parent_sentinels, "PORT": str(next_port)})
            _wait_listener(next_port, next_process, "Next dev")
        else:
            with NEXT_LOG.open("ab") as output:
                build = subprocess.run(npm_command, cwd=FRONTEND, env={**base_env, **parent_sentinels, "PORT": str(next_port)}, stdout=output, stderr=subprocess.STDOUT, check=False, timeout=300)
            _assert(build.returncode == 0, "npm run build가 실패했습니다")
            next_process = _spawn(["/usr/bin/sandbox-exec", "-f", str(LOCAL_NETWORK_POLICY), "npm", "run", "start", "--", "--port", str(next_port), "--hostname", "127.0.0.1"], cwd=FRONTEND, log=NEXT_LOG, env={**base_env, **parent_sentinels, "PORT": str(next_port)})
            _wait_listener(next_port, next_process, "Next start")
        ready = {
            "mode": mode, "cwd": str(CLONE), "head": fixture["head"],
            "backend": {"port": backend_port, "pid": backend.pid, "pgid": os.getpgid(backend.pid), "cwd": str(CLONE)},
            "next": {"port": next_port, "pid": next_process.pid, "pgid": os.getpgid(next_process.pid), "cwd": str(FRONTEND)},
        }
        temporary = READY.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(ready, indent=2) + "\n", encoding="utf-8")
        os.chmod(temporary, 0o600)
        os.replace(temporary, READY)
        print(json.dumps({"mode": mode, "next_port": next_port, "backend_port": backend_port, "head": fixture["head"]}))
    except Exception:
        _terminate_owned_processes([process for process in (locals().get("backend"), locals().get("next_process")) if process is not None])
        raise


def _owned(record: dict[str, Any]) -> bool:
    pid, port, expected_cwd = int(record["pid"]), int(record["port"]), str(record["cwd"])
    try:
        listeners = _listeners(port)
        return (
            os.getpgid(pid) == int(record["pgid"])
            and _process_cwd(pid) == expected_cwd
            and bool(listeners)
            and all(os.getpgid(listener) == int(record["pgid"]) for listener in listeners)
        )
    except ProcessLookupError:
        return False


def _terminate_owned_processes(processes: list[subprocess.Popen[bytes]]) -> None:
    groups = {os.getpgid(process.pid) for process in processes if process.poll() is None}
    for pgid in groups:
        os.killpg(pgid, signal.SIGTERM)
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline and any(_group_members(pgid) for pgid in groups):
        time.sleep(0.2)
    if any(_group_members(pgid) for pgid in groups):
        for pgid in groups:
            if _group_members(pgid):
                os.killpg(pgid, signal.SIGKILL)
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and any(_group_members(pgid) for pgid in groups):
            time.sleep(0.1)
    _assert(not any(_group_members(pgid) for pgid in groups), "소유 fixture process group 정리가 실패했습니다")


def stop() -> None:
    ready = _read_private_json(READY)
    records = [ready["next"], ready["backend"]]
    _assert(all(_owned(record) for record in records), "fixture 소유 프로세스 증명이 실패했습니다")
    for record in records:
        os.killpg(int(record["pgid"]), signal.SIGTERM)
    groups = {int(record["pgid"]) for record in records}
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline and (any(_listeners(int(record["port"])) for record in records) or any(_group_members(pgid) for pgid in groups)):
        time.sleep(0.2)
    _assert(not any(_listeners(int(record["port"])) for record in records) and not any(_group_members(pgid) for pgid in groups), "fixture 프로세스가 종료되지 않았습니다")
    READY.unlink()
    print(json.dumps({"stopped": True}))


def main() -> int:
    parser = argparse.ArgumentParser(description="INFRA-055 실제 QA 프로세스 supervisor")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for name in ("prepare", "start-dev", "build-start"):
        command = subparsers.add_parser(name)
        command.add_argument("--fresh-cache", action="store_true")
    subparsers.add_parser("stop")
    subparsers.add_parser("scan-caches")
    args = parser.parse_args()
    try:
        if args.command == "prepare":
            print(json.dumps(prepare(args.fresh_cache)))
        elif args.command == "start-dev":
            start("dev", args.fresh_cache)
        elif args.command == "build-start":
            start("build", args.fresh_cache)
        elif args.command == "scan-caches":
            raise LaunchFailure("scan-caches는 qa_fixture.py에서 실행하세요")
        else:
            stop()
        return 0
    except (LaunchFailure, OSError, subprocess.SubprocessError, json.JSONDecodeError) as error:
        print(f"launcher error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
