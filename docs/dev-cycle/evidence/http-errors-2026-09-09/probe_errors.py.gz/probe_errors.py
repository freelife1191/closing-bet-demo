import json,subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent
script='''(async () => {
 const cases=[
 ['missing','GET','/api/no-such-route',404],
 ['unicode','GET','/api/없는경로',404],
 ['long','GET','/api/'+ 'a'.repeat(2048),404],
 ['method','POST','/api/admin/check',405],
 ['env-method','DELETE','/api/system%2Fenv',405],
 ['bad','GET','/api/qa-bad-request',400],
 ['rate','GET','/api/qa-rate-limit',429],
 ['parse','POST','/api/system/log-event',400],
 ['form','POST','/api/system/log-event',415],
 ['custom','GET','/api/qa-custom-http',418]
 ];
 const results=[];
 for (const [name,method,path,expected] of cases) {
  const options=name==='parse'?{method,headers:{'Content-Type':'application/json'},body:'{'}:name==='form'?{method,headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=LOGIN'}:{method};
  const r=await fetch(path,options);const body=await r.text();
  results.push({name,method,path,status:r.status,expected,allow:r.headers.get('allow'),retryAfter:r.headers.get('retry-after'),body,custom:r.headers.get('x-qa-contract'),canaryPresent:body.includes('/private/qa-only/')});
 }
 return results;
})()'''
r=subprocess.run([sys.executable,str(p/'browser_cli.py'),'admin','eval','--stdin'],input=script,capture_output=True,text=True,timeout=90)
(p/'http-probe-raw.txt').write_text(r.stdout+r.stderr)
assert r.returncode==0,r.stderr
results=json.loads(r.stdout);(p/'http-probes.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
assert all(x['status']==x['expected'] and not x['canaryPresent'] for x in results),results
assert results[3]['allow'] and 'GET' in results[3]['allow']
assert results[4]['allow'] and 'POST' in results[4]['allow']
assert results[6]['retryAfter']=='17'
assert results[-1]['body']=='custom-public-response' and results[-1]['custom']=='preserved'
critical=p/'checkout/logs/critical_errors.log'
assert not critical.exists(),'routing errors unexpectedly logged as critical'
print(json.dumps({'probes':len(results),'passed':True,'critical_log_absent':True}))
