from pathlib import Path
import os,signal,json,subprocess,shutil,time,gzip,hashlib
p=Path(__file__).resolve().parent;c=p/'checkout';ev=c/'docs/dev-cycle/evidence/http-errors-2026-09-09'
x=json.loads((p/'proxy-ready.json').read_text());pid=x['pid'];port=x['port']
cwd=subprocess.check_output(['lsof','-a','-p',str(pid),'-d','cwd','-Fn'],text=True)
assert 'n'+str(p) in cwd
assert subprocess.run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'],capture_output=True).returncode==0
os.kill(pid,signal.SIGTERM)
for _ in range(30):
 if subprocess.run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'],capture_output=True).returncode==1:break
 time.sleep(.1)
else:raise RuntimeError('proxy still listening')
ns=Path('/Users/freelife/.agent-browser/namespaces/devcycle-errors-k6-l42b8')
assert ns.name=='devcycle-errors-k6-l42b8' and not ns.is_symlink()
if ns.exists():shutil.rmtree(ns)
# Only synthetic, value-free evidence is retained. Cookies/env/profile files are never copied.
values={line.split('=',1)[0]:line.split('=',1)[1] for line in (p/'fake.env').read_text().splitlines() if '=' in line}
private=['NEXTAUTH_SECRET','ADMIN_API_TOKEN','INTERNAL_IDENTITY_SECRET','SMTP_PASSWORD','GOOGLE_API_KEY','UNKNOWN_BACKEND_SECRET']
patterns=['*-snapshot.txt','*-console.txt','*-errors.txt','settings-*.json','data-*.json','*.png','http-probes.json','http-probe-raw.txt','viewer-env-probe.json','requests.jsonl','browser-commands.jsonl','backend.log','next.log','qa-verification.json','qa-scope.json','ownership.json']
files={f for pattern in patterns for f in p.glob(pattern)}
for f in files:
 assert not any(values[k].encode() in f.read_bytes() for k in private),f.name
 if f.suffix in {'.log','.txt','.jsonl'}:(ev/(f.name+'.gz')).write_bytes(gzip.compress(f.read_bytes()))
 else:shutil.copy2(f,ev/f.name)
for name in ['qa_fixture.py','launch_qa.py','browser_cli.py','ui_driver.py','verify.py','probe_errors.py','ui_case.py','data_case.py','deny_proxy.py','local-network.sb','no-network.sb','close_evidence.py']:
 f=p/name;(ev/(name+'.gz')).write_bytes(gzip.compress(f.read_bytes()))
for f in [c/'.env',c/'frontend/.env',p/'fake.env',p/'fixture-secrets.json',p/'admin-nextauth-cookie.json',p/'viewer-nextauth-cookie.json']:
 if f.exists() or f.is_symlink():f.unlink()
for name in ['browser-admin-batch','browser-viewer-batch']:
 f=p/name
 if f.exists():assert not f.is_symlink();shutil.rmtree(f)
cleanup={'runtime':'complete','browser_sessions_closed':['admin','viewer'],'namespace_removed':not ns.exists(),'ports_stopped':[57161,57162,port],'fake_credentials_removed':True,'workspace':'pending final integration'}
for port in cleanup['ports_stopped']:assert subprocess.run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'],capture_output=True).returncode==1
(ev/'cleanup.json').write_text(json.dumps(cleanup,indent=2))
f=ev/'qa-verification.json';x=json.loads(f.read_text());x['cleanup']='runtime and credentials complete; workspace removal after integration';f.write_text(json.dumps(x,ensure_ascii=False,indent=2))
print(json.dumps(cleanup))
