#!/bin/zsh
set -euo pipefail
readonly SRC="/Users/freelife/vibe/lecture/hodu/closing-bet-demo"
readonly ROOT="${0:A:h}"
readonly C="$ROOT/checkout"
[[ ! -e "$C" ]] || { print -u2 exists; exit 1; }
envs=$(git -C "$SRC" ls-tree -r --name-only HEAD | awk -F/ '$NF ~ /^[.]env/ && $NF != ".env.example"'); [[ -z "$envs" ]] || exit 1
mkdir -p "$C"; git -C "$SRC" archive --format=tar HEAD -- . ':(exclude)data' | tar -xf - -C "$C"
[[ ! -e "$C/data" && ! -e "$C/.env" && ! -e "$C/frontend/.env" ]] || exit 1
ln -s "$SRC/venv" "$C/venv"; ln -s "$SRC/frontend/node_modules" "$C/frontend/node_modules"
