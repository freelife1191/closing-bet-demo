#!/usr/bin/env python3
import argparse,json,os,secrets,subprocess,tempfile,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
R=Path(__file__).resolve().parent;C=R/"checkout";F=C/"frontend";ENV=R/"fake.env";COOKIE=R/"cookie.json";REQ=R/"requests.jsonl";STREAM=R/"stream.jsonl"

def w(p,v):
 with tempfile.NamedTemporaryFile(mode="w",encoding="utf8",dir=R,delete=False) as f:f.write(v if isinstance(v,str) else json.dumps(v)+"\n");t=f.name
 os.replace(t,p);os.chmod(p,0o600)
def prep():
 assert C.is_dir() and not (C/"data").exists()
 secret=secrets.token_urlsafe(32);w(ENV,f"GOOGLE_CLIENT_ID=chat-qa-client\nGOOGLE_CLIENT_SECRET=chat-qa-secret\nNEXTAUTH_SECRET={secret}\nNEXTAUTH_URL=http://127.0.0.1:57391\nNEXTAUTH_URL_INTERNAL=http://127.0.0.1:57391\nAPI_URL=http://127.0.0.1:57392\nINTERNAL_IDENTITY_SECRET={secrets.token_urlsafe(32)}\nADMIN_EMAILS=admin@example.test\nSCHEDULER_ENABLED=false\nNEXT_TELEMETRY_DISABLED=1\nCI=1\n")
 js="const {encode}=require('next-auth/jwt');let x='';process.stdin.on('data',c=>x+=c);process.stdin.on('end',async()=>process.stdout.write(JSON.stringify({value:await encode({token:JSON.parse(x),secret:process.env.NEXTAUTH_SECRET,maxAge:3600})})));"
 q=subprocess.run(["node","-e",js],cwd=F,env={"PATH":os.environ.get("PATH",""),"HOME":os.environ.get("HOME",""),"NEXTAUTH_SECRET":secret},input=json.dumps({"name":"채팅 검수자","email":"chat@example.test","sub":"chat@example.test"}),text=True,capture_output=True);assert q.returncode==0
 w(COOKIE,[{"name":"next-auth.session-token","value":json.loads(q.stdout)["value"],"domain":"127.0.0.1","path":"/","httpOnly":True,"secure":False,"sameSite":"Lax"}]);REQ.unlink(missing_ok=True);STREAM.unlink(missing_ok=True)
class H(BaseHTTPRequestHandler):
 def log_message(self,*x):pass
 def reply(self,s,v,h=None):
  b=json.dumps(v,ensure_ascii=False).encode();self.send_response(s);self.send_header("Content-Type","application/json" if not h else h);self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b);open(REQ,"a").write(json.dumps({"method":self.command,"path":urlparse(self.path).path,"status":s})+"\n")
 def do_GET(self):
  p=urlparse(self.path).path
  if p=="/api/kr/chatbot/models":self.reply(200,{"models":["synthetic-chat"],"current":"synthetic-chat"})
  elif p=="/api/kr/chatbot/sessions":self.reply(200,{"sessions":[]})
  elif p=="/api/kr/chatbot/history":self.reply(200,{"history":[]})
  elif p=="/api/kr/user/quota":self.reply(200,{"usage":0,"limit":10,"remaining":10,"is_admin":False})
  elif p=="/api/admin/check":self.reply(200,{"isAdmin":False})
  else:self.reply(404,{"error":"synthetic allowlist"})
 def do_POST(self):
  p=urlparse(self.path).path
  if p!="/api/kr/chatbot":self.reply(405,{"error":"writes blocked"});return
  length=int(self.headers.get('Content-Length','0'));assert 0<=length<=100000
  raw=self.rfile.read(length);payload=json.loads(raw)
  with REQ.open('a') as log:log.write(json.dumps({'method':'POST','path':p,'status':200,'synthetic':True,'message':payload.get('message'),'model':payload.get('model'),'files':0})+'\n')
  time.sleep(20)
  self.send_response(200);self.send_header("Content-Type","text/event-stream");self.send_header("Cache-Control","no-store");self.end_headers()
  try:
   for index in range(60):
    chunk=f"합성 지연 답변 {index} "
    self.wfile.write(f"data: {json.dumps({'session_id':'chat029','answer_chunk':chunk},ensure_ascii=False)}\n\n".encode());self.wfile.flush();time.sleep(1)
   self.wfile.write(b"data: {\"done\":true}\n\n");self.wfile.flush();open(STREAM,"a").write(json.dumps({"status":200,"body":"completed"})+"\n")
  except (BrokenPipeError,ConnectionResetError):open(STREAM,"a").write(json.dumps({"status":200,"body":"connection-closed"})+"\n")
 def do_DELETE(self):self.reply(405,{"error":"blocked"})
 do_PUT=do_DELETE;do_PATCH=do_DELETE
if __name__=="__main__":
 a=argparse.ArgumentParser();a.add_argument("cmd",choices=("prepare","serve"));x=a.parse_args().cmd;prep() if x=="prepare" else ThreadingHTTPServer(("127.0.0.1",57392),H).serve_forever()
