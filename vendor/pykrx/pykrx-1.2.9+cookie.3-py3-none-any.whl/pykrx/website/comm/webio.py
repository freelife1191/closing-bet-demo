from abc import abstractmethod

import requests

from pykrx.website.comm.auth import (
    build_krx_session,
    get_auth_session,
    is_krx_origin,
    public_request,
    set_auth_session,
)

# Initialize session at module load time
_session = build_krx_session()
# Set the auth session for get_auth_session() to work
set_auth_session(_session)


def set_session(session) -> requests.Session | None:
    """Set the global session (deprecated, use KRXSession)"""
    global _session
    _session = session


def get_session() -> requests.Session | None:
    """Get the current KRX session with automatic refresh if expired."""
    return get_auth_session()


class Get:
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0",
            "Referer": "https://data.krx.co.kr/contents/MDC/MDI/outerLoader/index.cmd",
            "X-Requested-With": "XMLHttpRequest",
        }

    def read(self, **params):
        url = self.url
        krxs = get_session() if is_krx_origin(url) else None
        if krxs is None:
            return public_request("GET", url, self.headers, params=params)
        return krxs.get(url, headers=self.headers, params=params)

    @property
    @abstractmethod
    def url(self):
        return NotImplementedError


class Post:
    def __init__(self, headers=None):
        self.headers = {
            "User-Agent": "Mozilla/5.0",
            "Referer": "https://data.krx.co.kr/contents/MDC/MDI/outerLoader/index.cmd",
            "X-Requested-With": "XMLHttpRequest",
        }
        if headers is not None:
            self.headers.update(headers)

    def read(self, **params):
        url = self.url
        krxs = get_session() if is_krx_origin(url) else None
        if krxs is None:
            return public_request("POST", url, self.headers, data=params)
        return krxs.post(url, headers=self.headers, data=params)

    @property
    @abstractmethod
    def url(self):
        return NotImplementedError
