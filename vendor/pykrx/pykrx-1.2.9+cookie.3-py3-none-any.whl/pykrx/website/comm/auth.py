import os
import threading
import time
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urlsplit

import requests

LOGIN_PAGE = "https://data.krx.co.kr/contents/MDC/COMS/client/MDCCOMS001.cmd"
LOGIN_JSP = "https://data.krx.co.kr/contents/MDC/COMS/client/view/login.jsp?site=mdc"
LOGIN_URL = "https://data.krx.co.kr/contents/MDC/COMS/client/MDCCOMS001D1.cmd"
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)


def is_krx_origin(url: str) -> bool:
    """Only this exact HTTPS origin may use the KRX authentication session."""
    parsed = urlsplit(url)
    return parsed.scheme == "https" and parsed.netloc.lower() in (
        "data.krx.co.kr", "data.krx.co.kr:443"
    )


def public_request(method: str, url: str, headers: dict, **kwargs):
    """Send public data requests without ambient or KRX credentials."""
    parsed = urlsplit(url)
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("Credentials in public request URLs are not supported")
    if kwargs.get("cookies") is not None or kwargs.get("auth") is not None:
        raise ValueError("Credentials in public requests are not supported")
    public_headers = {
        key: value for key, value in headers.items()
        if key.lower() not in {"cookie", "authorization", "proxy-authorization"}
    }
    with requests.Session() as session:
        session.trust_env = False
        return session.request(method, url, headers=public_headers, **kwargs)

# Global session reference (set by webio.py)
_auth_session: Optional["KRXSession"] = None

# 재로그인은 한 번에 하나만 한다. 실패하면 이 시각까지 어느 경로에서도 로그인하지 않는다
_refresh_lock = threading.Lock()
_REFRESH_RETRY_SECONDS = 60
_refresh_blocked_until = 0.0


def _is_logout_response(response) -> bool:
    """KRX 가 세션을 끊은 요청에 주는 응답(400, 본문 LOGOUT)인지 판별합니다."""
    return response.status_code == 400 and response.content.strip() == b"LOGOUT"


def _refresh_session(krxs, seen_login_time: float, reason: str) -> bool:
    """재로그인을 직렬화합니다. 요청 뒤 다른 스레드가 이미 로그인했으면 로그인하지 않습니다."""
    global _refresh_blocked_until
    with _refresh_lock:
        if krxs.login_time != seen_login_time:
            return krxs.is_authenticated
        if time.monotonic() < _refresh_blocked_until:
            return False
        login_id = os.getenv("KRX_ID")
        login_pw = os.getenv("KRX_PW")
        if not (login_id and login_pw):
            return False
        print(f"KRX 세션 {reason}, 재로그인 시도...", flush=True)
        if krxs.refresh(login_id, login_pw):
            print("KRX 세션 갱신 완료.", flush=True)
            return True
        _refresh_blocked_until = time.monotonic() + _REFRESH_RETRY_SECONDS
        print(f"KRX 세션 갱신 실패: {krxs.last_error or 'login_rejected'}", flush=True)
        return False


@dataclass
class KRXSession:
    """KRX 인증 세션 관리 클래스

    JSESSIONID 쿠키를 저장하고 만료 시간을 추적하여
    자동 재로그인 및 헤더 추가를 관리합니다.
    """

    session: requests.Session = field(default_factory=requests.Session)
    login_time: float = field(default_factory=time.time)
    expiry_time: float = field(
        default_factory=lambda: time.time() + 3600
    )  # 1 시간 만료
    is_authenticated: bool = False
    cookies: dict = field(default_factory=dict)
    last_error: str = ""

    def is_valid(self, buffer_seconds: int = 300) -> bool:
        """세션이 유효한지 확인 (버퍼 시간 포함)"""
        return self.is_authenticated and time.time() < (
            self.expiry_time - buffer_seconds
        )

    def refresh(self, login_id: str, login_pw: str) -> bool:
        """세션 갱신 (재로그인)"""
        try:
            self.session.close()
        except Exception:
            pass

        self.is_authenticated = False
        self.cookies.clear()
        self.last_error = ""
        self.session.cookies.clear()
        self.session = requests.Session()
        success = login_krx(login_id, login_pw, self.session)

        if not success:
            self.last_error = getattr(self.session, "_pykrx_login_error", "login_rejected")
            self.session.cookies.clear()
            return False

        # login_time 은 마지막에 쓴다. 재로그인 판단의 기준값이라, 인증 상태가 먼저 갖춰져야 한다
        self.expiry_time = time.time() + 3600  # 1 시간 만료
        self.is_authenticated = True
        self.login_time = time.time()

        # 쿠키 추출 및 저장
        for cookie in self.session.cookies:
            self.cookies[cookie.name] = {
                "value": cookie.value,
                "domain": cookie.domain,
                "path": cookie.path,
                "secure": cookie.secure,
                "expires": cookie.expires or 0,
            }

        return True

    def get_headers(self) -> dict:
        """현재 세션에 적합한 헤더 반환"""
        return {
            "User-Agent": USER_AGENT,
            "Referer": "https://data.krx.co.kr/contents/MDC/MDI/outerLoader/index.cmd",
            "X-Requested-With": "XMLHttpRequest",
        }

    def _request(self, method: str, url: str, headers: dict = None, **kwargs):
        request_headers = self.get_headers()
        if headers is not None:
            request_headers.update(headers)
        if not is_krx_origin(url):
            return public_request(method, url, request_headers, **kwargs)
        kwargs["allow_redirects"] = False
        seen_login_time = self.login_time
        response = self.session.request(method, url, headers=request_headers, **kwargs)
        # 로그인한 지 60초 안에 다시 끊기면(다른 프로세스와 서로 끊는 경우 등) 재로그인하지 않는다
        if (
            _is_logout_response(response)
            and time.time() - seen_login_time >= _REFRESH_RETRY_SECONDS
            and _refresh_session(self, seen_login_time, "서버에서 끊김(LOGOUT)")
        ):
            response.close()
            response = self.session.request(method, url, headers=request_headers, **kwargs)
        return response

    def get(self, url: str, headers: dict = None, params: dict = None, **kwargs):
        """GET 요청 전송"""
        return self._request("GET", url, headers, params=params, **kwargs)

    def post(self, url: str, headers: dict = None, data: dict = None, **kwargs):
        """POST 요청 전송"""
        return self._request("POST", url, headers, data=data, **kwargs)


def set_auth_session(session: KRXSession | None) -> None:
    """Set the global auth session (called by webio.py)."""
    global _auth_session
    _auth_session = session


def warmup_krx_session(session: requests.Session) -> None:
    response = session.get(
        LOGIN_PAGE,
        headers={"User-Agent": USER_AGENT},
        timeout=15,
        allow_redirects=False,
    )
    _require_success_status(response)
    response = session.get(
        LOGIN_JSP,
        headers={"User-Agent": USER_AGENT, "Referer": LOGIN_PAGE},
        timeout=15,
        allow_redirects=False,
    )
    _require_success_status(response)


def _require_success_status(response: requests.Response) -> None:
    status_code = response.status_code
    if not isinstance(status_code, int) or not 200 <= status_code < 300:
        raise requests.HTTPError("KRX login response status rejected")


def _login_response_data(response: requests.Response) -> tuple[dict | None, str]:
    """Return a valid login response without exposing server content."""
    status_code = response.status_code
    if not isinstance(status_code, int) or not 200 <= status_code < 300:
        return None, "http_error"
    try:
        data = response.json()
    except (ValueError, TypeError):
        return None, "invalid_json"
    if not isinstance(data, dict) or not isinstance(data.get("_error_code"), str):
        return None, "invalid_schema"
    return data, ""


def _set_login_error(session: requests.Session, category: str) -> None:
    session._pykrx_login_error = category


def login_krx(
    login_id: str, login_pw: str, session: requests.Session | None = None
) -> bool:
    """
    KRX <http://data.krx.co.kr|data.krx.co.kr> 로그인 후 세션 쿠키(JSESSIONID) 를 갱신합니다.

    로그인 흐름:
      1. GET MDCCOMS001.cmd  → 초기 JSESSIONID 발급
      2. GET login.jsp       → iframe 세션 초기화
      3. POST MDCCOMS001D1.cmd → 실제 로그인
      4. CD011(중복 로그인) → skipDup=Y 추가 후 재전송
    """
    if session is None:
        session = requests.Session()

    try:
        warmup_krx_session(session)
    except requests.HTTPError:
        _set_login_error(session, "http_error")
        return False
    except requests.RequestException:
        _set_login_error(session, "network_error")
        return False

    payload = {
        "mbrNm": "",
        "telNo": "",
        "di": "",
        "certType": "",
        "mbrId": login_id,
        "pw": login_pw,
    }
    headers = {"User-Agent": USER_AGENT, "Referer": LOGIN_PAGE}

    try:
        resp = session.post(
            LOGIN_URL, data=payload, headers=headers, timeout=15, allow_redirects=False,
        )
    except requests.RequestException:
        _set_login_error(session, "network_error")
        return False
    data, error = _login_response_data(resp)
    if data is None:
        _set_login_error(session, error)
        return False
    error_code = data.get("_error_code", "")

    # CD010: 패스워드 변경 필요
    if error_code == "CD010":
        _set_login_error(session, "password_change_required")
        return False

    # CD011: 중복 로그인 (skipDup 처리)
    if error_code == "CD011":
        payload["skipDup"] = "Y"
        try:
            resp = session.post(
                LOGIN_URL, data=payload, headers=headers, timeout=15, allow_redirects=False,
            )
        except requests.RequestException:
            _set_login_error(session, "network_error")
            return False
        data, error = _login_response_data(resp)
        if data is None:
            _set_login_error(session, error)
            return False
        error_code = data.get("_error_code", "")

    if error_code != "CD001":
        _set_login_error(session, "login_rejected")
        return False
    return True


def build_krx_session(
    login_id: str = os.getenv("KRX_ID"), login_pw: str = os.getenv("KRX_PW")
) -> KRXSession | None:
    """
    KRX 로그인 세션을 생성하고 반환합니다.

    환경 변수 KRX_ID, KRX_PW 가 설정되어 있으면 자동으로 로그인합니다.
    로그인 성공 시 KRXSession 객체를 반환하며, 실패 시 None 을 반환합니다.
    """
    if not (login_id and login_pw):
        print("KRX 로그인 실패: KRX_ID 또는 KRX_PW 환경 변수가 설정되지 않았습니다.")
        return None

    print("KRX 로그인 시도...")

    krxs = KRXSession()
    success = krxs.refresh(login_id, login_pw)

    if success:
        print("KRX 로그인 완료.")
        print(
            f"  로그인 시간: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(krxs.login_time))}"
        )
        print(
            f"  만료 시간: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(krxs.expiry_time))}"
        )
        return krxs
    else:
        print(f"KRX 로그인 실패: {krxs.last_error or 'login_rejected'}")
        return None


def get_auth_session() -> KRXSession | None:
    """
    현재 활성화된 KRX 세션을 반환합니다.

    환경 변수 KRX_ID, KRX_PW 가 설정되어 있지 않으면 None 을 반환합니다.
    세션이 만료되었을 경우 자동으로 재로그인을 시도합니다.
    """
    global _auth_session, _refresh_blocked_until

    if _auth_session is None:
        # 환경 변수에서 다시 시도. 재로그인과 같은 잠금·실패 차단을 따른다
        login_id = os.getenv("KRX_ID")
        login_pw = os.getenv("KRX_PW")
        if login_id and login_pw:
            with _refresh_lock:
                if _auth_session is None and time.monotonic() >= _refresh_blocked_until:
                    _auth_session = build_krx_session(login_id, login_pw)
                    if _auth_session is None:
                        _refresh_blocked_until = time.monotonic() + _REFRESH_RETRY_SECONDS
        return _auth_session

    # 세션 만료 확인 및 재로그인. 기준 시각은 유효성 판단보다 먼저 읽는다
    krxs = _auth_session
    seen_login_time = krxs.login_time
    if not krxs.is_valid():
        if not _refresh_session(krxs, seen_login_time, "만료"):
            return None

    return krxs
